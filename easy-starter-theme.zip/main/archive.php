<?php
get_header();

$post = $posts[0];
if ( is_tag() ) {
	$title = 'برچسب : ' . single_tag_title( "", false );
} elseif ( is_day() ) {
	$title = 'بایگانی روزانه : ' . get_the_time( 'F jS, Y' );
} elseif ( is_month() ) {
	$title = 'بایگانی ماهانه : ' . get_the_time( 'F, Y' );
} elseif ( is_year() ) {
	$title = 'بایگانی سالیانه : ' . get_the_time( 'Y' );
}
?>

    ?>
    <div class="container">
        <div class="matn">

            <div class="titleList">
                <p>
                    <img src="<?php echo get_template_directory_uri(); ?>/dist/images/titleList_icon1.png" alt="seperator" class="d-none d-md-inline">
                    &nbsp <?php echo $title; ?> &nbsp
                    <img src="<?php echo get_template_directory_uri(); ?>/dist/images/titleList_icon2.png" alt="seperator" class="d-none d-md-inline">
                </p>
            </div>

			<?php
			if ( have_posts() ) {

				?>

                <div class="row">
					<?php

					while ( have_posts() ) : the_post();

						include get_template_directory() . '/php/view/post-card.php';

					endwhile;

					?>
                </div>

				<?php
			}

			?>
        </div>
    </div>
<?php


//Pagination
if ( function_exists( 'wp_pagenavi' ) ) {
	echo '
<div class="container text-center" style="margin-top: 20px;margin-bottom: 48px;">
       <div class="text-center pagination_view">
       <nav aria-label="Page navigation">';
	echo wp_pagenavi( array( 'echo' => false ) );
	echo '</nav></div></div>';
}

get_footer();