<?php

// Load Helper Class
require_once( 'php/Helper.php' );

// Load ACf Option Page and Custom Meta Box
define( 'WP_ACF_OPTION_PAGE_SLUG', 'theme-general-settings' );
require_once( 'php/ACF.php' );

// Register jQuery Scripts and CSS Styles
if ( ! defined( 'DOING_AJAX' ) ) {
	require_once( 'php/setup/wp-head.php' );
}

// Activation Hook
require_once 'php/setup/activation_hook.php';

// Load ACL WordPress
require_once 'php/ACL/ACL_Helper.php';
require_once 'php/ACL/ACL_Config.php';
require_once 'php/ACL/Login_System.php';

// Support Template
require_once( 'php/setup/support.php' );

// Load Bootstrap FrameWork Compatible Class
//require_once( 'php/Bootstrap/bs4navwalker.php' );
//require_once( 'php/Bootstrap/pagination.php' );
//require_once( 'php/Bootstrap/wp-pagenavi.php' );

/* Helper Function */
require_once( 'php/config/helper.php' );

/* attachment Function */
require_once( 'php/config/attachment.php' );

/* Plugins Hook and Filters */
require_once( 'php/config/hook.php' );

/*Add Widget in Site*/
if ( ! defined( 'DOING_AJAX' ) ) {
	//require_once( 'php/config/widget.php' );
}

/* Contact form */
//require_once( 'php/WP_Contact_Form.php' );

// Check Access to Admin Area
require_once( 'php/access.php' );

/* Testing For Developer */
add_action( 'wp_footer', 'wp_theme_test_developer' );
function wp_theme_test_developer() {
	//	$t = "سلام";
	//	$t .= "\n";
	//	$t .= "خوبی";
	//	WP_THEME_Helper::send_sms( '09301303005', $t );
	//	exit;
	//	global $wp_query;
	//	echo '<pre dir="ltr">';
	//	var_dump($wp_query);
	//	echo '</pre>';
}
