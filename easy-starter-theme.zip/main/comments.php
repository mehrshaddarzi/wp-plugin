<?php 
/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */
if ( post_password_required() ) {
	return;
}


$comments_number = get_comments_number();

//Current User
$current_user_email = '';
if ( is_user_logged_in() ) {
 $current_user = wp_get_current_user();
 $current_user_email = $current_user->user_email;   
}

echo '
<!--Comment blog -->
<div class="blog-single-comments" id="blog-comments">
<div id="comments" class="comments clearfix">
    <div class="comments-title clearfix">
        <div class="comments-title-outer">
            <div class="comments-title-inner"> 
            '.($comments_number >0 ? '<span class="comments-number">'.per_number ( $comments_number ).'</span><span>دیدگاه</span>' : '<span>دیدگاه خود را بنویسید</span>').'
            </div> 
            <span class="sherkat"> در بحث&zwnj;&zwnj; پیرامون این مقاله شرکت کنید! </span></div> 
            <a href="#" data-function="show_comment_form" class="comment-open-button btn btn-success'.($comments_number >0 ? '' : ' hidden').'" data-wpel-link="internal">ارسال دیدگاه</a>
          </div>
    <div class="comment-form-outer '.($comments_number >0 ? '' : 'd-block-important').'">
        <div class="comment-form-holder clearfix">
            <div id="respond" class="comment-respond">
                <h3 id="reply-title" class="comment-reply-title">
                <a rel="nofollow" data-function="remove_replay_comment" id="cancel-comment-reply-link" href="#" style="display:none;">لغو پاسخ</a></h3>
                <form action="#" method="post" id="commentform" class="comment-form" novalidate="">
                    <div class="clearfix">
                        <textarea id="comment" placeholder="دیدگاه شما" name="comment_text" aria-required="true"></textarea>
                    </div>';
                    
if ( is_user_logged_in() ===false ) {
echo '
<div class="comment-name-field col-sm-5">
<input type="text" autocomplete="off" name="author" id="author" placeholder="نام و نام خانوادگی" aria-required="true"'.(is_user_logged_in() ===true ? " value='".wp_acl_user_fullname()."' readonly " : '').'>
</div>
<div class="comment-email-field col-sm-5">
<input type="text" autocomplete="off" name="email" id="email" placeholder="پست الکترونیکی" aria-required="true" value="'.$current_user_email.'"'.(trim($current_user_email) !="" ? ' readonly' : '').'>
</div>';
}
                    
                   echo '
                    <div class="form-submit '.(is_user_logged_in() ===true ? 'col-sm-12 no-pad-right' : 'col-sm-2').'">
                        <input type="hidden" name="comment_post_ID" value="'.get_the_ID().'" id="comment_post_ID">
                        <input type="hidden" name="comment_parent" id="comment_parent" value="0">
                        <input name="submit" type="submit" id="submit" class="btn btn-success comment-submit" value="ارسال دیدگاه">
                    </div>
                    <div class="clearfix"></div>
                </form>
            </div>
        </div>
    </div>
    <div class="comments-holder">
        <ul class="comments-list">';
           
            echo wp_list_comments( array(
                  'style'         => 'li',
                  'max_depth'     => 2,
                  'short_ping'    => true,
                  'avatar_size'   => '50',
                  'walker'        => new Bootstrap_Comment_Walker(),
              ) );
           
           echo '
        </ul>
    </div>
</div>
    </div>';