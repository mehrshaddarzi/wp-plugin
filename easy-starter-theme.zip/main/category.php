<?php
get_header();

/* Get Informarion */
global $cat;

//$term_meta = get_term_meta($cat);
$term_meta = array_map( function ( $a ) {
	return $a[0];
}, get_term_meta( $cat ) );

?>
    <div class="container">
        <div class="matn">

            <div class="titleList">
                <p style="margin-bottom: 20px;">
                    <img src="<?php echo get_template_directory_uri(); ?>/dist/images/titleList_icon1.png" alt="seperator" class="d-none d-md-inline">
                    &nbsp <?php echo single_cat_title(); ?> &nbsp
                    <img src="<?php echo get_template_directory_uri(); ?>/dist/images/titleList_icon2.png" alt="seperator" class="d-none d-md-inline">
                </p>
            </div>

			<?php
			if ( have_posts() ) {

				?>

                <div class="row">
					<?php

					while ( have_posts() ) : the_post();

						include get_template_directory() . '/php/view/post-card.php';

					endwhile;

					?>
                </div>

				<?php
			}

			?>
        </div>
    </div>
<?php


//Pagination
if ( function_exists( 'wp_pagenavi' ) ) {
echo '
<div class="container text-center" style="margin-top: 20px;margin-bottom: 48px;">
       <div class="text-center pagination_view">
       <nav aria-label="Page navigation">';
	echo wp_pagenavi( array( 'echo' => false ) );
	echo '</nav></div></div>';
}

get_footer();