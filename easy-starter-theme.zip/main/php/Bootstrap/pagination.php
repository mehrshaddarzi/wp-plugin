<?php

/**
 * @param WP_Query|null $wp_query
 * @param bool $echo
 *
 * @param string $get
 * @param null $base
 * @return string
 * Accepts a WP_Query instance to build pagination (for custom wp_query()),
 * or nothing to use the current global $wp_query (eg: taxonomy term page)
 * - Tested on WP 4.9.5
 * - Tested with Bootstrap 4.1
 * - Tested on Sage 9
 *
 * USAGE:
 *     <?php echo bootstrap_pagination(); ?> //uses global $wp_query
 * or with custom WP_Query():
 *     <?php
 *      $query = new \WP_Query($args);
 *       ... while(have_posts()), $query->posts stuff ...
 *       echo bootstrap_pagination($query);
 *     ?>
 */
function bootstrap_pagination( \WP_Query $wp_query = null, $echo = true, $get = 'paged', $base = null ) {
	if ( null === $wp_query ) {
		global $wp_query;
	}
	if ( $base == null ) {
		$base = str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) );
	}
	$pages = paginate_links( array(
			'base'         => $base,
			'format'       => '?' . $get . '=%#%',
			'current'      => max( 1, ( $get == "paged" ? get_query_var( 'paged' ) : $_GET[ $get ] ) ),
			'total'        => $wp_query->max_num_pages,
			'type'         => 'array',
			'show_all'     => false,
			'end_size'     => 3,
			'mid_size'     => 1,
			'prev_next'    => true,
			'prev_text'    => __( 'قبل' ),
			'next_text'    => __( 'بعد' ),
			'add_args'     => false,
			'add_fragment' => ''
		)
	);
	if ( is_array( $pages ) ) {
		//$paged = ( get_query_var( 'paged' ) == 0 ) ? 1 : get_query_var( 'paged' );
		$pagination = '<div class="pagination"><ul class="pagination" style="    margin: 30px auto; font-family: YJ;">';
		foreach ( $pages as $page ) {
			$pagination .= '<li class="page-item' . ( strpos( $page, 'current' ) !== false ? ' active' : '' ) . '"> ' . str_replace( 'page-numbers', 'page-link', $page ) . '</li>';
		}
		$pagination .= '</ul></div>';
		if ( $echo ) {
			echo $pagination;
		} else {
			return $pagination;
		}
	}
	return null;
}
function bootstrap_pagination_comment( $total, $echo = true, $get = 'paged', $base = null ) {
	if ( $base == null ) {
		$base = str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) );
	}
	$pages = paginate_links( array(
			'base'         => $base,
			'format'       => '?' . $get . '=%#%',
			'current'      => max( 1, ( $get == "paged" ? get_query_var( 'paged' ) : $_GET[ $get ] ) ),
			'total'        => $total,
			'type'         => 'array',
			'show_all'     => false,
			'end_size'     => 3,
			'mid_size'     => 1,
			'prev_next'    => true,
			'prev_text'    => __( 'قبل' ),
			'next_text'    => __( 'بعد' ),
			'add_args'     => false,
			'add_fragment' => ''
		)
	);
	if ( is_array( $pages ) ) {
		//$paged = ( get_query_var( 'paged' ) == 0 ) ? 1 : get_query_var( 'paged' );
		$pagination = '<div class="pagination"><ul class="pagination" style="    margin: 30px auto; font-family: YJ;">';
		foreach ( $pages as $page ) {
			$pagination .= '<li class="page-item' . ( strpos( $page, 'current' ) !== false ? ' active' : '' ) . '"> ' . str_replace( 'page-numbers', 'page-link', $page ) . '</li>';
		}
		$pagination .= '</ul></div>';
		if ( $echo ) {
			echo $pagination;
		} else {
			return $pagination;
		}
	}
	return null;
}