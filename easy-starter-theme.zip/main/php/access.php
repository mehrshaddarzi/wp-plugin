<?php

// disable Admin Bar Auto Optimize For Another User
add_action( 'admin_bar_menu', 'autoptimize_remove_toolbar_node', 999 );
function autoptimize_remove_toolbar_node( $wp_admin_bar ) {
	global $current_user;
	if ( $current_user->ID != 1 ) {
		$wp_admin_bar->remove_node( 'autoptimize' );
	}
}

// Disable Plugins.php page for admin
add_action( "load-plugins.php", 'disable_load_plugins_page' );
function disable_load_plugins_page() {
	if ( is_user_logged_in() and get_current_user_id() == 1 ) {
		return;
	}
	wp_redirect( admin_url() );
	exit;
}

// Disable Menu for Another Users
add_action( 'admin_head', 'wp_theme_my_custom_admin_head' );
function wp_theme_my_custom_admin_head() {
	$current_user = wp_get_current_user();
	if ( $current_user->ID > 0 ) {
		?>
        <style>
            li.toplevel_page_wp-user-avatar {
                display: none;
            }
        </style>

		<?php
	}
}
