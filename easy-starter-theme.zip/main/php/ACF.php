<?php
/**
 * Create Template Option Page
 * @see https://www.advancedcustomfields.com/resources/acf_add_options_page/
 */
if ( function_exists( 'acf_add_options_page' ) ) {
	acf_add_options_page( array(
		'page_title'      => 'تنظیمات پوسته',
		'menu_title'      => 'تنظیمات پوسته',
		'menu_slug'       => WP_ACF_OPTION_PAGE_SLUG,
		'capability'      => 'manage_options',
		'redirect'        => false,
		'parent_slug'     => '',
		'icon_url'        => 'dashicons-admin-customizer',
		'update_button'   => __( 'بروز رسانی', 'acf' ),
		'updated_message' => __( "تنظیمات بروز رسانی شد", 'acf' ),
	) );
}

/**
 * Custom Css for Setting Page ACF
 */
add_action( 'admin_head', 'custom_admin_head_acf_option_page' );
function custom_admin_head_acf_option_page() {
	if ( isset( $_GET['page'] ) and $_GET['page'] == WP_ACF_OPTION_PAGE_SLUG ) {
		?>
        <script>
            jQuery(document).ready(function ($) {
                let Submit_Box = $('#postbox-container-1');
                let save_box = Submit_Box.clone();
                save_box.appendTo("#poststuff");
                Submit_Box.remove();
                $("#post-body").removeClass("columns-2");
                $("#submitdiv h2, #submitdiv button").remove();
            });
        </script>
        <style>
            #postbox-container-1 {
                width: 100px !important;
            }

            #publishing-action #publish {
                border-radius: 5px;
            }

            #submitdiv {
                background: transparent;
                border: 0px;
            }
        </style>
		<?php
	}
}

/**
 * Hide ACF Menu for Users
 */
add_filter( 'acf/settings/show_admin', 'my_acf_show_admin' );
function my_acf_show_admin( $show ) {
	$current_user = wp_get_current_user();
	return ( current_user_can( 'manage_options' ) and is_user_logged_in() and $current_user->user_login == "mehrshad" );
}

/**
 * Get Theme Option
 * @see https://www.advancedcustomfields.com/resources/options-page/
 *
 * @param $name
 * @param bool $default
 * @return mixed
 * Return Null if not exist theme option
 * @see https://www.advancedcustomfields.com/resources/#field-types
 */
function get_theme_option( $name, $default = false ) {
	$option = get_field( $name, 'option' );
	if ( $option == null || empty( $option ) ) {
		return $default;
	}
	return $option;
}