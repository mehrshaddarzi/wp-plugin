<?php

class WP_THEME_Helper {
	/**
	 * Default Template Part Path
	 *
	 * @param $slug
	 */
	public static $template_part_path = 'php/view/';


	public function __construct() {

		// init Session
		add_action( 'init', array( $this, 'init_sessions' ) );

	}

	public function init_sessions() {
		if ( ! session_id() ) {
			session_start();
		}
	}

	public static function json_exit( $array ) {
		wp_send_json( $array );
		exit;
	}

	public static function wp_strip_all_tags( $text ) {
		return wp_strip_all_tags( strip_shortcodes( $text ) );
	}

	public static function mb_strlen( $text, $character = 80, $more = false ) {
		$str = mb_substr( $text, 0, $character, "utf-8" );
		if ( $more === true and ( mb_strlen( $str ) >= $character ) ) {
			$str .= " ..";
		}

		return $str;
	}

	public static function is_elementor() {
		global $post;
		return \Elementor\Plugin::$instance->db->is_built_with_elementor( $post->ID );
	}


	/* Related Post */
	public static function wp_get_related_posts( $post_id, $related_count, $args = array() ) {
		$args = wp_parse_args( (array) $args, array(
			'orderby' => 'rand',
			'return'  => 'query', // Valid values are: 'query' (WP_Query object), 'array' (the arguments array)
		) );

		$related_args = array(
			'post_type'      => get_post_type( $post_id ),
			'posts_per_page' => $related_count,
			'post_status'    => 'publish',
			'post__not_in'   => array( $post_id ),
			'orderby'        => $args['orderby'],
			'tax_query'      => array()
		);

		$post       = get_post( $post_id );
		$taxonomies = get_object_taxonomies( $post, 'names' );

		foreach ( $taxonomies as $taxonomy ) {
			$terms = get_the_terms( $post_id, $taxonomy );
			if ( empty( $terms ) ) {
				continue;
			}
			$term_list                   = wp_list_pluck( $terms, 'slug' );
			$related_args['tax_query'][] = array(
				'taxonomy' => $taxonomy,
				'field'    => 'slug',
				'terms'    => $term_list
			);
		}

		if ( count( $related_args['tax_query'] ) > 1 ) {
			$related_args['tax_query']['relation'] = 'OR';
		}

		if ( $args['return'] == 'query' ) {
			return new WP_Query( $related_args );
		} else {
			return $related_args;
		}
	}

	public static function this_page_url() {
		$url = home_url();
		if ( isset( $_SERVER['HTTP_HOST'] ) and isset( $_SERVER['REQUEST_URI'] ) ) {
			$url = ( isset( $_SERVER['HTTPS'] ) && $_SERVER['HTTPS'] === 'on' ? "https" : "http" ) . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
		}
		return $url;
	}

	/**
	 * Get Attachment Info
	 *
	 * @param $attachment_id
	 * @return array
	 */
	public static function get_attachment( $attachment_id ) {
		$attachment = get_post( $attachment_id );
		return array(
			'alt'         => get_post_meta( $attachment->ID, '_wp_attachment_image_alt', true ),
			'caption'     => $attachment->post_excerpt,
			'description' => $attachment->post_content,
			'href'        => get_permalink( $attachment->ID ),
			'src'         => $attachment->guid,
			'title'       => $attachment->post_title
		);
	}

	/**
	 * @see https://developer.wordpress.org/reference/functions/get_template_part/
	 * @param $slug
	 */
	public static function template_part( $slug ) {
		get_template_part( self::$template_part_path . $slug );
	}

	/**
	 * @see https://codex.wordpress.org/Function_Reference/wp_get_theme
	 * @param $what
	 * @return false|string
	 */
	public static function get_theme_info( $what ) {
		$my_theme = wp_get_theme();
		return $my_theme->get( $what );
	}

	public static function is_login_page() {
		return in_array( $GLOBALS['pagenow'], array( 'wp-login.php', 'wp-register.php' ), true );
	}

	/**
	 * Send SMS With WP-SMS Plugin
	 *
	 * @param $to
	 * @param $text
	 * @return bool
	 */
	public static function send_sms( $to, $text ) {
//		if ( function_exists( 'wp_sms_send' ) ) {
//			$wp_sms_opt = get_option( 'wpsms_settings' );
//			$to         = ( $to == "admin" ? $wp_sms_opt['admin_mobile_number'] : $to );
//			$run        = wp_sms_send( $to, $text );
//			return ( is_wp_error( $run ) ? false : true );
//			return true;
//		}

		// MSG
		$message = $text;
		$footer_sms = trim( get_theme_option( 'sms-footer' ) );
		if ( ! empty( $footer_sms ) ) {
			$message = $message . "\n" . $footer_sms;
		}

		// Send
		$wp_sms_opt = get_option( 'wpsms_settings' );
		$to         = ( $to == "admin" ? $wp_sms_opt['admin_mobile_number'] : $to );
		$request   = wp_remote_get( "https://ip.sms.ir/SendMessage.ashx?user=9122954972&pass=nasrabadi2906&text=" . urlencode( $message ) . "&to=" . $to . "&lineNo=10004373829344", array(
			'timeout' => 30
		) );
		if( is_wp_error( $request ) ) {
			return false;
		}

		return false;
	}

	public function set_html_content_type() {
		return 'text/html';
	}

	public static function wp_send_mail( $to, $subject, $body, $attachment = array() ) {
		$headers = 'Content-Type: text/html; charset=UTF-8';
		add_filter( 'wp_mail_content_type', array( 'WP_THEME_Helper', 'set_html_content_type' ) );
		wp_mail( $to, $subject, $body, $headers, $attachment );
		remove_filter( 'wp_mail_content_type', array( 'WP_THEME_Helper', 'set_html_content_type' ) );
		/*
		add_action( 'wp_mail_failed', 'onMailError', 10, 1 );
		function onMailError( $wp_error ) {
			echo "<pre>";
			print_r($wp_error);
			echo "</pre>";
		}
		*/
	}


	/******** This Project Helper */

	/**
	 * Sanitize Iranian Mobile Number
	 *
	 * @param $mobile
	 * @return array
	 */
	public static function sanitize_mobile_number( $mobile ) {
		$result = array(
			'success' => true,
			'txt'     => ''
		);

		//mobile Number character
		if ( strlen( $mobile ) !== 11 ) {
			$result['text']    = 'شماره همراه 11 کاراکتر می باشد';
			$result['success'] = false;
		}

		//mobile start 09
		if ( substr( $mobile, 0, 2 ) !== "09" ) {
			$result['text']    = 'شماره همراه با 09 شروع می شود';
			$result['success'] = false;
		}

		//mobile Numeric
		if ( ! is_numeric( $mobile ) ) {
			$result['text']    = 'شماره همراه تنها شامل کاراکتر عدد می باشد';
			$result['success'] = false;
		}

		return $result;
	}

	public static function wp_upload_file( $file_id, $model = false ) {
		require_once( ABSPATH . 'wp-admin/includes/image.php' );
		require_once( ABSPATH . 'wp-admin/includes/file.php' );
		require_once( ABSPATH . 'wp-admin/includes/media.php' );
		$attachment_id = media_handle_upload( $file_id, 0 );

		if ( is_wp_error( $attachment_id ) ) {
			return false;
		} else {
			//add to Not Show in attachment list
			//$opt = get_option("hide_attachment_list");
			// if($opt) {
			//$opt[] = $attachment_id;
			//update_option("hide_attachment_list",$opt);
			if ( $model != false ) {
				update_post_meta( $attachment_id, "what_is", $model );
			}
		}

		return $attachment_id;
	}

}

new WP_THEME_Helper;