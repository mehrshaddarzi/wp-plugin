<?php

class ACL_Helper {
	/**
	 * Get User Data
	 *
	 * @param bool $user_id
	 * @return array
	 */
	public static function get( $user_id = false ) {

		# Get User ID
		$user_id = $user_id ? $user_id : get_current_user_id();

		# Get User Data
		$user_data = get_userdata( $user_id );
		$user_info = get_object_vars( $user_data->data );

		# Get User roles
		$user_info['role'] = $user_data->roles;

		# Get User Caps
		$user_info['cap'] = $user_data->caps;

		# Get User Meta
		$user_info['meta'] = array_map( function ( $a ) {
			return $a[0];
		}, get_user_meta( $user_id ) );

		return $user_info;
	}

	/**
	 * Get Full name of User
	 *
	 * @param $user_id
	 * @return string
	 */
	public static function get_name( $user_id = false ) {

		# Get User ID
		$user_id = $user_id ? $user_id : get_current_user_id();

		# Get User Info
		$user_info = self::get( $user_id );

		# check display name
		if ( $user_info['display_name'] != "" ) {
			return $user_info['display_name'];
		}

		# Check First and Last name
		if ( $user_info['first_name'] != "" ) {
			return $user_info['first_name'] . " " . $user_info['last_name'];
		}

		# return Username
		return $user_info['user_login'];
	}


	public static function avatar( $user_id = false ) {
		$user_id     = $user_id ? $user_id : get_current_user_id();
		$user_avatar = get_user_meta( $user_id, 'avatar', true );
		if ( empty( $user_avatar ) ) {
			return get_template_directory_uri() . '/php/ACL/avatar/man.svg';
		} else {
			$get_attachment = wp_get_attachment_image_src( $user_avatar );
			return $get_attachment[0];
		}
	}

	/**
	 * Check User Exist By id
	 *
	 * @param $user_id
	 * @return bool
	 * We Don`t Use get_userdata or get_user_by function, because We need only count nor UserData object.
	 */
	public static function exists( $user_id ) {
		global $wpdb;

		$count = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $wpdb->users WHERE `ID` = %d", $user_id ) );
		return $count > 0;
	}

	/**
	 * Get WordPress Role List
	 */
	public static function get_role_list() {
		global $wp_roles;
		return $wp_roles->get_names();
	}

	public static function get_user_by_meta( $key, $value, $compare = "=", $extra = false ) {
		$defaults = array(
			'meta_key'     => $key,
			'meta_value'   => $value,
			'meta_compare' => $compare,
			'number'       => 1,
			'count_total'  => false
		);
		$args     = wp_parse_args( $extra, $defaults );
		$user     = get_users( $args );
		if ( count( $user ) == 1 ) {
			return $user[0]->data;
		} else {
			return false;
		}
	}
}