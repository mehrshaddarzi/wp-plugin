<?php

class ACL_Config {
	/**
	 * ACL_Config constructor.
	 */
	public function __construct() {

		// Config Role
		add_action( 'init', array( $this, 'role' ) );

		// Disable All Email Notification
		add_filter( 'send_password_change_email', '__return_false' );
		add_filter( 'send_email_change_email', '__return_false' );
		add_filter( 'wp_new_user_notification_email', '__return_false' );
		add_filter( 'wp_new_user_notification_email_admin', '__return_false' );

		// Register User
		add_action( 'user_register', array( $this, 'register' ), 10, 1 );
	}

	/**
	 * @ see https://wordpress.org/support/article/roles-and-capabilities/
	 * @see https://developer.wordpress.org/reference/functions/remove_role/
	 */
	public function role() {
		global $wp_roles;

		// Check Has Role global
		if ( ! isset( $wp_roles ) ) {
			$wp_roles = new WP_Roles();
		}

		//You can list all currently available roles like this...
		//$roles = $wp_roles->get_names();
		// We Don't Use remove_role because it removed completely From DB
		unset( $wp_roles->roles['editor'] );
		unset( $wp_roles->roles['contributor'] );

		// Change name of Role
		$wp_roles->roles['subscriber']['name'] = 'مشتری';
		$wp_roles->roles['author']['name']     = 'اپراتور';

		// Create New role
//		if ( ! isset( $wp_roles->roles['peyk'] ) ) {
//			$author = $wp_roles->get_role( 'author' );
//			$wp_roles->add_role( 'peyk', 'پیک سفارش', $author->capabilities );
//		}
	}

	public function register( $user_id ) {

		// Change Not Show Admin Bar
		update_user_meta( $user_id, 'show_admin_bar_front', 'false' );

	}

}

new ACL_Config;