<?php

class WP_Login_System {

	public function __construct() {

		// Disable Email Require For Register in WordPress
		add_action( 'user_profile_update_errors', array( $this, 'disable_email' ) );

		// Ajax Login or Register User
		add_action( 'wp_ajax_login_system', array( $this, 'login_system' ) );
		add_action( 'wp_ajax_nopriv_login_system', array( $this, 'login_system' ) );

		// Ajax change User Avatar
		add_action( 'wp_ajax_wp_change_user_avatar', array( $this, 'wp_change_user_avatar' ) );
		add_action( 'wp_ajax_nopriv_wp_change_user_avatar', array( $this, 'wp_change_user_avatar' ) );

		// Add column For users.php
		add_filter( 'manage_users_columns', array( $this, 'pippin_add_user_id_column' ) );
		add_action( 'manage_users_custom_column', array( $this, 'pippin_show_user_id_column_content' ), 10, 3 );
		add_filter( 'manage_users_sortable_columns', array( $this, 'fc_my_sortable_cake_column' ) );
		add_action( "pre_get_users", array( $this, 'pre_user_query' ), 10, 1 );

		// Hide field From Admin Wordpress
		add_action( "admin_head", array( $this, 'admin_head' ), 20 );
		add_action( 'user_new_form', array( $this, 'fb_add_custom_user_profile_fields' ), 10 );

		// Edit User Ajax
		add_action( 'wp_ajax_editable_user_profile', array( $this, 'editable_user_profile' ) );
		add_action( 'wp_ajax_nopriv_editable_user_profile', array( $this, 'editable_user_profile' ) );
	}

	public function admin_head() {
		global $pagenow;
		if ( $pagenow == "users.php" ) {
			?>
            <style>
                .row-actions span.view {
                    display: none;
                }
            </style>
			<?php
		}

		if ( $pagenow == "user-edit.php" ) {
			?>
            <style>
                li#wp-admin-bar-view {
                    display: none;
                }

                h2 {
                    display: none;
                }
            </style>
            <script>
                jQuery(document).ready(function () {
                    jQuery("input#rich_editing").parent().parent().parent().parent().hide();
                    jQuery("textarea#description").parent().parent().parent().hide();
                    jQuery("input#url").parent().parent().parent().hide();
                    jQuery("input#email").parent().parent().parent().hide();
                    jQuery("#fieldset-shipping").hide();
                });
            </script>
			<?php
		}
	}

	public function fb_add_custom_user_profile_fields() {
		?>
        <style>
            tr.pw-weak {
                display: none !important;
            }
        </style>
        <script>
            jQuery(document).ready(function () {
                jQuery("input#email").parent().parent().hide();
                jQuery("input#url").parent().parent().hide();
                jQuery("input#send_user_notification").parent().parent().hide();
                jQuery("label[for=user_login]").html("موبایل");
                $("form[name=createuser]").attr("autocomplete", "off");
                $("input[name=send_user_notification]").prop('checked', false);
                $("input[name=pw_weak]").attr("checked", "checked").parent().parent().hide();
                $("tr[class=pw-weak]").attr("style", "display:none;");
                $("input[name=user_login]").addClass("ltr");
                $("input[name=user_login]").val("09");
                $("tr[class=pw-weak]").attr("style", "display:none;");
                $("div[id=pass-strength-result]").hide();
                jQuery(document).on('keyup', 'input[name=pass1-text]', function (e) {
                    e.preventDefault();
                    $("tr[class=pw-weak]").attr("style", "display:none;");
                });
                let math_num = Math.floor((Math.random() * 99999) + 10000);
                $("input[name=pass1]").val(math_num).attr("data-pw", math_num).attr("readonly", "readonly");
            });
        </script>
		<?php
	}

	public function pre_user_query( $WP_User_Query ) {
		if ( ! is_admin() ) {
			return;
		}
		if ( isset( $WP_User_Query->query_vars["orderby"] ) && ( "order_num" === $WP_User_Query->query_vars["orderby"] ) ) {
			$WP_User_Query->query_vars["meta_key"] = "_order_count";
			$WP_User_Query->query_vars["orderby"]  = "meta_value";
		}
	}

	public function fc_my_sortable_cake_column( $columns ) {
		$columns['order-number'] = 'order_num';
		return $columns;
	}

	public function pippin_add_user_id_column( $columns ) {
		$columns['avatar']         = 'آواتار';
		$columns['date-reg']       = 'تاریخ ثبت نام';
		$columns['order-number']   = 'تعداد سفارش';
		$columns['payment-number'] = 'مجموع خرید';
		unset( $columns['posts'] );
		unset( $columns['email'] );
		return $columns;
	}

	/**
	 * @param $value
	 * @param $column_name
	 * @param $user_id
	 * @return datetime|string
	 */
	public function pippin_show_user_id_column_content( $value, $column_name, $user_id ) {
		$user = get_userdata( $user_id );
		if ( 'avatar' == $column_name ) {
			return '<img src="' . ACL_Helper::avatar( $user_id ) . '" style="width: 50px; height: 50px; border-radius: 50%;">';
		}
		if ( 'date-reg' == $column_name ) {
			return parsidate( "Y-m-d H:i", $user->user_registered );
		}
		if ( 'order-number' == $column_name ) {
			return per_number( number_format_i18n( wc_get_customer_order_count( $user_id ) ) );
		}
		if ( 'payment-number' == $column_name ) {
			return per_number( number_format_i18n( WooCommerce_Helper::get_sum_pay_order_by_user_id( $user_id ) ) ) . ' ' . get_woocommerce_currency_symbol();
		}
		return $value;
	}


	public function editable_user_profile() {
		global $wpdb;

		if ( defined( 'DOING_AJAX' ) and isset( $_REQUEST ) ) {

			// Check Refer Admin Ajax
			wp_verify_nonce( $_REQUEST['token'], 'wp_rest' );

			//Set internal Array For Export
			$result = array( 'status' => 'no', 'message' => '' );

			//Check User Loggin
			if ( ! is_user_logged_in() ) {
				exit;
			}

			// Check Has data
			if ( ! isset( $_REQUEST['email'] ) || ! isset( $_REQUEST['name'] ) || ! isset( $_REQUEST['current_pass'] ) || ! isset( $_REQUEST['pass_1'] ) || ! isset( $_REQUEST['pass_2'] ) ) {
				exit;
			}

			// check Email
			$user_email = sanitize_text_field( $_REQUEST['email'] );
			if ( ! empty( $user_email ) and is_email( $user_email ) === false ) {
				WP_THEME_Helper::json_exit( array( 'status' => 'no', 'message' => 'لطفا ایمیل را صحیح وارد کنید' ) );
			}
			if ( ! empty( $user_email ) and ( email_exists( $user_email ) != false and email_exists( $user_email ) != get_current_user_id() ) ) {
				WP_THEME_Helper::json_exit( array( 'status' => 'no', 'message' => 'این ایمیل توسط کاربر دیگری به ثبت رسیده است.' ) );
			}

			// Edit User email and display_name
			$user_id = get_current_user_id();
			wp_update_user( array(
				'ID'           => $user_id,
				'user_email'   => $user_email,
				'display_name' => sanitize_text_field( $_REQUEST['name'] )
			) );

			// Edit Password
			if ( ! empty( $_REQUEST['current_pass'] ) and ! empty( $_REQUEST['pass_1'] ) and ! empty( $_REQUEST['pass_2'] ) ) {

				// Check User Current Password
				$user = get_userdata( get_current_user_id() );
				if ( wp_check_password( $_REQUEST['current_pass'], $user->data->user_pass, $user->ID ) === false ) {
					WP_THEME_Helper::json_exit( array( 'status' => 'no', 'message' => 'رمز فعلی شما اشتباه می باشد.' ) );
				}

				// Change Password
				wp_update_user( array(
					'ID'        => $user_id,
					'user_pass' => sanitize_text_field( $_REQUEST['pass_1'] )
				) );
			}

			WP_THEME_Helper::json_exit( array( 'status' => 'yes', 'message' => 'اطلاعات کاربری با موفقیت بروز رسانی گردید' ) );
		}
		die();
	}

	public function wp_change_user_avatar() {
		global $wpdb;
		if ( defined( 'DOING_AJAX' ) and isset( $_REQUEST ) ) {

			// Check Refer Admin Ajax
			wp_verify_nonce( $_REQUEST['token'], 'wp_rest' );

			//Set internal Array For Export
			$result = array( 'status' => 'no', 'message' => '' );

			//Check User Loggin
			if ( ! is_user_logged_in() ) {
				exit;
			}

			// Change Avatar
			$attachment_id = WP_THEME_Helper::wp_upload_file( 'profile_image', false );
			if ( $attachment_id === false ) {
				WP_THEME_Helper::json_exit( array( 'status' => 'no', 'message' => 'ارسال عکس موفقت آمیز نبود لطفا دوباره تلاش کنید' ) );
			} else {

				update_user_meta( get_current_user_id(), 'avatar', $attachment_id );
				$src = wp_get_attachment_image_src( $attachment_id );
				WP_THEME_Helper::json_exit( array( 'status' => 'yes', 'message' => 'آواتار شما با موفقیت تغییر یافت.', 'avatar_id' => $attachment_id, 'avatar' => $src[0] ) );
			}
		}
		die();
	}

	public function disable_email( $arg ) {
		if ( ! empty( $arg->errors['empty_email'] ) ) {
			unset( $arg->errors['empty_email'] );
		}
	}

	/**
	 * New Code Valid For Mobile Register
	 *
	 * @param $mobile
	 */
	public static function new_code_mobile_valid_register( $mobile ) {
		global $wpdb;

		//Send Code Validation Mobile
		$code        = rand( 10000, 99999 );
		$text_mobile = "کد تایید هویت شما : " . $code;
		WP_THEME_Helper::send_sms( $mobile, $text_mobile );

		// Remove All Code for this number
		$wpdb->query( "DELETE FROM `{$wpdb->prefix}get_valid_mobile_code` WHERE `mobile` = '" . $mobile . "'" );

		//insert Row Code Valid in db
		$wpdb->insert(
			$wpdb->prefix . 'get_valid_mobile_code',
			array(
				'mobile' => $mobile,
				'code'   => $code,
				'date'   => current_time( 'mysql' ),
			)
		);
//		if ( $wpdb->last_error !== '' ) {
//			update_option( 'debug_last_error_wpdb', $wpdb->last_error, 'no' );
//		}
	}

	/**
	 * Login System ajax With Mobile
	 */
	public function login_system() {
		global $wpdb;

		if ( defined( 'DOING_AJAX' ) and isset( $_REQUEST ) ) {

			// Check Refer Admin Ajax
			wp_verify_nonce( $_REQUEST['token'], 'wp_rest' );

			//Set internal Array For Export
			$result = array( 'status' => 'no', 'message' => '' );

			// Step 1 =>  Check exist User With This Mobile number
			if ( $_REQUEST['step'] == "1" ) {

				//Check Mobile
				if ( ! isset ( $_REQUEST['mobile'] ) ) {
					exit;
				}

				// Check Mobile Validation
				$mobile          = sanitize_text_field( $_REQUEST['mobile'] );
				$validate_mobile = WP_THEME_Helper::sanitize_mobile_number( $mobile );
				if ( $validate_mobile['success'] === false ) {
					$result['message'] = 'خطا : ' . $validate_mobile['text'];
					WP_THEME_Helper::json_exit( $result );
				}

				// Check User in Database
				$user = get_user_by( 'login', $mobile );
				if ( ! $user ) {

					// Create new Code valid mobile
					self::new_code_mobile_valid_register( $mobile );
					$this_time = current_time( 'timestamp' ) + ( 60 * 2 );
					WP_THEME_Helper::json_exit( array( 'status' => 'yes', 'message' => 'new_user', 'now_date' => date( "Y-m-d H:i:s", $this_time ) ) );
				} else {
					WP_THEME_Helper::json_exit( array( 'status' => 'yes', 'message' => 'login' ) );
				}

			}

			// Step 2 => Check Code Validation mobile for Start Register
			if ( $_REQUEST['step'] == "2" ) {

				//Check Mobile and Code
				if ( ! isset ( $_REQUEST['mobile'] ) || ! isset ( $_REQUEST['code'] ) ) {
					exit;
				}

				$mobile = sanitize_text_field( $_REQUEST['mobile'] );
				$code   = sanitize_text_field( $_REQUEST['code'] );

				// Check code in database
				$_exist_code = $wpdb->get_row( "SELECT `ID` FROM `{$wpdb->prefix}get_valid_mobile_code` WHERE `mobile` = '" . esc_sql( $mobile ) . "' AND `code` = '" . esc_sql( $code ) . "' order by `ID` DESC LIMIT 1", ARRAY_A );
				if ( null !== $_exist_code ) {
					WP_THEME_Helper::json_exit( array( 'status' => 'yes', 'message' => 'go_to_process' ) );
				} else {
					$result['message'] = 'کد وارد شده اشتباه هست';
					WP_THEME_Helper::json_exit( $result );
				}
			}

			// Step 3 => Reset Password with Mobile
			if ( $_REQUEST['step'] == "3" ) {

				//Check Mobile and Code
				if ( ! isset ( $_REQUEST['mobile'] ) ) {
					exit;
				}
				$mobile = sanitize_text_field( $_REQUEST['mobile'] );

				// Check Exist User With this Mobile
				$user = get_user_by( 'login', $mobile );
				if ( ! $user ) {
					WP_THEME_Helper::json_exit( array( 'status' => 'yes', 'message' => 'کاربری با این شماره همراه وجود ندارد' ) );
				}

				// Remove all Session from this user
				$wpdb->query( "DELETE FROM `{$wpdb->prefix}new_password_restore_mobile` WHERE `user_id` = " . $user->ID );

				//add to database
				$current       = current_time( 'timestamp' );
				$after_current = $current + ( 60 * 60 * 12 );
				$code          = rand( 10000, 99999 );
				$wpdb->insert(
					$wpdb->prefix . 'new_password_restore_mobile',
					array(
						'user_id'   => $user->ID,
						'mobile'    => $mobile,
						'code'      => $code,
						'timestamp' => $after_current,
					)
				);

				//Send Sms
				$text_mobile = "کاربر گرامی " . ACL_Helper::get_name( $user->ID );
				$text_mobile .= "\n";
				$text_mobile .= "رمز عبور جدید شما در وب سایت " . $code . " می باشد ";
				WP_THEME_Helper::send_sms( $mobile, $text_mobile );
				WP_THEME_Helper::json_exit( array( 'status' => 'yes', 'message' => 'added_to_db' ) );
			}

			// Step 4 => Login With Password
			if ( $_REQUEST['step'] == "4" ) {

				//Check Mobile and Password
				if ( ! isset ( $_REQUEST['password'] ) || ! isset ( $_REQUEST['mobile'] ) ) {
					exit;
				}

				$password = sanitize_text_field( $_REQUEST['password'] );
				$mobile   = sanitize_text_field( $_REQUEST['mobile'] );

				// Check User id
				$user = get_user_by( 'login', $mobile );
				if ( $user ) {

					//Check Password Main
					if ( wp_check_password( $password, $user->user_pass ) ) {

						//set login
						wp_set_current_user( $user->ID, $user->user_login );
						wp_set_auth_cookie( $user->ID );

						//Remove all restore
						$wpdb->query( "DELETE FROM `{$wpdb->prefix}new_password_restore_mobile` WHERE `user_id` = " . $user->ID );

						//remove all Get valid code
						$wpdb->query( "DELETE FROM `{$wpdb->prefix}get_valid_mobile_code` WHERE `mobile` = '" . $mobile . "'" );

						// Result
						WP_THEME_Helper::json_exit( array( 'status' => 'yes', 'message' => 'user_is_success_login' ) );
					}

					// Check Password Native Restore
					$now_time      = time();
					$restore_count = $wpdb->get_var( "SELECT COUNT(*) FROM `{$wpdb->prefix}new_password_restore_mobile` WHERE `user_id` = " . $user->ID . " AND `mobile` = '" . $mobile . "' AND `code` = '" . $password . "' AND `timestamp` >=$now_time " );
					if ( $restore_count > 0 ) {

						//set password for user
						wp_set_password( $password, $user->ID );

						//set login
						wp_set_current_user( $user->ID, $user->user_login );
						wp_set_auth_cookie( $user->ID );

						//Remove all restore
						$wpdb->query( "DELETE FROM `{$wpdb->prefix}new_password_restore_mobile` WHERE `user_id` = " . $user->ID );

						//remove all Get valid code
						$wpdb->query( "DELETE FROM `{$wpdb->prefix}get_valid_mobile_code` WHERE `mobile` = '" . $mobile . "'" );

						// Result
						WP_THEME_Helper::json_exit( array( 'status' => 'yes', 'message' => 'user_is_success_login' ) );
					}

					$result['message'] = 'رمز عبور اشتباه می باشد';
					WP_THEME_Helper::json_exit( $result );

				} else {
					$result['message'] = 'رمز عبور اشتباه می باشد';
					WP_THEME_Helper::json_exit( $result );
				}

				exit;
			}

			// Step 5 => Register
			if ( $_POST['step'] == "5" ) {

				// Check Security $_POST
				$list_field = array( 'mobile', 'display_name', 'email', 'pass1', 'code' );
				foreach ( $list_field as $f ) {
					if ( ! isset ( $_REQUEST[ $f ] ) ) {
						exit;
					}
				}

				// Validation Code
				if ( $wpdb->get_var( "SELECT COUNT(*) FROM `{$wpdb->prefix}get_valid_mobile_code` WHERE `mobile` = '" . $_REQUEST['mobile'] . "' AND `code` = '" . $_REQUEST['code'] . "'" ) < 1 ) {
					WP_THEME_Helper::json_exit( array( 'status' => 'no', 'message' => 'کد تاییدی صحیح نمی باشد' ) );
				}

				// Check Valid Email
				if ( ! empty( $_REQUEST['email'] ) and ! is_email( $_REQUEST['email'] ) ) {
					WP_THEME_Helper::json_exit( array( 'status' => 'no', 'message' => 'لطفا ایمیل را بدرستی وارد نمایید' ) );
				}

				// Remove all Get valid code
				$wpdb->query( "DELETE FROM `{$wpdb->prefix}get_valid_mobile_code` WHERE `mobile` = '" . sanitize_text_field( $_REQUEST['mobile'] ) . "'" );

				// Register User
				$userdata                 = array();
				$userdata['user_login']   = sanitize_text_field( $_REQUEST['mobile'] );
				$userdata['user_email']   = "";
				$userdata['user_pass']    = sanitize_text_field( $_REQUEST['pass1'] );
				$userdata['role']         = 'subscriber';
				$userdata['display_name'] = sanitize_text_field( $_REQUEST['display_name'] );
				$userdata['first_name']   = sanitize_text_field( $_REQUEST['display_name'] );
				$user_id                  = wp_insert_user( $userdata );
				if ( is_wp_error( $user_id ) ) {
					WP_THEME_Helper::json_exit( array( 'status' => 'no', 'message' => $result->get_error_message() ) );
				}

				// Add To Mobile Subscriber
				WP_SMS_Config::add_user_to_subscriber( array(
					'name'     => sanitize_text_field( $_REQUEST['display_name'] ),
					'mobile'   => sanitize_text_field( $_REQUEST['mobile'] ),
					'group_ID' => WP_SMS_Config::$tuesday_group_id
				) );

				// Auto login after sign up
				$user = get_userdata( $user_id );
				wp_set_current_user( $user->ID, $user->user_login );
				wp_set_auth_cookie( $user->ID );

				// result
				WP_THEME_Helper::json_exit( array( 'status' => 'yes', 'message' => 'success' ) );
			}
		}
		die();
	}


}

new WP_Login_System;