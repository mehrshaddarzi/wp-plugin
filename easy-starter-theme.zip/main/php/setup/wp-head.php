<?php

class WP_THEME_HEAD {

	public function __construct() {

		// Language Attribute
		add_filter( 'language_attributes', array( $this, 'language_attributes' ), 10, 2 );

		// Add ICON WebSite
		add_action( 'wp_head', array( $this, 'add_icon_site' ) );

		// Add Schema Color Browser in Mobile
		add_action( 'wp_head', array( $this, 'theme_color_mobile_browser' ) );

		// Add Alternate Language For Seo
		add_action( 'wp_head', array( $this, 'alternate' ) );

		// Remove Version From Css and Js File
		add_filter( 'style_loader_src', array( $this, 'remove_ver' ), 10, 2 );
		add_filter( 'script_loader_src', array( $this, 'remove_ver' ), 10, 2 );

		// Clean Html5 Tags From Script Tag
		add_filter( 'script_loader_tag', array( $this, 'html5_script_tag' ), 10, 3 );

		// Clean Html Tag From Css Tag
		add_filter( 'style_loader_tag', array( $this, 'html5_style_tag' ) );

		// Change Jquery Url
		add_action( 'wp', array( $this, 'jquery' ) );

		// Remove Jquery Migration
		add_action( 'wp_default_scripts', array( $this, 'remove_jquery_migration' ) );

		// Change Body Class
		add_filter( 'body_class', array( $this, 'body_class' ) );

		// Add H1 For First Page
		do_action( 'wp_body_open', array( $this, 'h1' ) );

		// Register Script and Css
		add_action( 'wp_enqueue_scripts', array( $this, 'register' ) );

		// Remove Comment Js from From
		add_action( 'init', array( $this, 'disable_comment_js' ) );

		// Clean Head
		remove_action( 'rest_api_init', 'wp_oembed_register_route' );
		remove_filter( 'oembed_dataparse', 'wp_filter_oembed_result', 10 );
		remove_action( 'wp_head', 'wp_oembed_add_host_js' );
		remove_action( 'wp_head', 'rest_output_link_wp_head', 10 );
		remove_action( 'wp_head', 'wp_oembed_add_discovery_links', 10 );
		remove_action( 'wp_head', 'wp_generator' );
		remove_action( 'wp_head', 'wp_resource_hints', 2 );
		remove_action( 'wp_head', 'rsd_link' );
		remove_action( 'wp_head', 'wlwmanifest_link' );

		// Remove WordPress Admin Bar
		add_filter( 'show_admin_bar', '__return_false' );

		// Disable Block Editor Css From Head
		add_action( 'wp_enqueue_scripts', array( $this, 'remove_block_css' ), 100 );
	}

	/**
	 * @see https://developer.wordpress.org/reference/functions/get_language_attributes/
	 *
	 * @param $output
	 * @param $doctype
	 * @return mixed
	 */
	public function language_attributes( $output, $doctype ) {
		return $output = ( ( is_admin() === false and WP_THEME_Helper::is_login_page() === false ) ? 'lang="fa-IR"' : $output );
	}

	public function theme_color_mobile_browser() {
		echo '<meta name="theme-color" content="' . get_theme_option( 'theme-color', '#000' ) . '">' . "\n";
	}

	public function add_icon_site() {

		// ICon 32
		$icon_32 = get_theme_option( 'icon-32' );
		if ( is_array( $icon_32 ) and isset( $icon_32['url'] ) and ! empty( $icon_32['url'] ) ) {
			echo '<link rel="icon" href="' . $icon_32['url'] . '" type="image/png">' . "\n";
		}

		// Icon for Mobile
		foreach ( array( 512, 72, 192, 250 ) as $size ) {
			$url_image = get_theme_option( 'icon-' . $size );
			if ( is_array( $url_image ) and isset( $url_image['url'] ) and ! empty( $url_image['url'] ) ) {
				echo ' <link href="' . get_theme_option( 'icon-' . $size ) . '" rel="apple-touch-icon"' . ( $size != 512 ? ' sizes="' . $size . 'x' . $size . '"' : '' ) . '>' . "\n";
			}
		}
	}

	public function alternate() {
		echo '<link rel="alternate" href="' . WP_THEME_Helper::this_page_url() . '" hreflang="fa-IR" />' . "\n";
	}

	function remove_ver( $src ) {

		// Check For SCRIPT DEBUG
		if ( ! is_admin() ) {
			if ( defined( 'SCRIPT_DEBUG' ) and SCRIPT_DEBUG === true ) {
				$src = remove_query_arg( 'ver', $src ) . '?ver=' . time();
			} else {

				// Remove Version
				if ( strpos( $src, '?ver=' ) ) {
					$src = remove_query_arg( 'ver', $src );
				}
			}
		}

		return $src;
	}

	function html5_script_tag( $tag, $handle, $src ) {

		// The handles of the enqueued scripts we want to defer for example jquery
		$defer_scripts = array();
		if ( is_admin() === false ) {
			$tag = preg_replace( '~\s+type=["\'][^"\']++["\']~i', '', $tag );
			$tag = preg_replace( '~\s+id=["\'][^"\']++["\']~i', '', $tag );
			$tag = str_replace( ' media=\'all\' /', '', $tag );
			$tag = str_replace( '  ', ' ', $tag );

			if ( in_array( $handle, $defer_scripts ) ) {
				$tag = str_replace( '<script', '<script defer="defer"', $tag );
			}
		}
		return $tag;
	}

	function html5_style_tag( $tag ) {
		if ( is_admin() === false ) {
			$tag = preg_replace( '~\s+type=["\'][^"\']++["\']~i', '', $tag );
			$tag = preg_replace( '~\s+id=["\'][^"\']++["\']~i', '', $tag );
			$tag = str_replace( ' media=\'all\' /', '', $tag );
			$tag = str_replace( '  ', ' ', $tag );
		}
		return $tag;
	}

	public function jquery() {
		if ( ! is_admin() ) {
			wp_deregister_script( 'jquery' );
			wp_register_script( 'jquery', get_template_directory_uri() . '/dist/js/jquery-3.4.1.min.js', true, '3.4.1' );
			wp_enqueue_script( 'jquery' );
		}
	}

	public function remove_jquery_migration( $scripts ) {
		if ( ! is_admin() && ! empty( $scripts->registered['jquery'] ) ) {
			$jquery_dependencies                 = $scripts->registered['jquery']->deps;
			$scripts->registered['jquery']->deps = array_diff( $jquery_dependencies, array( 'jquery-migrate' ) );
		}
	}

	public function body_class( $classes ) {
		$classes = (array) $classes;

		//Remove Default Class
//		foreach ( $classes as $k => $v ) {
//			if ( stristr( $v, "woocommerce" ) === false ) {
//				unset( $classes[ $k ] );
//			}
//		}

		// Example
		//if ( is_home() || is_front_page() ) {
		//	$classes[] = 'index-back';
		//}
		return $classes;
	}

	public function h1() {
		if ( is_home() || is_front_page() ) { ?>
            <h1 class="site-title"><?php echo get_theme_option( 'h1' ); ?></h1>
		<?php } else { ?>
            <h3 class="site-title"><?php bloginfo( 'name' ); ?></h3>
		<?php }
	}

	public function register() {

		//Load Style
		//wp_enqueue_style( 'animate', get_template_directory_uri() . '/dist/css/animate.min.css', array(), '1.0.0', 'all' );
		//wp_enqueue_style( 'app', get_template_directory_uri() . '/dist/css/app.min.css', array(), WP_THEME_Helper::get_theme_info( 'Version' ), 'all' );

		//Js
		//wp_enqueue_script( 'slim-bootstrap', get_template_directory_uri() . '/dist/js/jquery-3.2.1.slim.min.js', array( 'jquery' ), '4.3.1', false );
		//wp_enqueue_script( 'popper-bootstrap', get_template_directory_uri() . '/dist/js/popper.min.js', array( 'jquery' ), '4.3.1', false );
		//wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/dist/js/bootstrap.min.js', array( 'jquery' ), '4.3.1', false );
		//wp_enqueue_script( 'overhang', get_template_directory_uri() . '/dist/js/overhang/overhang.min.js', array( 'jquery' ), '1.12.1', false );
		//wp_enqueue_script( 'jCarousel', get_template_directory_uri() . '/dist/js/jquery.jcarousel.min.js', array( 'jquery' ), '0.0.3', false );
		//wp_enqueue_script( 'slim-scroll', get_template_directory_uri() . '/dist/js/jquery.slimscroll.min.js', array( 'jquery' ), '1.1.3', false );
		//wp_enqueue_script( 'app', get_template_directory_uri() . '/dist/js/app.min.js', array( 'jquery' ), WP_THEME_Helper::get_theme_info( 'Version' ), false );

		// localize Javascript Variable
		$localize = array(
			'app_url' => home_url(),
			'token'   => wp_create_nonce( 'wp_rest' ),
			'page'    => WP_THEME_Helper::this_page_url()
		);

		wp_localize_script( 'app', 'app_config', $localize );
	}

	public function disable_comment_js() {
		wp_deregister_script( 'comment-reply' );
		wp_deregister_script( 'front_end_script.js' );
	}

	function remove_block_css() {
		wp_dequeue_style( 'wp-block-library' ); // Wordpress core
		wp_dequeue_style( 'wp-block-library-theme' ); // Wordpress core
		wp_dequeue_style( 'wc-block-style' ); // WooCommerce
		wp_dequeue_style( 'storefront-gutenberg-blocks' ); // Storefront theme
	}

}

new WP_THEME_HEAD;
