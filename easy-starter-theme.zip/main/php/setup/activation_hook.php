<?php

class WP_THEME_ACTIVATION_HOOK {

	public function __construct() {
		add_action( "after_switch_theme", array( $this, 'create_table' ) );
	}

	public function create_table() {
		global $wpdb;

		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		$table_name = $wpdb->prefix . "translations";
//		$sql        = "CREATE TABLE $table_name (
//		      id int(10) unsigned NOT NULL AUTO_INCREMENT,
//		      identifier varchar(255) NOT NULL,
//		      translation varchar(255) NOT NULL,
//		      lang varchar(5) NOT NULL,
//		      notes varchar(255) DEFAULT NULL,
//		      PRIMARY KEY  (id),
//		      KEY Index_2 (lang),
//		      KEY Index_3 (identifier)
//		    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
//
//		dbDelta( $sql );
	}

}

new WP_THEME_ACTIVATION_HOOK;