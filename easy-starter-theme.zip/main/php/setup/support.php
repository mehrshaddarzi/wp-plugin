<?php

class WP_THEME_SUPPORT {

	public function __construct() {

		// Add Feed Link
		add_action( 'after_setup_theme', array( $this, 'support' ) );

		// Use Parent Category Template For Sub category
		add_action( 'template_redirect', array( $this, 'cat_template' ) );

		// Add Custom Image Size
		add_action( 'init', array( $this, 'wpse4378_add_new_image_size' ) );

	}

	public function wpse4378_add_new_image_size() {
		//add_image_size( 'thumb-600-400', 600, 400, true ); //mobile
	}

	public function support() {

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		// disable comments feed
		add_filter( 'feed_links_show_comments_feed', '__return_false' );

		// Support Title Tag
		add_theme_support( 'title-tag' );

		//Add Walker Comment Html5
		add_theme_support( 'html5', array( 'comment-list' ) );

		//Create Nav Menu
		register_nav_menu( 'home_top_menu', 'Top Menu' );
		register_nav_menu( 'footer_menu', 'Footer Menu' );
	}

	public function cat_template() {
		if ( is_category() ) {
			$catid = get_query_var( 'cat' );
			if ( file_exists( TEMPLATEPATH . '/category-' . $catid . '.php' ) ) {
				include( TEMPLATEPATH . '/category-' . $catid . '.php' );
				exit;
			}
			$cat    = &get_category( $catid );
			$parent = $cat->category_parent;
			while ( $parent ) {
				$cat = &get_category( $parent );
				if ( file_exists( TEMPLATEPATH . '/category-' . $cat->cat_ID . '.php' ) ) {
					include( TEMPLATEPATH . '/category-' . $cat->cat_ID . '.php' );
					exit;
				}
				$parent = $cat->category_parent;
			}
		}
	}

}

new WP_THEME_SUPPORT;