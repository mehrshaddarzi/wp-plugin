<?php
// Don't call the file directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Register thumbnail sizes.
 *
 * @return void
/**
 * Category Posts Widget Class
 *
 * Shows the single category posts with some configurable options
 */
class MyFav extends WP_Widget {

    public function __construct() {
        $widget_ops = array('classname' => 'wp', 'description' => __('به چه موضوعی علاقه مندی'));        //$this->WP_Widget( 'dokan-category-menu', 'Dokan: Product Category', $widget_ops );
        parent::__construct('alaghemandi', 'به چه موضوعی علاقه مندی', $widget_ops  );
    }

	// Displays category posts widget on blog.
	function widget($args, $instance) {
			global $post;
		$post_old = $post; // Save the post object.
		
		extract( $args );
		

		echo $before_widget;
		// Widget title
		$title = apply_filters( 'widget_title', $instance['title'] );
		if ( ! empty( $title ) )
		echo $args['before_title'] . $title . $args['after_title'];
		
        
        
        echo '<ul class="tag_fav_widget">';
    
for($i=1; $i<=10; $i++) {
   if(wp_get_option('theme_setting_index', 'fav_title_'.$i) !="") {
        echo '<li><a href="'.wp_get_option('theme_setting_index', 'fav_link_'.$i).'" title="'.wp_get_option('theme_setting_index', 'fav_title_'.$i).'"># '.str_replace(" ", "_" , wp_get_option('theme_setting_index', 'fav_title_'.$i)).'</a></li>';
   }
}
                
echo '
</ul>';
        
        
        
		


		echo $after_widget;
	}

	/**
	 * Update the options
	 *
	 * @param  array $new_instance
	 * @param  array $old_instance
	 * @return array
	 */
	function update($new_instance, $old_instance) {
	$instance = array();
	
	$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
	//$instance['cat'] = ( ! empty( $new_instance['cat'] ) ) ? strip_tags( $new_instance['cat'] ) : '';
	//$instance['num'] = ( ! empty( $new_instance['num'] ) ) ? strip_tags( $new_instance['num'] ) : '';
	//$instance['sort'] = ( ! empty( $new_instance['sort'] ) ) ? strip_tags( $new_instance['sort'] ) : '';
	//$instance['show-thumbail'] = ( ! empty( $new_instance['show-thumbail'] ) ) ? strip_tags( $new_instance['show-thumbail'] ) : '';
				
		return $new_instance;
	}

	/**
	 * The widget configuration form back end.
	 *
	 * @param  array $instance
	 * @return void
	 */
	function form($instance) {
		$instance = wp_parse_args( ( array ) $instance, array(
			'title'          => null,
			//'cat'			 => null,
			//'num'            => null,
			//'sort_by'        => __( '' ),
			//'asc_sort_order' => __( '' ),
			//'show-thumbail' => null,
			//'sort' => null,
			//'title_link'	 => __( '' ),
			//'excerpt'        => __( '' ),
			//'excerpt_length' => __( '' ),
			//'comment_num'    => __( '' ),
			//'date'           => __( '' )
			//'thumb'          => __( '' ),
			//'thumb_w'        => __( '' ),
			//'thumb_h'        => __( '' )
		) );

		$title          = $instance['title'];
		//$cat 			= $instance['cat'];
		//$num            = $instance['num'];
		//$sort_by        = $instance['sort_by'];
		//$asc_sort_order = $instance['asc_sort_order'];
		//$show_thumbail = $instance['show-thumbail'];
		//$sort = $instance['sort'];
		//$title_link		= $instance['title_link'];		
		//$excerpt        = $instance['excerpt'];
		//$excerpt_length = $instance['excerpt_length'];
		//$comment_num    = $instance['comment_num'];
		//$date           = $instance['date'];
	//	$thumb          = $instance['thumb'];
		//$thumb_w        = $instance['thumb_w'];
		//$thumb_h        = $instance['thumb_h'];
				
			?>
			<p>
				<label for="<?php echo $this->get_field_id("title"); ?>">
					نام بلوک :
					<input class="widefat" id="<?php echo $this->get_field_id("title"); ?>" name="<?php echo $this->get_field_name("title"); ?>" type="text" value="<?php echo esc_attr($instance["title"]); ?>" />
				</label>
			</p>
			
			<?php

		}

}

add_action( 'widgets_init', create_function('', 'return register_widget("MyFav");') );