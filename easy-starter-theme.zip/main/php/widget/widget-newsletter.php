<?php
// Don't call the file directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Register thumbnail sizes.
 *
 * @return void
/**
 * Category Posts Widget Class
 *
 * Shows the single category posts with some configurable options
 */
class MYNEWSLETTER extends WP_Widget {

    public function __construct() {
        $widget_ops = array('classname' => 'wp', 'description' => __('خبرنامه'));        //$this->WP_Widget( 'dokan-category-menu', 'Dokan: Product Category', $widget_ops );
        parent::__construct('widnewsletter', 'خبرنامه', $widget_ops  );
    }

	// Displays category posts widget on blog.
	function widget($args, $instance) {
			global $post;
		$post_old = $post; // Save the post object.
		
		extract( $args );
		

		echo $before_widget;
		// Widget title
		$title = apply_filters( 'widget_title', $instance['title'] );
		if ( ! empty( $title ) )
		echo $args['before_title'] . $title . $args['after_title'];
		
        echo '<div class="widget-newsletter">';
        
        echo wp_get_option('theme_setting_index', 'newsletter_text_widget');
        
        echo '
        <div class="wpmlr_subscription">
            <form action="#" class="wpmlr_form" data-form="newsletter_form">
                <p class="wpmlr_input_container">
                    <label for="wpmlr_email_field">نام شما:</label>
                    <input name="wp_mailerlite_name_widget" autocomplete="off" type="text" class="wpmlr_input_name form-control rtl text-right" placeholder="نام و نام خانوادگی">
                </p>
                <p class="wpmlr_input_container">
                    <label for="wpmlr_email_field">آدرس ایمیل شما:</label>
                    <input name="wp_mailerlite_mail_widget" autocomplete="off" type="text" class="wpmlr_input_email form-control" placeholder="پست الکترونیکی">
                </p>
                <input type="hidden" name="where_from_widget" value="'.wp_theme_where_from().'">
                <p class="wpmlr_submit_container"> <button type="submit" id="send_newsletter_widget" class="button btn wpmlr_btn">اشتراک در خبرنامه</button> </p>
            </form>
        </div>

        ';

        
        
        echo '</div>';

		echo $after_widget;
	}

	/**
	 * Update the options
	 *
	 * @param  array $new_instance
	 * @param  array $old_instance
	 * @return array
	 */
	function update($new_instance, $old_instance) {
	$instance = array();
	
	$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
	//$instance['cat'] = ( ! empty( $new_instance['cat'] ) ) ? strip_tags( $new_instance['cat'] ) : '';
	//$instance['num'] = ( ! empty( $new_instance['num'] ) ) ? strip_tags( $new_instance['num'] ) : '';
	//$instance['sort'] = ( ! empty( $new_instance['sort'] ) ) ? strip_tags( $new_instance['sort'] ) : '';
	//$instance['show-thumbail'] = ( ! empty( $new_instance['show-thumbail'] ) ) ? strip_tags( $new_instance['show-thumbail'] ) : '';
				
		return $new_instance;
	}

	/**
	 * The widget configuration form back end.
	 *
	 * @param  array $instance
	 * @return void
	 */
	function form($instance) {
		$instance = wp_parse_args( ( array ) $instance, array(
			'title'          => null,
			//'cat'			 => null,
			//'num'            => null,
			//'sort_by'        => __( '' ),
			//'asc_sort_order' => __( '' ),
			//'show-thumbail' => null,
			//'sort' => null,
			//'title_link'	 => __( '' ),
			//'excerpt'        => __( '' ),
			//'excerpt_length' => __( '' ),
			//'comment_num'    => __( '' ),
			//'date'           => __( '' )
			//'thumb'          => __( '' ),
			//'thumb_w'        => __( '' ),
			//'thumb_h'        => __( '' )
		) );

		$title          = $instance['title'];
		//$cat 			= $instance['cat'];
		//$num            = $instance['num'];
		//$sort_by        = $instance['sort_by'];
		//$asc_sort_order = $instance['asc_sort_order'];
		//$show_thumbail = $instance['show-thumbail'];
		//$sort = $instance['sort'];
		//$title_link		= $instance['title_link'];		
		//$excerpt        = $instance['excerpt'];
		//$excerpt_length = $instance['excerpt_length'];
		//$comment_num    = $instance['comment_num'];
		//$date           = $instance['date'];
	//	$thumb          = $instance['thumb'];
		//$thumb_w        = $instance['thumb_w'];
		//$thumb_h        = $instance['thumb_h'];
				
			?>
			<p>
				<label for="<?php echo $this->get_field_id("title"); ?>">
					نام بلوک :
					<input class="widefat" id="<?php echo $this->get_field_id("title"); ?>" name="<?php echo $this->get_field_name("title"); ?>" type="text" value="<?php echo esc_attr($instance["title"]); ?>" />
				</label>
			</p>
			
			<?php

		}

}

add_action( 'widgets_init', create_function('', 'return register_widget("MYNEWSLETTER");') );