<?php
// Don't call the file directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Register our styles
 *
 * @return void
 */
//add_action( 'wp_enqueue_scripts', 'category_posts_widget_styles' );


/**
 * Category Posts Widget Class
 *
 * Shows the single category posts with some configurable options
 */
class CategoryPosts extends WP_Widget {

    public function __construct() {
        $widget_ops = array('classname' => 'wp', 'description' => __('نمایش مطالب از دسته خاص'));        //$this->WP_Widget( 'dokan-category-menu', 'Dokan: Product Category', $widget_ops );
        parent::__construct('category-posts', 'نمایش گروهی مطالب دسته', $widget_ops  );
    }

	// Displays category posts widget on blog.
	function widget($args, $instance) {
			global $post;
		$post_old = $post; // Save the post object.
		
		extract( $args );
		

		echo $before_widget;
		// Widget title
		$title = apply_filters( 'widget_title', $instance['title'] );
		if ( ! empty( $title ) )
		echo $args['before_title'] . $title . $args['after_title'];
		
		
		// Get array of post info.
$args = array (
	'cat' => $instance["cat"],
	'posts_per_page' => $instance["num"],
	'order'  => 'DESC',
	'orderby' => $instance["sort"]
);

// The Query
$query = new WP_Query( $args );
$q = 0;


		if ($instance["show-thumbail"] =="خیر") {
		
		// Post list
		echo "<ul class='list-line'>\n";
		
		while ($query->have_posts()):
		$query->the_post();
		$animation = 1 + ($q * 0.2);
		echo '<li><i class="fa fa-angle-left"></i><a href="'.get_permalink($post->ID).'" title="'.get_the_title().'">'.per_number ( get_the_title() ).' '.(get_field("vip") =="بله" ? '<span class="label label-warning" style="vertical-align: middle;">ویژه</span>' : '').'</a></li>'."\n";
		//echo '<li class="wow fadeInLeft" data-wow-delay="'.$animation.'s"><i class="fa fa-angle-left"></i><a href="'.get_permalink($post->ID).'" title="'.get_the_title().'">'.get_the_title().' '.(get_field("vip") =="بله" ? '<span class="label label-warning" style="vertical-align: middle;">ویژه</span>' : '').'</a></li>'."\n";
		
		$q++;
		endwhile;

		
		echo "</ul><div class='clearfix'></div>\n";
		
		} elseif ($instance["show-thumbail"] =="سمت راست عنوان") { //Show with thumbail
			
			
	echo "<ul class='list-line-thumbail'>\n";
	
		while ($query->have_posts()):
		$query->the_post();
			$img = placeholdit(60,60);
			if ( has_post_thumbnail() ) {
			$thumb = wp_get_attachment_image_src( get_post_thumbnail_id(), 'thumb-60');
			$img = $thumb[0];
          $img_alt = (wp_get_attachment( get_post_thumbnail_id() )['alt'] =="" ? get_the_title() : wp_get_attachment( get_post_thumbnail_id() )['alt']);

			}


			/*Title*/
$character = 70;
if (mb_strlen(get_the_title()) >=$character) { $moref =" .."; } else { $moref=""; }

            
            
            //Post Model
$l = '';
$post_model = get_post_meta(get_the_ID(), 'wp_model_post', true);
if( $post_model =="ویدئو" ) { $l =  '<span class="label label-danger lb">ویدئو</span>'; }
if( $post_model =="اینفوگرافیک" ) { $l = '<span class="label label-success lb">اینفوگرافیک</span>'; }
if( $post_model =="پادکست" ) { $l = '<span class="label label-primary lb">پادکست</span>'; }
            
            
        echo '<li>
        <div class="pull-right"><img data-src="'.$img.'" alt="'.$img_alt.'"></div>
        <a href="'.get_permalink($post->ID).'" target="_blank" title="'.get_the_title().'">'.mb_substr(get_the_title(), 0, $character).$moref.' '.$l.'</a>

        <div class="clearfix"></div>
        </li>
        ';
			
			$q++;
		endwhile;
		echo "</ul>\n";
			
		} else { //شاخص بالای سایت
			
			echo "<ul class='list-line-thumbail-top'>\n";
	
            $l = '';
$post_model = get_post_meta(get_the_ID(), 'wp_model_post', true);
if( $post_model =="ویدئو" ) { $l =  '<span class="label label-danger lb">ویدئو</span>'; }
if( $post_model =="اینفوگرافیک" ) { $l = '<span class="label label-success lb">اینفوگرافیک</span>'; }
if( $post_model =="پادکست" ) { $l = '<span class="label label-primary lb">پادکست</span>'; }
          
            
            
		while ($query->have_posts()):
		$query->the_post();
			$animation = 1 + ($q * 0.2);
			$img = placeholdit(200,120);
			if ( has_post_thumbnail() ) {
			$thumb = wp_get_attachment_image_src( get_post_thumbnail_id(), 'thumb-200');
			$img = $thumb[0];
          $img_alt = (wp_get_attachment( get_post_thumbnail_id() )['alt'] =="" ? get_the_title() : wp_get_attachment( get_post_thumbnail_id() )['alt']);

			}

			/*Title*/
            $character = 110;
            if (mb_strlen(get_the_title()) >=$character) { $moref =" .."; } else { $moref=""; }



			echo '<li>
            <a href="'.get_permalink($post->ID).'" target="_blank" title="'.get_the_title().'">
			<img data-src="'.$img.'" alt="'.$img_alt.'" class="img-responsive">
            </a>
			<a href="'.get_permalink($post->ID).'" target="_blank" title="'.get_the_title().'">'.mb_substr(get_the_title(), 0, $character).$moref.' '.$l.'</a>
						
			<div class="clearfix"></div>
			</li>
			';
			
			$q++;
		endwhile;
		echo "</ul>\n";
			
			
			
			
			
			
			
		}
		
	
	wp_reset_postdata();

		echo $after_widget;
	}

	/**
	 * Update the options
	 *
	 * @param  array $new_instance
	 * @param  array $old_instance
	 * @return array
	 */
	function update($new_instance, $old_instance) {
	$instance = array();
	
	$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
	$instance['cat'] = ( ! empty( $new_instance['cat'] ) ) ? strip_tags( $new_instance['cat'] ) : '';
	$instance['num'] = ( ! empty( $new_instance['num'] ) ) ? strip_tags( $new_instance['num'] ) : '';
	$instance['sort'] = ( ! empty( $new_instance['sort'] ) ) ? strip_tags( $new_instance['sort'] ) : '';
	$instance['show-thumbail'] = ( ! empty( $new_instance['show-thumbail'] ) ) ? strip_tags( $new_instance['show-thumbail'] ) : '';
				
		return $new_instance;
	}

	/**
	 * The widget configuration form back end.
	 *
	 * @param  array $instance
	 * @return void
	 */
	function form($instance) {
		$instance = wp_parse_args( ( array ) $instance, array(
			'title'          => null,
			'cat'			 => null,
			'num'            => null,
			//'sort_by'        => __( '' ),
			//'asc_sort_order' => __( '' ),
			'show-thumbail' => null,
			'sort' => null,
			//'title_link'	 => __( '' ),
			//'excerpt'        => __( '' ),
			//'excerpt_length' => __( '' ),
			//'comment_num'    => __( '' ),
			//'date'           => __( '' )
			//'thumb'          => __( '' ),
			//'thumb_w'        => __( '' ),
			//'thumb_h'        => __( '' )
		) );

		$title          = $instance['title'];
		$cat 			= $instance['cat'];
		$num            = $instance['num'];
		//$sort_by        = $instance['sort_by'];
		//$asc_sort_order = $instance['asc_sort_order'];
		$show_thumbail = $instance['show-thumbail'];
		$sort = $instance['sort'];
		//$title_link		= $instance['title_link'];		
		//$excerpt        = $instance['excerpt'];
		//$excerpt_length = $instance['excerpt_length'];
		//$comment_num    = $instance['comment_num'];
		//$date           = $instance['date'];
	//	$thumb          = $instance['thumb'];
		//$thumb_w        = $instance['thumb_w'];
		//$thumb_h        = $instance['thumb_h'];
				
			?>
			<p>
				<label for="<?php echo $this->get_field_id("title"); ?>">
					نام بلوک :
					<input class="widefat" id="<?php echo $this->get_field_id("title"); ?>" name="<?php echo $this->get_field_name("title"); ?>" type="text" value="<?php echo esc_attr($instance["title"]); ?>" />
				</label>
			</p>
			
			<p>
				<label>
					انتخاب دسته :
					<?php wp_dropdown_categories( array( 'name' => $this->get_field_name("cat"), 'hide_empty' => 0,
    'hierarchical' => true,
    'depth'  => 2, 'selected' => $instance["cat"] ) ); ?>
				</label>
			</p>
			
			<p>
				<label for="<?php echo $this->get_field_id("num"); ?>">
					تعداد نمایش پست :
					<input style="text-align: center;" id="<?php echo $this->get_field_id("num"); ?>" name="<?php echo $this->get_field_name("num"); ?>" type="text" value="<?php echo absint($instance["num"]); ?>" size='3' />
				</label>
			</p>
			
			<p>
				<label for="<?php echo $this->get_field_id("sort"); ?>">
					نحوه ی نمایش :
					<select id="<?php echo $this->get_field_id("sort"); ?>" name="<?php echo $this->get_field_name("sort"); ?>">
					  <option value="id"<?php selected( $instance["sort"], "id" ); ?>>نمایش از مطالب آخر</option>
					  <option value="rand"<?php selected( $instance["sort"], "rand" ); ?>>بصورت تصادفی</option>
					</select>
				</label>
			</p>
			
				<p>
				<label for="<?php echo $this->get_field_id("show-thumbail"); ?>">
					نمایش تصویر شاخس :
					<select id="<?php echo $this->get_field_id("show-thumbail"); ?>" name="<?php echo $this->get_field_name("show-thumbail"); ?>">
					  <option value="خیر"<?php selected( $instance["show-thumbail"], "خیر" ); ?>>خیر</option>
					  <option value="سمت راست عنوان"<?php selected( $instance["show-thumbail"], "سمت راست عنوان" ); ?>>سمت راست عنوان</option>
					  <option value="بالای عنوان"<?php selected( $instance["show-thumbail"], "بالای عنوان" ); ?>>بالای عنوان</option>
					</select>
				</label>
			</p>


			<?php

		}

}

add_action( 'widgets_init', create_function('', 'return register_widget("CategoryPosts");') );