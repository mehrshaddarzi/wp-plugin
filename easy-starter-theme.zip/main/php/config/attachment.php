<?php

//Get Attachemnt info
function wp_get_attachment( $attachment_id ) {
$attachment = get_post( $attachment_id );
return array(
    'alt' => get_post_meta( $attachment->ID, '_wp_attachment_image_alt', true ),
    'caption' => $attachment->post_excerpt,
    'description' => $attachment->post_content,
    'href' => get_permalink( $attachment->ID ),
    'src' => $attachment->guid,
    'title' => $attachment->post_title
);
}

/*change size upload*/
function filter_site_upload_size_limit( $size ) {
    $size = 1024 * 50000;
    return $size;
}
add_filter( 'upload_size_limit', 'filter_site_upload_size_limit', 20 );

/*Change image Quality*/
add_filter( 'jpeg_quality', create_function( '', 'return 85;' ) );


/*Add post thumbail Support */
add_theme_support( 'post-thumbnails' );

add_filter( 'intermediate_image_sizes_advanced', 'prefix_remove_default_images' );
// Remove default image sizes here. 
function prefix_remove_default_images( $sizes ) {
 unset( $sizes['medium']); // 300px
 unset( $sizes['medium_large']); // 1024px
 unset( $sizes['large']); // 768px

 return $sizes;
}

/* List Image Size */
function wpdocs_theme_setup() {

	add_image_size( 'thumb-60', 60, 60, true); //user_thumbnail and postrelated
	add_image_size( 'thumb-200', 200, 120, true); //post thumbnail for widget
	add_image_size( 'thumb-350', 350, 250, true); //post thumbnail in category page
	add_image_size( 'thumb-950', 950, 9999, true); //post wallpaper in single

   // add_image_size( 'thumb-150', 150, 150, true ); //wordpress thumbail
    //add_image_size( 'thumb-editor', 500, 9999, true );

    remove_image_size('medium');
    remove_image_size('medium_large');
    remove_image_size('large');
}
add_action( 'init', 'wpdocs_theme_setup');


/*Get image Path by id/image_size*/
 function wp_get_image_path($attachment_id, $size = 'thumbnail') {
    $file = get_attached_file($attachment_id, true);
    if (empty($size) || $size === 'full') {
        // for the original size get_attached_file is fine
        return realpath($file);
    }
    if (! wp_attachment_is_image($attachment_id) ) {
        return false; // the id is not referring to a media
    }
    $info = image_get_intermediate_size($attachment_id, $size);
    if (!is_array($info) || ! isset($info['file'])) {
        return false; // probably a bad size argument
    }

    return realpath(str_replace(wp_basename($file), $info['file'], $file));
}

/*Get list image size site*/
function wp_get_list_image_size() {
	global $_wp_additional_image_sizes;
	$sizes = array();
	foreach ( get_intermediate_image_sizes() as $_size ) {
		if ( in_array( $_size, array('thumbnail', 'medium', 'medium_large', 'large') ) ) {
			$sizes[] = $_size;
		} elseif ( isset( $_wp_additional_image_sizes[ $_size ] ) ) {
			$sizes[] = $_size;
		}
	}
	return $sizes;
}


/*Wp Remove image Without image_size */
function wp_remove_attachment_size_from_id($attachment_id, $size) {
   foreach(wp_get_list_image_size() as $image_size) {
       if($image_size !="thumbnail" and $image_size !=$size) {
                unlink(wp_get_image_path($attachment_id, $image_size));
            } 
       }
}