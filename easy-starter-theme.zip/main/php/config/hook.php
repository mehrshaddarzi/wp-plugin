<?php

//Content filter
require_once ('hook/content.php');

//Admin Wordpress Core
require_once ('hook/admin-core.php');

//Walker Menu
require_once ('walker/wordpress-menu-walker.php');

//Botstrap Framework Hook
require_once ('bootstrap/wp_bootstrap_breadcrumbs.php');
require_once ('bootstrap/wp_page_navi.php');
require_once ('bootstrap/wp_bootstrap_comment.php');

//comment
require_once ('hook/comment.php');