<?php
//Remover icon wordpress Admin bar
function annointed_admin_bar_remove() {
        global $wp_admin_bar;
        $wp_admin_bar->remove_menu('wp-logo');
}
add_action('wp_before_admin_bar_render', 'annointed_admin_bar_remove', 0);

//Delete Help Wrap Admin
function hide_help() {
    echo '<style type="text/css">
            #contextual-help-link-wrap { display: none !important; }
    </style>';
}
add_action('admin_head', 'hide_help');

// Delete Wordpress Dashboard Index Admin
add_action('wp_dashboard_setup', 'wpc_dashboard_widgets');
function wpc_dashboard_widgets() {
	global $wp_meta_boxes;
	// Today widget
	unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_right_now']);
	//Wordpress News
	unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_primary']);
	// Last comments
	unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_recent_comments']);
	// Incoming links
	unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_incoming_links']);
	// Plugins
	unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_plugins']);
}

//Remove  WordPress Welcome Panel
remove_action('welcome_panel', 'wp_welcome_panel');

//Delete Word Wordpress from admin title
add_filter('admin_title', 'my_admin_title', 10, 2);
function my_admin_title($admin_title, $title) { return get_bloginfo('name').' &bull; '.$title; }

//Remove comment inline Css
function twentyten_remove_recent_comments_style() {
global $wp_widget_factory;
remove_action( 'wp_head', array( $wp_widget_factory->widgets['WP_Widget_Recent_Comments'], 'recent_comments_style' ) );
}
add_action( 'widgets_init', 'twentyten_remove_recent_comments_style' );

//*Remove Comment from Admin bar
function remove_admin_bar_links() {
    global $wp_admin_bar;
    $wp_admin_bar->remove_menu('comments');         // Remove the comments link
}
add_action( 'wp_before_admin_bar_render', 'remove_admin_bar_links' );

// Hide Admin Page From Admin
/*add_filter( 'parse_query', 'exclude_pages_from_admin' );
function exclude_pages_from_admin($query) {
    global $pagenow,$post_type;
    if (is_admin() && $pagenow=='edit.php' && $post_type =='page') {
        $query->query_vars['post__not_in'] = array(PAGE_NOT_SHOW);
    }
}*/

/* Hide Admin Category From Admin
add_action( 'admin_init', 'wpse_55202_do_terms_exclusion' );
function wpse_55202_do_terms_exclusion() {
    if( current_user_can('administrator') )
        add_filter( 'list_terms_exclusions', 'wpse_55202_list_terms_exclusions', 10, 2 );
}
function wpse_55202_list_terms_exclusions($exclusions,$args) {
	
	if (!empty(HIDE_CAT_ADMIN)) {
		$array = explode(',',HIDE_CAT_ADMIN);
		$term = "";
		foreach ($array as $value) {
		$term .= " AND ( t.term_id <> $value )";
		}
	}
	
 return $exclusions . $term;
}*/

//Remove Tools Menu item
//add_action( 'admin_menu', 'wpse26980_remove_tools', 99 );
//function wpse26980_remove_tools() { remove_menu_page( 'tools.php' ); }

//Block Category Delete
//include('block-category-delete.php');