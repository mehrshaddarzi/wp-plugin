<?php

/*Show Comment Post Result*/
/*add_action( 'comment_post', 'save_comment_meta_data' );
function save_comment_meta_data( $comment_id ) {
	$comment_id = get_comment( $comment_id ); 
    $comment_post_id = $comment_id->comment_post_ID;
	$comment_author = $comment_id->comment_author;
	if (!is_admin()) {
		$arg='';
		$arg['bw_author_comment'] = rawurlencode($comment_author);
		$arg['bw_send_comment'] = 'yes';
		$url =get_post_permalink( $comment_post_id);
		wp_redirect( add_query_arg( $arg, $url) );
		exit;
	}
}*/

//Show result commet
add_action('wp_head',function(){	
	if (isset($_GET['bw_send_comment'])) {
		echo '
		<script>
		jQuery(document).ready(function(){
			jQuery("body").overhang({
			  type: "success",
			  message: "'.$_GET['bw_author_comment'].' نظر ارزشمند شما با موفقیت دریافت شد",
			closeConfirm: true
			});	
		});
		</script>
		';	
	}	
});

/*No follow All link */
function wpsnipp_all_links_nofollow_comment( $comment_text ){
    $content = str_replace( '<a', '<a rel="nofollow" ', $comment_text );
	return $content;
}
add_filter( 'comment_text', 'wpsnipp_all_links_nofollow_comment' );


/* Send Comment Ajax */
add_action( 'wp_ajax_wp_theme_commentform_ajax', 'wp_theme_commentform_ajax' );
add_action( 'wp_ajax_nopriv_wp_theme_commentform_ajax', 'wp_theme_commentform_ajax' );
function wp_theme_commentform_ajax()
{
        global $wpdb;
        if ( isset($_POST) && defined('DOING_AJAX') && DOING_AJAX ) {

            //Check Admin Reffer
            check_ajax_referer( 'wp_theme_token', 'token' );
            
            $result = array();
            $result['error'] = 'yes'; //Defautl is Error
            $result['text'] = '';
            
            
             //Check Empty comment Text
            if(  trim( $_POST['comment_text'] ) =="" ) {
                $result['text'] = 'لطفا متن نظر خود را وارد نمایید'; 
                json_exit($result);
            }
            
            
             //Check Empty Name Or email
            if ( is_user_logged_in() ===false ) {
                
                if(  trim( $_POST['author'] ) =="" || trim( $_POST['email'] ) =="" ) {
                    $result['text'] = 'لطفا نام و یا ایمیل را وارد نمایید'; 
                    json_exit($result);
                }
                
                  //Persian Character
                if( check_persian_input(trim( $_POST['author'] )) ===false ) {
                    $result['text'] = 'نام و نام خانوادگی خود را فارسی وارد کنید'; 
                    json_exit($result);
                }

                //Check Email valid
                if( is_email( trim( $_POST['email'] ) ) ===false ) {
                     $result['text'] = 'لطفا ایمیل را با دقت وارد نمایید'; 
                    json_exit($result);
                }
 
            }
            
        
            $user_id = 0;
            if ( is_user_logged_in() ) {
                
                $author_name = wp_acl_user_fullname();
                if ( is_user_login_with_mobile() ===true ) { $author_mail = "nobody@gmail.com"; } else { $author_mail = wp_acl_get_userdata('user_email'); } 
                $user_id = get_current_user_id();
                
            } else {
                
                $author_name = sanitize_text_field($_POST['author']);
                $author_mail = sanitize_email($_POST['email']);
                
            }
            

            $commentdata = array(
                'comment_post_ID' => $_POST['comment_post_ID'], // to which post the comment will show up
                'comment_author' => $author_name, //fixed value - can be dynamic 
                'comment_author_email' => $author_mail, //fixed value - can be dynamic 
                'comment_author_url' => '', 
                'comment_content' => trim( $_POST['comment_text'] ),
                'comment_type' => '',
                'comment_parent' => $_POST['comment_parent'],
                'user_id' => $user_id
            );
            //Insert new comment and get the comment ID
            $comment_id = wp_new_comment( $commentdata );
            
            

            $result['error'] = 'no';
            $result['text'] = 'نظر ارزشمند شما با موفقیت ثبت شده و بعد از تایید مدیریت به نمایش در می آید'; 
            json_exit($result);
            
            //get_included_files()
            //get_option('active_plugins')
            //['count_included' => count(get_included_files())]
            //wp_send_json();
            //exit;
        }
        die();
}