<?php

/*Disable Main query For Custom Page*/
add_filter( 'posts_pre_query', function ( $posts, \WP_Query $q ) {
	if ( $q->is_home() && $q->is_main_query() ) {
		$posts          = [];
		$q->found_posts = 0;
	}
	return $posts;
}, 10, 2 );

/*Number post per page*/
function custom_posts_per_page( $query ) {
	global $wp_theme_config;
	if ( is_admin() === false ) {
		if ( is_home() ) {
			if ( $query->is_main_query() ) {
				$query->set( 'posts_per_page', $wp_theme_config['pre_get_post']['home'] );
			}
		}
		if ( is_search() && $query->is_main_query() ) {
			$query->set( 'posts_per_page', $wp_theme_config['pre_get_post']['search'] );
		}
		if ( is_archive() && $query->is_main_query() ) {
			$query->set( 'posts_per_page', $wp_theme_config['pre_get_post']['archive'] );
		}
		if ( is_category() && $query->is_main_query() ) {
			$query->set( 'posts_per_page', $wp_theme_config['pre_get_post']['category'] );
		}
		if ( is_product_category() && $query->is_main_query() ) {
			$query->set( 'posts_per_page', 16 );
		}
	}
}
//add_action( 'pre_get_posts', 'custom_posts_per_page' );

/* add image respnsive class */
function add_image_responsive_class( $content ) {
	global $post;

		//Add img responsive
		$pattern     = "/<img(.*?)class=\"(.*?)\"(.*?)>/i";
		$replacement = '<img$1class="$2 img-responsive"$3>';
		$content     = preg_replace( $pattern, $replacement, $content );

		//add Lazy Load
		$content = preg_replace( "/<img(.*?)(src=|srcset=)(.*?)>/i", '<img$1data-$2$3>', $content );

		//-- Add .lazy-load class to each image that already has a class.
		//$content = preg_replace('/<img(.*?)class=\"(.*?)\"(.*?)>/i', '<img$1class="$2 lazy-load"$3>', $content);

		//-- Add .lazy-load class to each image that doesn't have a class.
		//$content = preg_replace('/<img(.*?)(?!\bclass\b)(.*?)/i', '<img$1 class="lazy-load"$2', $content);

	return $content;
}

add_filter( 'the_content', 'add_image_responsive_class' );

/* Disable Nopreper */
function tinymce_allow_unsafe_link_target( $mceInit ) {
	$mceInit['allow_unsafe_link_target'] = true;
	return $mceInit;
}

/* add rel auto to href */
function wpex_auto_add_link_titles( $content ) {

	// No need to do anything if there isn't any content
	if ( empty( $content ) ) {
		return $content;
	}

	// Define links array
	$links = array();

	// Get page content
	$html = new DomDocument;
	libxml_use_internal_errors( true );
	$html->loadHTML( mb_convert_encoding( $content, 'HTML-ENTITIES', 'UTF-8' ) );
	$html->preserveWhiteSpace = false;

	// Loop through all content links
	foreach ( $html->getElementsByTagName( 'a' ) as $link ) {

		// If the title attribute is already defined no need to do anything
		if ( ! empty( $link->getAttribute( 'title' ) ) ) {
			continue;
		}

		// Get link text
		$link_text = $link->textContent;

		// Save links and link text in $links array
		if ( $link_text ) {
			$links[ $link_text ] = $link->getAttribute( 'href' );
		}

	}

	// Loop through links array and update post content to add link titles
	if ( ! empty( $links ) ) {
		foreach ( $links as $text => $link ) {
			if ( $link && $text ) {
				//$text    = esc_attr( $text ); // Sanitize
				//$text    = ucwords( $text );  // Captilize words (looks better imo)
				$replace = $link . '" title="' . $text . '"'; // Add title to link
				$content = str_replace( $link . '"', $replace, $content ); // Replace post content
			}

		}
	}

	// Return post content
	return $content;

}

add_filter( 'the_content', 'wpex_auto_add_link_titles' );


//Bootstrap Table auto add_action
add_filter( 'the_content', 'wpse8170_add_custom_table_class' );
function wpse8170_add_custom_table_class( $content ) {
	return str_replace( '<table', '<table class="table table-bordered table-striped table-hover" ', $content );
}


//Only 4 row for gallery
add_action( 'wp_enqueue_media', 'mgzc_media_gallery_zero_columns' );
function mgzc_media_gallery_zero_columns() {
	add_action( 'admin_print_footer_scripts', 'mgzc_media_gallery_zero_columns_script', 999 );
}

function mgzc_media_gallery_zero_columns_script() {
	?>
    <script type="text/javascript">
        jQuery(function () {
            if (wp.media.view.Settings.Gallery) {
                wp.media.view.Settings.Gallery = wp.media.view.Settings.extend({
                    className: "collection-settings gallery-settings",
                    template: wp.media.template("gallery-settings"),
                    render: function () {
                        wp.media.View.prototype.render.apply(this, arguments);
                        // Append an option for 0 (zero) columns if not already present...
                        var $s = this.$('select.columns');
                        if (!$s.find('option[value="0"]').length) {

                            $s.find('option[value="1"]').remove();
                            $s.find('option[value="2"]').remove();
                            $s.find('option[value="3"]').remove();
                            $s.find('option[value="5"]').remove();
                            $s.find('option[value="6"]').remove();
                            $s.find('option[value="7"]').remove();
                            $s.find('option[value="8"]').remove();
                            $s.find('option[value="9"]').remove();
                        }
                        // Select the correct values.
                        _(this.model.attributes).chain().keys().each(this.update, this);
                        return this;
                    }
                });
            }
        });
    </script>
	<?php
}

/*Remove Embed Shortcode in Content*/
/**
 * @param string $code name of the shortcode
 * @param string $content
 * @return string content with shortcode striped
 */
function strip_shortcode( $code, $content ) {
	global $shortcode_tags;

	$stack          = $shortcode_tags;
	$shortcode_tags = array( $code => 1 );

	$content = strip_shortcodes( $content );

	$shortcode_tags = $stack;
	return $content;
}