<?php


/* PlaceHolder image */
if ( ! function_exists( 'placeholdit' ) ) {
	function placeholdit( $width, $height, $back = 'f8f8f8', $fontcolor = 'b6b6b6' ) {
		//placeholder.php?size=400x150&bg=eee&fg=999&text=Generated+image
		return get_stylesheet_directory_uri() . '/class/placeholder/placeholder.php?size=' . $width . 'x' . $height . '&bg=' . $back . '&fg=' . $fontcolor;
	}
}

/*Wrap Page*/
if ( ! function_exists( 'admin_wrap_page' ) ) {
	function admin_wrap_page( $icon, $title, $type = 'start' ) {
		if ( $type == 'start' ) {
			return '<div class="wrap admin_wrap"><h2><span class="dashicons ' . $icon . '"></span>&nbsp; ' . $title . '</h2><div class="box-text-admin">';
		}
		if ( $type == 'end' ) {
			return "</div></div>\n";
		}
	}
}


/*Admin alert*/
if ( ! function_exists( 'admin_alert' ) ) {
	function admin_alert( $text ) {
		return '<div class="well text-right rtl">' . $text . '</div>';
	}
}

/*check Parent or children category*/
if ( ! function_exists( 'category_has_parent' ) ) {
	function category_has_parent( $catid ) {
		$category = get_category( $catid );
		if ( $category->category_parent > 0 ) {
			return true;
		}
		return false;
	}
}

/* check who category darad zirmajmoie*/
if ( ! function_exists( 'has_children_cat' ) ) {
	function has_children_cat( $cat_id ) //دارد زیر مجموعه
	{
		$children = get_terms(
			'category',
			array( 'parent' => $cat_id, 'hide_empty' => false )
		);
		if ( $children ) {
			return true;
		}
		return false;
	}
}


/*Product price*/
if ( ! function_exists( 'product_price' ) ) {
	function product_price( $text ) {
		return per_number( number_format( $text ) );
	}
}


/*
* Mb_substr ||mb_strlen($string, 'UTF-8');
*/
if ( ! function_exists( 'wp_mb_substr' ) ) {
	function wp_mb_substr( $text, $number_character ) {
		return mb_substr( $text, 0, $number_character, "utf-8" );
	}
}

/* Check Persian input */
if ( ! function_exists( 'check_persian_input' ) ) {
	function check_persian_input( $input ) {
		if ( preg_match( "/^[آ ا ب پ ت ث ج چ ح خ د ذ ر ز ژ س ش ص ض ط ظ ع غ ف ق ک گ ل م ن و ه ی]/", $input ) ) {
			return true;
		} else {
			return false;
		}
	}
}

/* Uploadfile */
if ( ! function_exists( 'wp_upload_file' ) ) {
	function wp_upload_file( $fileid, $model = false ) {
		require_once( ABSPATH . 'wp-admin/includes/image.php' );
		require_once( ABSPATH . 'wp-admin/includes/file.php' );
		require_once( ABSPATH . 'wp-admin/includes/media.php' );
		$attachment_id = media_handle_upload( $fileid, 0 );

		if ( is_wp_error( $attachment_id ) ) {
			return false;
		} else {
			//add to Not Show in attachment list
			//$opt = get_option("hide_attachment_list");
			// if($opt) {
			//$opt[] = $attachment_id;
			//update_option("hide_attachment_list",$opt);
			if ( $model != false ) {
				update_post_meta( $attachment_id, "what_is", $model );
			}
		}

		return $attachment_id;
	}
}


/* Check Code Meli User */
if ( ! function_exists( 'CheckMeliCode' ) ) {
	function CheckMeliCode( $meli_code ) {
		if ( strlen( $meli_code ) == 10 ) {
			if ( $meli_code == '1111111111' ||
			     $meli_code == '0000000000' ||
			     $meli_code == '2222222222' ||
			     $meli_code == '3333333333' ||
			     $meli_code == '4444444444' ||
			     $meli_code == '5555555555' ||
			     $meli_code == '6666666666' ||
			     $meli_code == '7777777777' ||
			     $meli_code == '8888888888' ||
			     $meli_code == '9999999999' ||
			     $meli_code == '0123456789'
			) {
				//echo 'كد ملي صحيح نمي باشد';
				return false;
			}

			$c = substr( $meli_code, 9, 1 );

			$n = substr( $meli_code, 0, 1 ) * 10 +
			     substr( $meli_code, 1, 1 ) * 9 +
			     substr( $meli_code, 2, 1 ) * 8 +
			     substr( $meli_code, 3, 1 ) * 7 +
			     substr( $meli_code, 4, 1 ) * 6 +
			     substr( $meli_code, 5, 1 ) * 5 +
			     substr( $meli_code, 6, 1 ) * 4 +
			     substr( $meli_code, 7, 1 ) * 3 +
			     substr( $meli_code, 8, 1 ) * 2;
			$r = $n - (int) ( $n / 11 ) * 11;
			if ( ( $r == 0 && $r == $c ) || ( $r == 1 && $c == 1 ) || ( $r > 1 && $c == 11 - $r ) ) {
				//echo ' کد ملی صحیح است';
				return true;
			} else {
				//echo 'كد ملي صحيح نمي باشد';
				return false;
			}
		} else {
			//echo 'طول کد ملی وارد شده باید 10 کاراکتر باشد';
			return false;
		}
	}
}


/* Get List Tree Menu of category */
if ( ! function_exists( 'CatTreeList' ) ) {
	function CatTreeList( $cat_id ) {
		return array_reverse( get_ancestors( $cat_id, 'category' ) );
	}
}

/*
 * Iran time
 */
function migration_timezone_to_iran() {
	date_default_timezone_set( "Asia/Tehran" );
}

function reset_timezone() {
	date_default_timezone_set( 'UTC' );
}

/*
 * is in Localhost
 */
if ( ! function_exists( 'is_localhost' ) ) {
	function is_localhost() {
		if ( strlen( strstr( home_url(), "localhost" ) ) > 0 ) {
			return true;
		} else {
			return false;
		}
	}
}

/*
 * Get Col info in Wordpress Db
 *
for($i=1; $i<=wp_get_number_column_table('payment'); $i++) {
echo wp_get_col_name($i, 'payment')." : ".wp_get_col_comment($i, 'payment');
echo "<br>";
}
 *
 *
 */

//Number Column Of Table
if ( ! function_exists( 'wp_get_number_column_table' ) ) {
	function wp_get_number_column_table( $table ) {
		global $wpdb;
		return count( $wpdb->get_col( "DESC " . $wpdb->prefix . $table, 0 ) );
	}
}

//function Get Field Name of mysql table
if ( ! function_exists( 'wp_get_col_name' ) ) {
	function wp_get_col_name( $number_field, $table ) {
		global $wpdb;
		$wpdb->get_results( "SELECT * FROM " . $wpdb->prefix . $table );
		return $wpdb->get_col_info( 'name', ( $number_field - 1 ) );
		$wpdb->flush();
	}
}

//Get field Comment
if ( ! function_exists( 'wp_get_col_comment' ) ) {
	function wp_get_col_comment( $number_field, $table ) {
		global $wpdb;
		$field_name    = $wpdb->get_col( "DESC " . $wpdb->prefix . $table, 0 )[ $number_field - 1 ];
		$field_comment = $wpdb->get_row( "SELECT column_comment FROM information_schema.columns WHERE table_name = '" . $wpdb->prefix . $table . "' AND column_name LIKE '$field_name'", ARRAY_N );
		return $field_comment[0];
	}
}


/*
 * Sort category parent list by get_the_category
 * $array is a get_the_category() uses
 */
if ( ! function_exists( 'sort_list_category_by_parent' ) ) {
	function sort_list_category_by_parent( $array ) {

		$categories = $array;
		// Assemble a tree of category relationships
// Also re-key the category array for easier
// reference
		$category_tree    = array();
		$keyed_categories = array();
		foreach ( (array) $categories as $c ) {
			$category_tree[ $c->cat_ID ]    = $c->category_parent;
			$keyed_categories[ $c->cat_ID ] = $c;
		}
// Now loop through and create a tiered list of
// categories
		$tiered_categories = array();
		$tier              = 0;
// This is the recursive bit
		while ( ! empty( $category_tree ) ) {
			$cats_to_unset = array();
			foreach ( (array) $category_tree as $cat_id => $cat_parent ) {
				if ( ! in_array( $cat_parent, array_keys( $category_tree ) ) ) {
					$tiered_categories[ $tier ][] = $cat_id;
					$cats_to_unset[]              = $cat_id;
				}
			}
			foreach ( $cats_to_unset as $ctu ) {
				unset( $category_tree[ $ctu ] );
			}
			$tier ++;
		}
// Walk through the tiers to order the cat objects properly
		$ordered_categories = array();
		foreach ( (array) $tiered_categories as $tier ) {
			foreach ( (array) $tier as $tcat ) {
				$ordered_categories[] = $keyed_categories[ $tcat ];
			}
		}
// Now you can loop over them and do whatever you want
		return (array) $ordered_categories;
	}
}


/*
 * Conver Hex to Rgb
 */
if ( ! function_exists( 'hextorgb' ) ) {
	function hextorgb( $hex, $alpha = false ) {
		$hex      = str_replace( '#', '', $hex );
		$length   = strlen( $hex );
		$rgb['r'] = hexdec( $length == 6 ? substr( $hex, 0, 2 ) : ( $length == 3 ? str_repeat( substr( $hex, 0, 1 ), 2 ) : 0 ) );
		$rgb['g'] = hexdec( $length == 6 ? substr( $hex, 2, 2 ) : ( $length == 3 ? str_repeat( substr( $hex, 1, 1 ), 2 ) : 0 ) );
		$rgb['b'] = hexdec( $length == 6 ? substr( $hex, 4, 2 ) : ( $length == 3 ? str_repeat( substr( $hex, 2, 1 ), 2 ) : 0 ) );
		if ( $alpha ) {
			$rgb['a'] = $alpha;
		}
		return $rgb;
	}
}


/* Related Post */
if ( ! function_exists( 'wp_get_related_posts' ) ) {
	function wp_get_related_posts( $post_id, $related_count, $args = array() ) {
		$args = wp_parse_args( (array) $args, array(
			'orderby' => 'rand',
			'return'  => 'query', // Valid values are: 'query' (WP_Query object), 'array' (the arguments array)
		) );

		$related_args = array(
			'post_type'      => get_post_type( $post_id ),
			'posts_per_page' => $related_count,
			'post_status'    => 'publish',
			'post__not_in'   => array( $post_id ),
			'orderby'        => $args['orderby'],
			'tax_query'      => array()
		);

		$post       = get_post( $post_id );
		$taxonomies = get_object_taxonomies( $post, 'names' );

		foreach ( $taxonomies as $taxonomy ) {
			$terms = get_the_terms( $post_id, $taxonomy );
			if ( empty( $terms ) ) {
				continue;
			}
			$term_list                   = wp_list_pluck( $terms, 'slug' );
			$related_args['tax_query'][] = array(
				'taxonomy' => $taxonomy,
				'field'    => 'slug',
				'terms'    => $term_list
			);
		}

		if ( count( $related_args['tax_query'] ) > 1 ) {
			$related_args['tax_query']['relation'] = 'OR';
		}

		if ( $args['return'] == 'query' ) {
			return new WP_Query( $related_args );
		} else {
			return $related_args;
		}
	}
}

/* List Hook wordpress */
if ( ! function_exists( 'hextorgb' ) ) {
	function list_hooks( $hook = '' ) {
		global $wp_filter;

		if ( isset( $wp_filter[ $hook ]->callbacks ) ) {
			array_walk( $wp_filter[ $hook ]->callbacks, function ( $callbacks, $priority ) use ( &$hooks ) {
				foreach ( $callbacks as $id => $callback ) {
					$hooks[] = array_merge( [ 'id' => $id, 'priority' => $priority ], $callback );
				}
			} );
		} else {
			return [];
		}

		foreach ( $hooks as &$item ) {
			// skip if callback does not exist
			if ( ! is_callable( $item['function'] ) ) {
				continue;
			}

			// function name as string or static class method eg. 'Foo::Bar'
			if ( is_string( $item['function'] ) ) {
				$ref          = strpos( $item['function'], '::' ) ? new ReflectionClass( strstr( $item['function'], '::', true ) ) : new ReflectionFunction( $item['function'] );
				$item['file'] = $ref->getFileName();
				$item['line'] = get_class( $ref ) == 'ReflectionFunction'
					? $ref->getStartLine()
					: $ref->getMethod( substr( $item['function'], strpos( $item['function'], '::' ) + 2 ) )->getStartLine();

				// array( object, method ), array( string object, method ), array( string object, string 'parent::method' )
			} elseif ( is_array( $item['function'] ) ) {

				$ref = new ReflectionClass( $item['function'][0] );

				// $item['function'][0] is a reference to existing object
				$item['function'] = array(
					is_object( $item['function'][0] ) ? get_class( $item['function'][0] ) : $item['function'][0],
					$item['function'][1]
				);
				$item['file']     = $ref->getFileName();
				$item['line']     = strpos( $item['function'][1], '::' )
					? $ref->getParentClass()->getMethod( substr( $item['function'][1], strpos( $item['function'][1], '::' ) + 2 ) )->getStartLine()
					: $ref->getMethod( $item['function'][1] )->getStartLine();

				// closures
			} elseif ( is_callable( $item['function'] ) ) {
				$ref              = new ReflectionFunction( $item['function'] );
				$item['function'] = get_class( $item['function'] );
				$item['file']     = $ref->getFileName();
				$item['line']     = $ref->getStartLine();

			}
		}

		return $hooks;
	}
}