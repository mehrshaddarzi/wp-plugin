<?php
get_header();

global $wp_query;
$icon = "fa-search";
$title= "جستجوی عبارت : ".$_GET['s'];
$number_result = $wp_query->found_posts;

echo '
<div class="container category-page">
<div class="wrapper blog-page-posts-outer">
<div class="blog-items-holder masonry-items-holder">
';


if (have_posts()) {	

echo '<div class="panel panel-default" style="margin:20px 0px 60px 0px;">
<div class="panel-body">
<div class="col-sm-6">
'.$title.'
</div>
<div class="col-sm-6 text-danger text-left">
تعداد مطالب یافت شده : '.per_number(number_format( $wp_query->found_posts ) ).'
</div>
<div class="clearfix"></div>
</div>
</div>';
    
    
    
while (have_posts()) : the_post();

    box_post_category();

endwhile;

echo '<div class="clearfix"></div>';

/*No Resuolt*/
} else {
	
echo '<div class="panel panel-default" style="margin:40px 0px;">
<div class="panel-body text-center">
<img src="'.get_template_directory_uri().'/images/not-found-search.jpg" class="img-responsive center-block" alt="search not Found">
<br>
هیچ محتوایی با عبارت شما در ایران رژ یافت نشد
<br>
<a href="'.home_url().'" class="btn btn-danger" style="padding: 15px 40px; margin:20px 0px" title="ایران رژ لب">ورود به سایت ایران رژ</a>
<br>
</div>
</div>';

}



echo '</div></div>';


//Pagination
if(function_exists('wp_pagenavi')) { 
wp_theme_pagination();
}

echo '</div>';


get_footer();