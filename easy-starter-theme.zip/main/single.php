<?php
get_header();

if ( have_posts() ) : while ( have_posts() ) :
	the_post();

	global $wp_query;
	$post_id = $wp_query->post->ID; //Get post id

	do_action( 'top_page_action' );

	$page_class = 'container';
	if ( get_post_meta( get_the_ID(), 'page-layout', true ) == "container-fluid" ) {
		$page_class = 'container-fluid';
	}
	?>
    <div class="<?php echo $page_class; ?>">
        <div class="matn">
			<?php
			$show_page_title = 'yes';
			if ( get_post_meta( get_the_ID(), 'show-page-title', true ) == "no" ) {
				$show_page_title = 'no';
			}
			if ( $show_page_title == "yes" ) {
				?>
                <h1 style="font-size: 22px;background: #f5f5f5;padding: 15px; border-radius: 5px;margin-bottom: 19px;font-weight: 500;"><?php the_title(); ?></h1>
				<?php
			}
			?>
			<?php
			the_content();
			?>
        </div>

		<?php
		$related = wp_get_related_posts( get_the_ID(), 4 );
		$x       = 1;
		if ( $related->have_posts() ):
			?>
            <div class="card" style="margin: -20px 0 40px 0; border-radius: 0px;">
                <h5 class="card-header" style="padding: .75rem 1.25rem;margin-bottom: 0;background-color: rgba(251, 251, 251, 0.03);border-bottom: 0px;font-size: 20px;">مطالب مرتبط</h5>
                <div class="card-body" style="padding-top: 5px;">
                    <ul class="list-group">
						<?php
						while ( $related->have_posts() ): $related->the_post();
							?>
                            <li class="list-group-item" style="<?php echo( $x == 1 ? 'border-top:0px;' : '' ); ?>border-right: 0px; border-left: 0px;border-radius: 0px;">
                                <a class="text-danger" style="font-size: 16px;" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
                            </li>
							<?php
							$x ++;
						endwhile;
						?>
                    </ul>
                </div>
            </div>
		<?php
		endif;
		wp_reset_postdata();
		?>
    </div>
	<?php
	do_action( 'bottom_page_action' );
endwhile;
else:
endif;
get_footer();