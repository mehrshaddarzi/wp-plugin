<div class="clearfix"></div>
<div class="section4 d-print-none">
    <div class="container">
        <div class="row fourRow" style="padding: 8% 0px !important;">
            <div class="col-md-4 contactUs" id="third">
                <h5>با ما در ارتباط باشید</h5>
				<?php
				$Address = get_theme_option( 'address' );
				?>
                <i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp<span><?php echo per_number($Address['address']); ?></span><br>
                <i class="fa fa-phone" aria-hidden="true"></i>&nbsp<span><?php echo per_number($Address['tel']); ?></span><br>
                <i class="fa fa-envelope" aria-hidden="true"></i>&nbsp<span style="font-family: Trebuchet MS;font-size: 15px;font-weight: 200;"><?php echo ucfirst($Address['email']); ?></span><br>
                <p><?php echo $Address['desc']; ?></p>
            </div>
            <div class="col-md-5 friends" id="second">
                <img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/dist/images/bestF_icon.png" alt="">
                <h5 class="mt-3">بهترین دوستاتو با ما دوست کن</h5>
                <p class="mt-1" style="font-size: 14px;"><<?php echo per_number( get_theme_option( 'percentage_first_order', 5 ) ); ?>% تخفیف برای خودت و دوستت در اولین سفارش از حس تازگی</p>
                <br>
                <div class="wrap form-inline">
                    <div class="sendit">
                        <div class="inputHa" style="width: 86%;">
                            <input type="text" name="friends-mobile" class="friendNum" placeholder="09---------" style="color: #4e4e4e;direction: ltr;">
                            <input type="text" name="friends-name" class="friendName" placeholder="اسم دوست" style="color: #4e4e4e;">
                        </div>
                        <button type="submit" class="sendButton" data-send-friend-register>ارسال</button>
                    </div>
                </div>
                <br><br>
            </div>
            <div class="col-md-3 spancers" id="first">
				<?php
				$Namad = get_theme_option( 'namad' );
				foreach ( $Namad as $n ) {
					?>
                    <a href="<?php echo $n['link']; ?>" title="<?php echo $n['name']; ?>">
                        <img src="<?php echo wp_get_attachment_url( $n['attachment_id'] ); ?>" alt="<?php echo $n['name']; ?>">
                    </a>
					<?php
				}
				?>
            </div>
        </div>
    </div>
    <div class="container d-none d-md-block">
        <div class="row">
            <div class="col-md-4 menuBott">
                <ul id="menu2">
					<?php
					$menu_name = 'footer_menu';
					if ( ( $locations = get_nav_menu_locations() ) && isset( $locations[ $menu_name ] ) ) {
						$menu       = wp_get_nav_menu_object( $locations[ $menu_name ] );
						$menu_items = wp_get_nav_menu_items( $menu->term_id );
						foreach ( (array) $menu_items as $key => $menu_item ) {
							$title  = $menu_item->title;
							$url    = $menu_item->url;
							$target = $menu_item->target; //if($target !="")
							$class  = $menu_item->classes; //if (count($class) >0)
							echo '<li><a href="' . $url . '" title="' . $title . '"' . ( $target != "" ? ' target="_blank"' : '' ) . '>' . $title . '</a></li>';
						}
					}
					?>
                </ul>
            </div>
            <div class="col-md-4"></div>
            <div class="col-md-4"></div>
        </div>
    </div>
</div>

<footer class="d-print-none">
    <div class="container" style="position: relative">
        <div class="footer-logo">
            <a href="<?php echo home_url(); ?>" title="حس تازگی">
                <img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/dist/images/footer-logo.png" alt="Footer logo">
            </a>
        </div>
        <div class="row sotials" <?php if ( ! is_home() and ! is_front_page() ) { ?> style="padding-bottom: 10px;" <?php } ?>>
            <div class="col-md-4">
                <p><?php echo get_theme_option( 'copyright' ); ?></p>
            </div>
            <div class="col-md-4"></div>
            <div class="col-md-4 text-center">
				<?php
				$Social = get_theme_option( 'social_footer' );
				foreach ( $Social as $sl ) {
					?>
                    <a href="<?php echo $sl['link']; ?>" title="<?php echo $sl['name']; ?>"><i class="fa <?php echo $sl['icon']; ?>" aria-hidden="true"></i></a>
					<?php
				}
				?>
            </div>
        </div>
		<?php
		if ( is_home() || is_front_page() ) {
			?>
            <div class="row texts">
                <div class="col-md-3"></div>
                <div class="col-md-6">
                    <p><?php echo wp_strip_all_tags( get_theme_option( 'footer_text' ) ); ?></p>
                    <img src="<?php echo get_template_directory_uri(); ?>/dist/images/symbol.png" alt="separate">
                </div>
                <div class="col-md-3"></div>
            </div>
			<?php
		}
		?>
    </div>
    <div class="container d-none d-sm-block">
        <div class="row">
            <div class="col-md-12 ToTop">
                <img src="<?php echo get_template_directory_uri(); ?>/dist/images/top.png" alt="top">
            </div>
        </div>
    </div>
</footer>

<?php
// Show Login PopUP
if ( ! is_user_logged_in() ) {
	WP_THEME_Helper::template_part( 'login_popup' );
}

// Show quick access
if ( is_home() || is_front_page() ) {
	WP_THEME_Helper::template_part( 'quick_access' );
}
?>

<?php
/*Footer Function wp*/
wp_footer();

//Show Query
//global $wpdb; echo "<pre>"; print_r($wpdb->queries); echo "</pre>";

//show active plugin
//echo "<pre>"; print_r(get_option('active_plugins')); echo "</pre>";

//main query
//global $wp_query; echo "<pre>"; print_r($wp_query); echo "</pre>";
?>
</body></html>