<?php
get_header();

if ( have_posts() ) : while ( have_posts() ) :
	the_post();

	global $wp_query;
	$post_id = $wp_query->post->ID; //Get post id

	do_action( 'top_page_action' );

	$page_class = 'container';
	if ( get_post_meta( get_the_ID(), 'page-layout', true ) == "container-fluid" ) {
		$page_class = 'container-fluid';
	}
	?>
    <div class="<?php echo $page_class; ?>">
        <div class="matn">
			<?php
			$show_page_title = 'yes';
			if ( get_post_meta( get_the_ID(), 'show-page-title', true ) == "no" ) {
				$show_page_title = 'no';
			}
			if ( $show_page_title == "yes" ) {
				?>
                <div class="titleList">
                    <p style="margin-bottom: 20px;">
                        <img src="<?php echo get_template_directory_uri(); ?>/dist/images/titleList_icon1.png" alt="seperator" class="d-none d-md-inline">
                        &nbsp <?php echo the_title(); ?> &nbsp
                        <img src="<?php echo get_template_directory_uri(); ?>/dist/images/titleList_icon2.png" alt="seperator" class="d-none d-md-inline">
                    </p>
                </div>
				<?php
			}
			?>
			<?php
			the_content();
			?>
        </div>
    </div>
	<?php

	do_action( 'bottom_page_action' );

endwhile;
else:
endif;
get_footer();