<?php
get_header();
?>
    <!-- Introduce -->
<?php
$Introduce = get_theme_option( 'introduce' );
?>
    <div class="section1">
        <div class="container">
            <div class="row twoRow">
                <div class="col-sm-12 col-md-6 order-md-2">
                    <img class="img-fluid img-delivery"  src="<?php echo wp_get_attachment_url( $Introduce['image'] ) ?>" alt="<?php $alt = WP_THEME_Helper::get_attachment( $Introduce['image'] );
		            echo $alt['alt']; ?>">
                </div>
                <div class="col-sm-12 col-md-6 order-md-1 oneContent">
                    <h2><?php echo $Introduce['title']; ?></h2>
                    <p><?php echo wp_strip_all_tags( $Introduce['text'] ); ?></p>
					<?php
					if ( $Introduce['is_more'] === true ) {
						?>
                        <a href="<?php echo $Introduce['link']; ?>">بیشتر بدانید</a>
						<?php
					}
					?>
                </div>
            </div>
        </div>


        <!-- separator -->
        <div class="container">
            <div class="row cr">
                <div class="col-md-12">
                    <div class="half_circle" style="background-color: #f0f0f0!important;">
                        <img src="<?php echo get_template_directory_uri(); ?>/dist/images/symbol1.png" alt="separator">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Service -->
    <div class="section2">
        <div class="container">
            <div class="row">
				<?php
				$Services = get_theme_option( 'services' );
				switch ( count( $Services ) ) {
					case 1:
						$col = 12;
						break;
					case 2:
						$col = 6;
						break;
					case 3:
						$col = 4;
						break;
					case 4:
						$col = 3;
				}
				foreach ( $Services as $service ) {
					?>
                    <div class="col-md-4 propertyTwo">
						<?php if ( ! empty( $service['link'] ) ) { ?>
                        <a href="<?php echo $service['link']; ?>"> <?php } ?>
                            <img class="img-fluid" src="<?php echo wp_get_attachment_url( $service['attachment_id'] ) ?>" alt="<?php echo $service['title']; ?>">
                            <h3><?php echo $service['title']; ?></h3>
							<?php if ( ! empty( $service['link'] ) ) { ?> </a> <?php } ?>
                    </div>
					<?php
				}
				?>
            </div>
        </div>

        <!-- Separator -->
        <div class="container">
            <div class="row cr">
                <div class="col-md-12">
                    <div class="half_circle">
                        <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/dist/images/symbol.png" alt="separator">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Tuesday ha -->
<?php
$Tuesday = get_theme_option( 'tuesday' );
?>
    <div class="section3">
        <div class="container">
            <div class="row thereRow">
                <div class="col-md-6 twoContent">
                    <img class="img-fluid" src="<?php echo wp_get_attachment_url( $Tuesday['attachment_id'] ); ?>" alt="<?php $alt = WP_THEME_Helper::get_attachment( $Tuesday['attachment_id'] );
					echo $alt['alt']; ?>">
                </div>
                <div class="col-md-6  twoContent">
                    <h3><?php echo $Tuesday['title']; ?></h3>
                    <p><?php echo wp_strip_all_tags( $Tuesday['text'] ); ?></p>
                    <div class="container">
                        <div class="row">
							<?php
							if ( is_user_logged_in() ) {
								?>
                                <div class="col-md-8 col-sm-8"></div>
                                <div class="col-md-4 col-sm-4">
                                    <button onclick="location.href='<?php echo get_category_link( $Tuesday['cat'] ); ?>'" type="button">
                                        <i class="fa fa-archive" aria-hidden="true"></i>&nbsp&nbsp&nbsp&nbsp<span>آرشیو</span>
                                    </button>
                                </div>
							<?php } else { ?>
                                <div class="col-md-4 col-sm-4"></div>
                                <div class="col-md-4 col-sm-4">
                                    <button data-tuesday-notification>
                                        <i class="fa fa-bell" aria-hidden="true"></i>&nbsp&nbsp&nbsp&nbsp<span>یادآوری</span>
                                    </button>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <button onclick="location.href='<?php echo get_category_link( $Tuesday['cat'] ); ?>'" type="button">
                                        <i class="fa fa-archive" aria-hidden="true"></i>&nbsp&nbsp&nbsp&nbsp<span>آرشیو</span>
                                    </button>
                                </div>
							<?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row cr">
                <div class="col-md-12">
                    <div class="half_circle">
                        <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/dist/images/symbol.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
get_footer();