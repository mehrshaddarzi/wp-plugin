<?php
// silent is Good