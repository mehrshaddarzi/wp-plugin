<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>"/>
	<?php if ( is_search() ) { ?>
        <meta name="robots" content="noindex, nofollow"/> <?php } ?>
    <!--[if IE]>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><![endif]-->
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
        <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php endif; ?>
	<?php wp_head(); //echo "\n";?>
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header>
    <div class="container top-container pt-4 <?php if ( ! is_front_page() and ! is_home() ) { ?>pb-4<?php } ?>">
        <nav class="navbar navbar-expand-lg navbar-light">
            <a class="navbar-brand" href="<?php echo home_url(); ?>">
                <img class="logo" src="<?php echo get_theme_option( 'logo', get_template_directory_uri() . '/dist/images/logo.png' ); ?>" alt="<?php echo get_bloginfo( 'name' ); ?>">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
				<?php
				wp_nav_menu( array(
					'menu'            => 'home_top_menu',
					'container'       => '',
					'container_id'    => '',
					'container_class' => 'collapse navbar-collapse',
					'menu_id'         => false,
					'menu_class'      => 'navbar-nav mr-auto',
					'depth'           => 2,
					'fallback_cb'     => 'bs4navwalker::fallback',
					'walker'          => new bs4navwalker()
				) );
				?>
                <ul class="top-site-button">
                    <li>
						<?php
						if ( is_user_logged_in() ) {
						?>
                        <a href="<?php echo WooCommerce_Helper::get_page_url( 'myaccount' ); ?>" class="btn1"><img src="<?php echo ACL_Helper::avatar(); ?>" alt="<?php echo ACL_Helper::get_name(); ?>">&nbsp<span> <?php echo ACL_Helper::get_name(); ?> خوش آمدید ‍! </span></a>
								<?php
								} else {
								?>
                                <a href="#" class="btn1" data-toggle="modal" data-target="#login_modal" id="show_login_modal"><img src="<?php echo get_template_directory_uri(); ?>/dist/images/login_icon.png" alt="ورود به سایت">&nbsp<span>ورود&nbsp|&nbspعضویت</span></a>
										<?php
										}
										?>
                    </li>
                    <li>
                        <a href="<?php echo WooCommerce_Helper::get_page_url( 'shop' ); ?>" class="btn1 btndovom">
                            <img src="<?php echo get_template_directory_uri(); ?>/dist/images/sail_icon.png" alt="">&nbsp<span>&nbsp سبد خرید &nbsp</span>
							<?php
							if ( ! WooCommerce_Helper::is_empty_cart() ) {
								?>
                                <span class="badge badge-danger" data-top-cart-item style="width: 18px;height: 18px; font-size: 12px;font-family: 'YJ';"><?php echo per_number( WooCommerce_Helper::get_number_product_in_cart() ); ?></span>
								<?php
							}
							?>
                            </a>
                    </li>
                </ul>

            </div>
        </nav>

        <!-- Quick Access BTN -->
		<?php if ( is_home() || is_front_page() ) { ?>
            <div class="row d-none d-md-block">
                <div class="col-md-12">
                    <a class="access_btn" href="#"><br>دسترسی سریع<br><i class="fa fa-bars" aria-hidden="true" style="margin-top: 6px;font-size: 18px;"></i></a>
                </div>
            </div>
		<?php } ?>
    </div>

    <!-- Home Page Slider -->
	<?php if ( is_home() || is_front_page() ) { ?>
        <div class="container">
            <div class="row">
                <div class="col-md-12 HPage">
                    <div id="carousel-home-top" class="carousel slide carousel-fade mt-4" data-ride="carousel">
                        <div class="carousel-inner">
							<?php
							$SlideShow_Home = get_theme_option( 'home-slideshow' );
							$i              = 0;
							foreach ( $SlideShow_Home as $slide ) {
								$attachment_info = WP_THEME_Helper::get_attachment( $slide['attachment_id'] );
								?>
                                <div class="carousel-item <?php echo( $i < 1 ? "active" : "" ); ?>" data-interval="5000">
                                    <a href="<?php echo $slide['link']; ?>"><img src="<?php echo wp_get_attachment_url( $slide['attachment_id'] ); ?>" class="img-responsive" alt="<?php echo $attachment_info['alt']; ?>"></a>
                                </div>
								<?php
								$i ++;
							}
							?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- separator -->
        <div class="container">
            <div class="row cr">
                <div class="col-md-12">
                    <div class="half_circle">
                        <img src="<?php echo get_template_directory_uri(); ?>/dist/images/symbol1.png" alt="separator">
                    </div>
                </div>
            </div>
        </div>
	<?php } ?>
</header>