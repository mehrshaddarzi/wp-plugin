// Alert Function
function show_loading(time = 5000) {
    jQuery("body").overhang({
        type: "info",
        html: true,
        message: "لطفا کمی صبر نمائید ...",
        duration: time
    });
}
function show_overhang(type, text, time) {
    jQuery("body").overhang({
        type: type, //[success, error, info, warn]
        html: true,
        message: text,
        duration: time,
        upper: true
    });
    setTimeout(function () {
        jQuery(".overhang").remove();
    }, time);
}
function strstr(haystack, needle) {
    let i = 0,
        tempLength = 0,
        temp = [];
    for (; ;) {
        if (haystack[i] === undefined || needle == null) {
            return "No match";
        }
        //if the char doesn't match then reset
        else if (haystack[i] !== needle[tempLength]) {
            temp = [];
            tempLength = 0;
        }
        //the char matches so let's store it.
        else if (haystack[i] === needle[tempLength]) {
            temp[tempLength] = haystack[i];
            if (needle[tempLength + 1] === undefined) {
                return temp;
            }
            tempLength++;
        }
        i++;
    }
}

jQuery(document).ready(function () {

    // Login Modal Box
    $('#login_modal').on('shown.bs.modal', function () {
        $("div[data-step-login]").hide();
        $("div[data-step-login=1]").fadeIn('normal');
    });

    // Login Sysetm
    $(document).on('keyup', 'input[name=login-mobile]', function (e) {
        if (e.keyCode == 13) {
            $("button[data-login-mobile]").click();
        }
    });
    $(document).on('keyup', 'input[name=login-password]', function (e) {
        if (e.keyCode == 13) {
            $("button[data-login-complete]").click();
        }
    });
    $(document).on('click', 'button[data-login-mobile]', function (event) {
        event.preventDefault();

        // Alert Box
        var alert = $(".alert-login-box");

        // Check Mobile Number
        let mobile = $("input[name=login-mobile]").val();
        if (mobile.length < 1) {
            alert.html("<div class=\"alert alert-danger\" role=\"alert\">" + " لطفا شماره همراه را وارد نمایید " + "</div>").fadeIn('slow', function () {
                $(this).delay(4000).fadeOut('slow');
            });
            return;
        }

        // Show Loading
        alert.html("<div class=\"alert alert-dark\" role=\"alert\">" + " لطفا کمی صبر کنید ... " + "</div>").show();

        // Send Ajax
        $.ajax({
            url: app_config.app_url + '/wp-admin/admin-ajax.php',
            type: 'GET',
            dataType: "json",
            cache: false,
            data: {
                'action': 'login_system',
                'step': 1,
                'token': app_config.token,
                'mobile': mobile
            },
            success: function (data) {
                if (data.status == "no") {
                    alert.html("<div class=\"alert alert-danger\" role=\"alert\">" + data.message + "</div>").fadeIn('slow', function () {
                        $(this).delay(4000).fadeOut('slow');
                    });
                } else {
                    $("div[data-step-login]").hide();
                    alert.hide();
                    if (data.message == "new_user") {
                        $("div[data-step-login=2]").fadeIn('fast');
                    } else {
                        $("div[data-step-login=4]").fadeIn('fast');
                    }
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                alert.html("<div class=\"alert alert-danger\" role=\"alert\">" + " خطای ارتباط با سرور ایجاد شده لطفا دوباره تلاش کنید " + "</div>").fadeIn('slow', function () {
                    $(this).delay(4000).fadeOut('slow');
                });
            }
        });
    });
    $(document).on('click', 'button[data-register-code]', function (event) {
        event.preventDefault();

        // Alert Box
        let alert = $(".alert-login-box");

        // Check
        let mobile = $("input[name=login-mobile]").val();
        let code = $("input[name=code-signup]").val();
        if (code.length < 1) {
            alert.html("<div class=\"alert alert-danger\" role=\"alert\">" + " لطفا کد تایید را وارد نمایید " + "</div>").fadeIn('slow', function () {
                $(this).delay(4000).fadeOut('slow');
            });
            return;
        }

        // Show Loading
        alert.html("<div class=\"alert alert-dark\" role=\"alert\">" + " لطفا کمی صبر کنید ... " + "</div>").show();

        // Send Ajax
        $.ajax({
            url: app_config.app_url + '/wp-admin/admin-ajax.php',
            type: 'GET',
            dataType: "json",
            cache: false,
            data: {
                'action': 'login_system',
                'step': 2,
                'token': app_config.token,
                'mobile': mobile,
                'code': code
            },
            success: function (data) {
                if (data.status == "no") {
                    alert.html("<div class=\"alert alert-danger\" role=\"alert\">" + data.message + "</div>").fadeIn('slow', function () {
                        $(this).delay(4000).fadeOut('slow');
                    });
                } else {
                    $("div[data-step-login]").hide();
                    alert.hide();
                    if (data.message == "go_to_process") {
                        $("div[data-step-login=3]").fadeIn('fast');
                    }
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                alert.html("<div class=\"alert alert-danger\" role=\"alert\">" + " خطای ارتباط با سرور ایجاد شده لطفا دوباره تلاش کنید " + "</div>").fadeIn('slow', function () {
                    $(this).delay(4000).fadeOut('slow');
                });
            }
        });
    });
    $(document).on('click', 'button[data-register-complete]', function (event) {
        event.preventDefault();

        // Alert Box
        let alert = $(".alert-login-box");

        // Check
        let mobile = $("input[name=login-mobile]").val();
        let code = $("input[name=code-signup]").val();
        let name = $("input[name=register-name]").val();
        let email = $("input[name=register-email]").val();
        let password = $("input[name=register-pass]").val();

        // Check Law
        if (!$("input[name=register-law]").is(":checked")) {
            alert.html("<div class=\"alert alert-danger\" role=\"alert\">" + " لطفا قوانین را تایید نمایید " + "</div>").fadeIn('slow', function () {
                $(this).delay(4000).fadeOut('slow');
            });
            return;
        }
        if (name.length < 1 || password.length < 1) {
            alert.html("<div class=\"alert alert-danger\" role=\"alert\">" + " لطفا فیلد های اجباری را پر نمایید " + "</div>").fadeIn('slow', function () {
                $(this).delay(4000).fadeOut('slow');
            });
            return;
        }

        // Show Loading
        alert.html("<div class=\"alert alert-dark\" role=\"alert\">" + " لطفا کمی صبر کنید ... " + "</div>").show();

        // Send Ajax
        $.ajax({
            url: app_config.app_url + '/wp-admin/admin-ajax.php',
            type: 'POST',
            dataType: "json",
            cache: false,
            data: {
                'action': 'login_system',
                'step': 5,
                'token': app_config.token,
                'mobile': mobile,
                'code': code,
                'display_name': name,
                'email': email,
                'pass1': password
            },
            success: function (data) {
                if (data.status == "yes") {
                    alert.html("<div class=\"alert alert-success\" role=\"alert\">" + "ثبت نام شما با موفقیت انجام شد" + "</div>").fadeIn('slow', function () {
                        $(this).delay(4000).fadeOut('slow');
                    });
                    window.location.replace(app_config.page);
                } else {
                    alert.html("<div class=\"alert alert-danger\" role=\"alert\">" + data.message + "</div>").fadeIn('slow', function () {
                        $(this).delay(4000).fadeOut('slow');
                    });
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                alert.html("<div class=\"alert alert-danger\" role=\"alert\">" + " خطای ارتباط با سرور ایجاد شده لطفا دوباره تلاش کنید " + "</div>").fadeIn('slow', function () {
                    $(this).delay(4000).fadeOut('slow');
                });
            }
        });
    });
    $(document).on('click', 'button[data-login-complete]', function (event) {
        event.preventDefault();

        // Alert Box
        let alert = $(".alert-login-box");

        // Check
        let mobile = $("input[name=login-mobile]").val();
        let password = $("input[name=login-password]").val();
        if (password.length < 1) {
            alert.html("<div class=\"alert alert-danger\" role=\"alert\">" + " لطفا رمز عبور را وارد نمایید " + "</div>").fadeIn('slow', function () {
                $(this).delay(4000).fadeOut('slow');
            });
            return;
        }

        // Show Loading
        alert.html("<div class=\"alert alert-dark\" role=\"alert\">" + " لطفا کمی صبر کنید ... " + "</div>").show();

        // Send Ajax
        $.ajax({
            url: app_config.app_url + '/wp-admin/admin-ajax.php',
            type: 'POST',
            dataType: "json",
            cache: false,
            data: {
                'action': 'login_system',
                'step': 4,
                'token': app_config.token,
                'mobile': mobile,
                'password': password
            },
            success: function (data) {
                if (data.status == "yes") {
                    alert.html("<div class=\"alert alert-success\" role=\"alert\">" + "شما با موفقیت وارد شده اید" + "</div>").fadeIn('slow', function () {
                        $(this).delay(4000).fadeOut('slow');
                    });
                    window.location.replace(app_config.page);
                } else {
                    alert.html("<div class=\"alert alert-danger\" role=\"alert\">" + data.message + "</div>").fadeIn('slow', function () {
                        $(this).delay(4000).fadeOut('slow');
                    });
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                alert.html("<div class=\"alert alert-danger\" role=\"alert\">" + " خطای ارتباط با سرور ایجاد شده لطفا دوباره تلاش کنید " + "</div>").fadeIn('slow', function () {
                    $(this).delay(4000).fadeOut('slow');
                });
            }
        });
    });
    $(document).on('click', 'a[data-reset-mobile-password]', function (event) {
        event.preventDefault();

        // Alert Box
        let alert = $(".alert-login-box");

        // Check
        let mobile = $("input[name=login-mobile]").val();

        // Show Loading
        alert.html("<div class=\"alert alert-dark\" role=\"alert\">" + " لطفا کمی صبر کنید ... " + "</div>").show();

        // Send Ajax
        $.ajax({
            url: app_config.app_url + '/wp-admin/admin-ajax.php',
            type: 'POST',
            dataType: "json",
            cache: false,
            data: {
                'action': 'login_system',
                'step': 3,
                'token': app_config.token,
                'mobile': mobile
            },
            success: function (data) {
                alert.html("<div class=\"alert alert-success\" role=\"alert\">" + "یک پیامک حاوی رمز عبور جدید برایتان ارسال میگردد لطفا ان را وارد کنید" + "</div>").fadeIn('slow', function () {
                    $(this).delay(4000).fadeOut('slow');
                });
            },
            error: function (jqXHR, textStatus, errorThrown) {
                alert.html("<div class=\"alert alert-danger\" role=\"alert\">" + " خطای ارتباط با سرور ایجاد شده لطفا دوباره تلاش کنید " + "</div>").fadeIn('slow', function () {
                    $(this).delay(4000).fadeOut('slow');
                });
            }
        });
    });

    // Edit Profile Page
    $(document).on("keyup", "input[data-save-user-profile-field]", function (e) {
        e.preventDefault();
        $("div[data-edit-profile-save-area]").show();
    });
    $(document).on("click", "a[data-edit-profile-save]", function (e) {
            e.preventDefault();

            let name = $("input[name=edit-display-name]").val();
            let email = $("input[name=edit-user-email]").val();
            let current_pass = $("input[name=edit-current-pass]").val();
            let new_pass = $("input[name=edit-new-pass]").val();
            let new_pass_2 = $("input[name=edit-new-pass-2]").val();

            // Check Empty Validation
            if (name.length < 1) {
                show_overhang("error", "خطا : لطفا نام خود را وارد نمایید", 5000);
                return;
            }

            // Check Current Pass
            if (
                (current_pass.length > 0 && (new_pass.length < 1 || new_pass_2 < 1))
                || (new_pass.length > 0 && (current_pass.length < 1 || new_pass_2 < 1))
                || (new_pass_2.length > 0 && (current_pass.length < 1 || new_pass < 1))
            ) {
                show_overhang("error", "خطا : لطفا فیلد های مربوط به رمز عبور را کامل پر نمایید.", 5000);
                return;
            }

            // Check New Pass is Same
            if (new_pass.length > 0 && new_pass_2.length > 0 && new_pass_2 !== new_pass) {
                show_overhang("error", "خطا : رمز عبور جدید وارد شده یکسان نمی باشد.", 5000);
                return;
            }

            // Show Alert
            show_loading();

            // Send Ajax Request
            $.ajax({
                url: app_config.app_url + '/wp-admin/admin-ajax.php',
                type: 'POST',
                dataType: "json",
                cache: false,
                data: {
                    'action': 'editable_user_profile',
                    'token': app_config.token,
                    'name': name,
                    'email': email,
                    'current_pass': current_pass,
                    'pass_1': new_pass,
                    'pass_2': new_pass_2
                },
                success: function (data) {
                    if (data.status == "yes") {
                        show_overhang("success", data.message, 5000);
                        $("input[type=password]").val("");
                    } else {
                        show_overhang("error", data.message, 5000);
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    show_overhang("error", " خطای ارتباط با سرور ایجاد شده لطفا دوباره تلاش کنید ", 5000);
                }
            });
        }
    );

    // Show Quick Access
    $(".access_btn").click(function () {
        if ($(".access_btn i").hasClass("fa fa-times")) {
            $(".access_btn i").removeClass("fa fa-times").addClass("fa fa-bars");
            $("#quick_access").fadeOut();
            $(".tab").animate({marginTop: "-25%"});
        } else {
            $(".access_btn i").removeClass("fa fa-bars").addClass("fa fa-times");
            $("#quick_access").fadeIn();
            $(".tab").animate({marginTop: "15%"});
        }
    });

    // To Top in Page
    $(".ToTop img").click(function () {
        $("html").animate({scrollTop: "0"}, 2000);
    });
    $(window).scroll(function () {
        var scroll_top = $(this).scrollTop();
        if (scroll_top >= 400) {
            $(".ToTop img").animate({right: "15px"}, 50);
        } else {
            $(".ToTop img").animate({right: "-50px"}, 50);
        }
    });

    // tuesday Notification
    $(document).on('click', 'button[data-tuesday-notification]', function (event) {
        event.preventDefault();
        $("p#first_text_register").html("برای با خبر شدن از سه شنبه های شگفت انگیز شماره همراه خود را وارد نمایید");
        $("div[data-step-login]").hide();
        $("div[data-step-login=1]").fadeIn('normal');
        $('#login_modal').modal('show');
    });

    // Send User Friends Number
    $(document).on('click', 'button[data-send-friend-register]', function (event) {
        event.preventDefault();

        // Get Value
        let friends_name = $("input[name=friends-name]").val();
        let friends_mobile = $("input[name=friends-mobile]").val();
        if (friends_name.length < 1 || friends_mobile.length < 1) {
            show_overhang("error", "خطا : لطفا تمامی فیلد ها را پر نمایید", 5000);
            return;
        }

        // Show Alert
        show_loading();

        // Send Ajax Request
        // Send Ajax
        $.ajax({
            url: app_config.app_url + '/wp-admin/admin-ajax.php',
            type: 'GET',
            dataType: "json",
            cache: false,
            data: {
                'action': 'friends_invitation',
                'step': 4,
                'token': app_config.token,
                'mobile': friends_mobile,
                'name': friends_name
            },
            success: function (data) {
                if (data.status == "yes") {
                    show_overhang("success", data.message, 5000);
                } else {
                    show_overhang("error", data.message, 5000);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                show_overhang("error", " خطای ارتباط با سرور ایجاد شده لطفا دوباره تلاش کنید ", 5000);
            }
        });
    });

    /*Contact Form*/
    $(document).on("click", "button[id=send_submit_contact]", function (e) {
        e.preventDefault();

        // Get Value
        let name = $("input[name=contact-name]").val();
        let mobile = $("input[name=contact-mobile]").val();
        let email = $("input[name=contact-email]").val();
        let branch = $("input[name=contact-branch]").val();
        let content = $("textarea[name=contact-content]").val();
        let captcha = $("input[name=contact-captcha]").val();
        if (name.length < 1 || mobile.length < 1 || branch.length < 1 || content.length < 1 || captcha.length < 1) {
            show_overhang("error", "خطا : لطفا تمامی فیلد ها را پر نمایید", 5000);
            return;
        }

        // Show Alert
        show_loading();

        // Send Ajax Form
        $.ajax({
            url: app_config.app_url + '/wp-admin/admin-ajax.php',
            type: 'POST',
            dataType: "json",
            cache: false,
            data: {
                'action': 'send_ajax_contact_form',
                'token': app_config.token,
                'name': name,
                'mobile': mobile,
                'email': email,
                'branch': branch,
                'content': content,
                'captcha': captcha
            },
            success: function (data) {
                if (data.status == "yes") {
                    show_overhang("success", data.message, 5000);
                    $("input[name=contact-name]").val("");
                    $("input[name=contact-mobile]").val("");
                    $("input[name=contact-email]").val("");
                    $("input[name=contact-branch]").val("");
                    $("textarea[name=contact-content]").val("");
                    $("input[name=contact-captcha]").val("");
                } else {
                    show_overhang("error", data.message, 5000);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                show_overhang("error", " خطای ارتباط با سرور ایجاد شده لطفا دوباره تلاش کنید ", 5000);
            }
        });

    });

    // Update User Profile
    $(document).on("click", "img[data-function=select_user_avatar]", function (e) {
        e.preventDefault();
        jQuery("input#profile_image_upload").click();
    });
    jQuery(document).on('change', 'input#profile_image_upload', function () {

        //check file size
        var f = jQuery("input[id=profile_image_upload]")[0].files[0];
        var mb = 2 * 1024 * 1024;
        if (f.size > mb || f.fileSize > mb) {
            show_overhang("error", 'حداکثر حجم عکس آواتار 2 مگابایت می باشد', 5000);
            return;
        } else {

            var fileupload = jQuery("input[id=profile_image_upload]").val();
            var fileExtension = ['jpeg', 'jpg', 'png'];
            if (jQuery.inArray(fileupload.split('.').pop().toLowerCase(), fileExtension) == -1) {
                show_overhang("error", 'تنها پسوند jpg و png مورد قبول می باشد', 5000);
                return false;
            }

            // Show Alert
            show_loading();

            // Send FormData
            var formdata = new FormData($("#change_profile_image")[0]);
            formdata.append('action', 'wp_change_user_avatar');
            formdata.append('token', app_config.token);
            jQuery.ajax({
                url: app_config.app_url + '/wp-admin/admin-ajax.php',
                type: 'POST',
                processData: false,
                contentType: false,
                cache: false,
                data: formdata,
                success: function (data) {
                    if (data.status == "yes") {
                        show_overhang("success", data.message, 5000);
                        jQuery("img[data-function=select_user_avatar]").attr("src", data.avatar);
                    } else {
                        show_overhang("error", data.message, 5000);
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    show_overhang("error", " خطای ارتباط با سرور ایجاد شده لطفا دوباره تلاش کنید ", 5000);
                }
            });
        }
    });

    // Signup inTuesday Compain
    jQuery(document).on('change', 'select[name=tuesday-system]', function () {

        // Show Alert
        show_loading();

        $.ajax({
            url: app_config.app_url + '/wp-admin/admin-ajax.php',
            type: 'POST',
            dataType: "json",
            cache: false,
            data: {
                'action': 'change_type_subscriber',
                'token': app_config.token,
                'subscriber_type': $("select[name=tuesday-system]").val()
            },
            success: function (data) {
                if (data.status == "yes") {
                    show_overhang("success", data.message, 5000);
                } else {
                    show_overhang("error", data.message, 5000);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                show_overhang("error", " خطای ارتباط با سرور ایجاد شده لطفا دوباره تلاش کنید ", 5000);
            }
        });


    });

    // Jcarousel
    $('.jcarousel').jcarousel();
    $('.jcarousel-control-prev')
        .on('jcarouselcontrol:active', function () {
            $(this).removeClass('inactive');
        })
        .on('jcarouselcontrol:inactive', function () {
            $(this).addClass('inactive');
        })
        .jcarouselControl({
            target: '-=1'
        });
    $('.jcarousel-control-next')
        .on('jcarouselcontrol:active', function () {
            $(this).removeClass('inactive');
        })
        .on('jcarouselcontrol:inactive', function () {
            $(this).addClass('inactive');
        })
        .jcarouselControl({
            target: '+=1'
        });
    $('.jcarousel-pagination')
        .on('jcarouselpagination:active', 'a', function () {
            $(this).addClass('active');
        })
        .on('jcarouselpagination:inactive', 'a', function () {
            $(this).removeClass('active');
        })
        .jcarouselPagination();

    // WooCmmerce Update Checkout
    function woo_update_checkout(data) {

        // Cart Items
        let _cart_items = $("div[data-cart-items]");
        if (_cart_items.length) {
            _cart_items.html(data.cart_items);
        }

        // Check out List
        let _checkout_tbl = $("div[data-checkout-total-cart]");
        if (_checkout_tbl.length) {
            _checkout_tbl.html(data.checkout_tbl);
        }

        // Check Btn Coupon
        let _btn_coupon = $("div[data-btn-coupon]");
        if (_btn_coupon.length) {
            _btn_coupon.html(data.btn_coupon);
        }

        // Address
        let _address_ls = $("div[data-checkout-address-list]");
        if (_address_ls.length) {
            _address_ls.html(data.address_list);
        }

        // Btn CheckOut Address
        let _btn_checkout = $("div[data-checkout-btn-process]");
        if (_btn_checkout.length) {
            _btn_checkout.html(data.btn_checkout);
        }

    }

    // Keypress Input Coupon [.keypress(function () { for ajax ]
    $(document).on('keyup', 'input[name=enter-woo-coupons]', function (event) {
        let dInput = $(this).val();
        let _btn = $("button[data-set-coupon]");
        if (dInput.length > 0) {
            _btn.show();
        } else {
            _btn.hide();
        }
    });

    // Apply Coupon
    $(document).on('click', 'button[data-set-coupon]', function (event) {
        event.preventDefault();
        var coupon = $("input[name=enter-woo-coupons]").val();

        // Show Alert
        show_loading();

        // Send Ajax Request
        $.ajax({
            url: app_config.app_url + '/wp-admin/admin-ajax.php',
            type: 'GET',
            dataType: "json",
            cache: false,
            data: {
                'action': 'woo_add_coupons',
                'token': app_config.token,
                'coupon': coupon
            },
            success: function (data) {
                if (data.status == "yes") {
                    show_overhang("success", data.message, 5000);
                    woo_update_checkout(data);
                } else {
                    show_overhang("error", data.message, 5000);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                show_overhang("error", " خطای ارتباط با سرور ایجاد شده لطفا دوباره تلاش کنید ", 5000);
            }
        });

    });

    // Re Order
    $(document).on('click', 'a[data-action-order=re-order]', function (event) {
        event.preventDefault();
        var order_ID = $(this).attr("data-id");

        // Show Alert
        show_loading();

        // Send Ajax Request
        $.ajax({
            url: app_config.app_url + '/wp-admin/admin-ajax.php',
            type: 'GET',
            dataType: "json",
            cache: false,
            data: {
                'action': 'woo_re_order',
                'token': app_config.token,
                'order_id': order_ID
            },
            success: function (data) {
                if (data.status == "yes") {
                    window.location.href = data.redirect;
                } else {
                    show_overhang("error", data.message, 5000);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                show_overhang("error", " خطای ارتباط با سرور ایجاد شده لطفا دوباره تلاش کنید ", 5000);
            }
        });

    });

    // Remove Order
    $(document).on('click', 'a[data-action-order=cancel]', function (event) {
        event.preventDefault();
        var order_ID = $(this).attr("data-id");

        // Show Alert
        show_loading();

        // Send Ajax Request
        $.ajax({
            url: app_config.app_url + '/wp-admin/admin-ajax.php',
            type: 'GET',
            dataType: "json",
            cache: false,
            data: {
                'action': 'woo_remove_order',
                'token': app_config.token,
                'order_id': order_ID
            },
            success: function (data) {
                if (data.status == "yes") {
                    window.location.href = data.redirect;
                } else {
                    show_overhang("error", data.message, 5000);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                show_overhang("error", " خطای ارتباط با سرور ایجاد شده لطفا دوباره تلاش کنید ", 5000);
            }
        });
    });

    // Go to Checkout
    $(document).on('click', 'button[data-go-to-checkout-process]', function (event) {
        event.preventDefault();
        let checkout_url = $(this).attr("data-go-to-checkout-process");

        // Check Set Address
        let this_address = parseInt($("input[name=user_shipping_id]").val());
        if (this_address < 1) {
            show_overhang("error", " لطفا آدرس محل ارسال را انتخاب کنید ", 5000);
            return;
        }

        window.location.href = checkout_url + '?shipping_id=' + this_address;
    });

    // Click On Change Address BTN
    $(document).on('click', ".ersalBe button[data-user-address-id]", function (event) {
        event.preventDefault();
        let address_id = parseInt($(this).attr("data-user-address-id"));
        $(".ersalBe button[data-user-address-id]").removeClass("act");
        $(".ersalBe button[data-user-address-id= " + address_id + "]").addClass("act");
        $("input[name=user_shipping_id]").val(address_id);
    });

    // Click Btn Add Address
    $(document).on('click', 'button[data-add-new-cart-address]', function (event) {
        event.preventDefault();
        let logged_in = $(this).attr("data-is-user-logged-in");
        if (logged_in == "no") {
            show_overhang("error", "برای افزودن آدرس ابتدا وارد حساب کاربری خود شوید", 5000);
        } else {
            $('#woo_add_address').modal('show');
        }
    });

    $(document).on('click', 'a[data-add-new-user-edit-address]', function (event) {
        event.preventDefault();
        $('#woo_add_address').modal('show');
    });

    // Remove Shipping
    $(document).on('click', 'button[data-remove-user-address-id]', function (event) {
        event.preventDefault();

        // Get Value
        var address_ID = $(this).attr("data-remove-user-address-id");

        // Show Alert
        jQuery("body").overhang({
            type: "confirm",
            primary: "#40D47E",
            accent: "#27AE60",
            yesMessage: "بله",
            noMessage: "خیر",
            yesColor: "#3498DB",
            message: "آیا می خواهید آدرس را حذف کنید ؟",
            callback: function (value) {
                if (value === true) {

                    // Show Alert
                    show_loading();

                    // Send Ajax Request
                    $.ajax({
                        url: app_config.app_url + '/wp-admin/admin-ajax.php',
                        type: 'POST',
                        dataType: "json",
                        cache: false,
                        data: {
                            'action': 'remove_user_shipping_ajax',
                            'token': app_config.token,
                            'ID': address_ID
                        },
                        success: function (data) {
                            if (data.status == "yes") {
                                show_overhang("success", data.message, 5000);
                                if (strstr(app_config.page, '/my-account/edit_profile')) {
                                    setTimeout(function () {
                                        window.location = app_config.page;
                                    }, 1000);
                                }
                            } else {
                                show_overhang("error", data.message, 5000);
                            }
                        },
                        error: function (jqXHR, textStatus, errorThrown) {
                            show_overhang("error", " خطای ارتباط با سرور ایجاد شده لطفا دوباره تلاش کنید ", 5000);
                        }
                    });
                }
            }
        });
    });

    // Add Shipping
    function set_modal_address(address, phone, zipcode, lat, lng) {
        $("textarea[name=woo-new-shipping-address]").val(address);
        $("input[name=woo-new-shipping-phone]").val(phone);
        $("input[name=woo-new-shipping-zipcode]").val(zipcode);
        var myLatlng = new google.maps.LatLng(lat, lng);
        var mapProp = {
            center: myLatlng,
            zoom: 18,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        var map = new google.maps.Map(document.getElementById("googleMap"), mapProp);
        var marker = new google.maps.Marker({
            position: myLatlng,
            map: map,
            title: 'Your Place',
            draggable: true
        });
        document.getElementById('lat').value = lat;
        document.getElementById('lng').value = lng;
        // marker drag event
        google.maps.event.addListener(marker, 'drag', function (event) {
                document.getElementById('lat').value = event.latLng.lat();
                document.getElementById('lng').value = event.latLng.lng();
            }
        );
        //marker drag event end
        google.maps.event.addListener(marker, 'dragend', function (event) {
            document.getElementById('lat').value = event.latLng.lat();
            document.getElementById('lng').value = event.latLng.lng();
        });
    }

    $(document).on('click', 'button[data-register-new-shipping]', function (event) {
        event.preventDefault();

        let address = $("textarea[name=woo-new-shipping-address]").val();
        let phone = $("input[name=woo-new-shipping-phone]").val();
        let zipcode = $("input[name=woo-new-shipping-zipcode]").val();
        let lat = $("input#lat").val();
        let lng = $("input#lng").val();
        let ID = $("input#address-modify-id").val();

        // Check Valid
        if (address.length < 1) {
            show_overhang("error", "خطا : لطفا آدرس را وارد نمایید", 5000);
            return;
        }
        if (phone.length < 1) {
            show_overhang("error", "خطا : لطفا شماره تماس را وارد نمایید", 5000);
            return;
        }

        // Show Alert
        show_loading();

        // Send Ajax Request
        $.ajax({
            url: app_config.app_url + '/wp-admin/admin-ajax.php',
            type: 'POST',
            dataType: "json",
            cache: false,
            data: {
                'action': 'woo_modify_address',
                'step': 4,
                'token': app_config.token,
                'address': address,
                'phone': phone,
                'zipcode': zipcode,
                'lat': lat,
                'lng': lng,
                'ID': ID
            },
            success: function (data) {
                if (data.status == "yes") {
                    show_overhang("success", data.message, 5000);
                    woo_update_checkout(data);
                    $('#woo_add_address').modal('hide');
                    set_modal_address("", "", "", 35.69439, 51.42151);
                    if (strstr(app_config.page, '/my-account/edit_profile')) {
                        setTimeout(function () {
                            window.location = app_config.page;
                        }, 1000);
                    }
                } else {
                    show_overhang("error", data.message, 5000);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                show_overhang("error", " خطای ارتباط با سرور ایجاد شده لطفا دوباره تلاش کنید ", 5000);
            }
        });
    });

    // Edit Address Show Modal
    $(document).on('click', 'button[data-edit-user-address-id]', function (event) {
        event.preventDefault();
        let vat = $(this);
        set_modal_address(vat.attr("data-address"), vat.attr("data-phone"), vat.attr("data-zipcode"), vat.attr("data-lat"), vat.attr("data-lon"));
        $("input#address-modify-id").val(vat.attr("data-edit-user-address-id"));
        $('#woo_add_address').modal('show');
    });

    // Add to Cart
    function wc_process_cart(product_id, quantity, type) {

        // Show Alert
        show_loading();

        // Send Ajax Request
        $.ajax({
            url: app_config.app_url + '/wp-admin/admin-ajax.php',
            type: 'GET',
            dataType: "json",
            cache: false,
            data: {
                'action': 'woo_add_to_cart',
                'token': app_config.token,
                'product_id': product_id,
                'quantity': quantity,
                'type': type
            },
            success: function (data) {
                if (data.status == "yes") {

                    // Show MSG
                    show_overhang("success", data.message, 5000);

                    // Update top Cart
                    let top_cart = $("span[data-top-cart-item]");
                    if (top_cart.length) {
                        top_cart.html((data.number < 1 ? '' : data.number_i18n));
                    }

                    // Update Cart Items List
                    woo_update_checkout(data);

                } else {
                    show_overhang("error", data.message, 5000);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                show_overhang("error", " خطای ارتباط با سرور ایجاد شده لطفا دوباره تلاش کنید ", 5000);
            }
        });
    }

    // Add To cart Btn
    $(document).on('click', '[data-add-to-cart]', function (event) {
        event.preventDefault();
        let product_id = $(this).attr("data-add-to-cart");
        let quantity = parseInt($(this).attr("data-quanity"));
        let type = $(this).attr("data-cart-action");
        wc_process_cart(product_id, quantity, type);
    });

    // Favorite Product click
    $(document).on('click', '[data-favorite-to-cart]', function (event) {
        event.preventDefault();

        // Get Value
        var product_favorite_id = $(this).attr("data-product-id");

        // Show Alert
        jQuery("body").overhang({
            type: "confirm",
            primary: "#40D47E",
            accent: "#27AE60",
            yesMessage: "بله",
            noMessage: "خیر",
            yesColor: "#3498DB",
            message: "آیا می خواهید به سبد خرید خود اضافه کنید ؟",
            callback: function (value) {
                if (value === true) {
                    wc_process_cart(product_favorite_id, 1, 'add');
                }
            }
        });
    });

    // Remove coupon
    $(document).on('click', '[data-remove-cart-coupon]', function (event) {
        event.preventDefault();

        var coupon = $(this).attr("data-remove-cart-coupon");

        // Show Alert
        show_loading();

        // Send Ajax Request
        $.ajax({
            url: app_config.app_url + '/wp-admin/admin-ajax.php',
            type: 'GET',
            dataType: "json",
            cache: false,
            data: {
                'action': 'woo_remove_coupons',
                'token': app_config.token,
                'coupon': coupon
            },
            success: function (data) {
                if (data.status == "yes") {
                    show_overhang("success", data.message, 5000);
                    woo_update_checkout(data);
                } else {
                    show_overhang("error", data.message, 5000);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                show_overhang("error", " خطای ارتباط با سرور ایجاد شده لطفا دوباره تلاش کنید ", 5000);
            }
        });

    });

    //  Like Or Dislike Product
    $(document).on('click', '[data-favorite-product]', function (event) {
        event.preventDefault();

        // Get Value
        var product_favorite_id = $(this).attr("data-favorite-product");

        // Show Alert
        show_loading();

        // Toggle Class
        var this_event =  $(this);
        this_event.find("i").toggleClass("text-danger");

        // Send Ajax Request
        $.ajax({
            url: app_config.app_url + '/wp-admin/admin-ajax.php',
            type: 'GET',
            dataType: "json",
            cache: false,
            data: {
                'action': 'favorite_product_ajax',
                'token': app_config.token,
                'product_id': product_favorite_id
            },
            success: function (data) {
                if (data.status == "yes") {

                    // Show New List Of Favorite
                    $('#favorite-list ul li:not(:first-child)').remove();
                    let all_item = 7;
                    let html_export = '';
                    data.list.forEach(function (arg) {
                        html_export += `
                        <li>
                        <a href="#" data-favorite-to-cart data-product-id="${arg['ID']}" title="${arg['name']}">
                            <img class="img-responsive" src="${arg['image']}" alt="${arg['name']}">
                        </a>
                    </li>
                      `;
                    });

                    // Check Empty
                    let empty_count = all_item - data.list.length;
                    for (let x = 1; x <= empty_count; x++) {
                        html_export += `
                        <li>
                        <div>
                            <img src="${data.favorite_thumbnail}" alt="غذای مورد علاقه شما" class="favorite-icon">
                        </div>
                    </li>
                      `;
                    }

                    // insert
                    $(html_export).insertAfter("#favorite-list ul li:last-child");

                    // Sow MSG
                    show_overhang("success", (data.message == "like" ? 'غذا به لیست علاقه مندی شما اضافه گردید' : 'غذا از لیست علاقه مندی شما حذف شد'), 5000);

                } else {
                    this_event.find("i").toggleClass("text-danger");
                    show_overhang("error", data.message, 5000);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                this_event.find("i").toggleClass("text-danger");
                show_overhang("error", " خطای ارتباط با سرور ایجاد شده لطفا دوباره تلاش کنید ", 5000);
            }
        });

    });

    // Dislike Form Profile Page
    $(document).on('click', '[data-favorite-product-dislike]', function (event) {
        event.preventDefault();

        // Get Value
        var product_favorite_id = $(this).attr("data-favorite-product-dislike");

        // Show Alert
        show_loading();

        // Send Ajax Request
        $.ajax({
            url: app_config.app_url + '/wp-admin/admin-ajax.php',
            type: 'GET',
            dataType: "json",
            cache: false,
            data: {
                'action': 'favorite_product_ajax',
                'token': app_config.token,
                'product_id': product_favorite_id
            },
            success: function (data) {
                if (data.status == "yes") {
                    show_overhang("success", (data.message == "like" ? 'غذا به لیست علاقه مندی شما اضافه گردید' : 'غذا از لیست علاقه مندی شما حذف شد'), 5000);
                    window.location.replace(app_config.page);
                } else {
                    show_overhang("error", data.message, 5000);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                show_overhang("error", " خطای ارتباط با سرور ایجاد شده لطفا دوباره تلاش کنید ", 5000);
            }
        });

    });


    // Change Tab Horizontal or Vertical Product List
    $(".panjareh").click(function (even) {
        even.preventDefault();
        $(this).toggleClass("text-danger");
        $(".khatti").toggleClass("text-danger");
        $("li.product-box").removeClass('col-md-12').addClass('col-md-4');
        $(".fodImgBox").show();
    });
    $(".khatti").click(function (even) {
        even.preventDefault();
        $(".panjareh").toggleClass("text-danger");
        $(".khatti").toggleClass("text-danger");
        $("li.product-box").removeClass('col-md-4').addClass('col-md-12');
        $(".fodImgBox").hide();
    });

    // Slim Scroll Comment List
    $('div[data-comment-list]').slimScroll({
        color: '#999',
        size: '6px',
        height: '350px'
    });

    // Show All image After Show Modal
    $("div[id^='food_']").on('shown.bs.modal', function () {
        $(this).find('img').each(function (i) {
            let data_src = $(this).attr("data-src");
            $(this).attr("src", data_src);
        });
    });

    // Toggle New Comment Box
    $(document).on('click', 'button[data-toggle-comment-new]', function (event) {
        event.preventDefault();
        let product_id = parseInt($(this).attr("data-toggle-comment-new"));
        $("div[data-comment-food-box=" + product_id + "]").toggleClass('d-none');
        // $(this).hide();
        $('.modal').animate({
            scrollTop: $("button[data-send-comment-for-product-id= " + product_id + "]").offset().top
        }, 2000);
    });

    // Toggle Comment Replay
    $(document).on('click', 'div[data-comment-reply-action]', function (event) {
        event.preventDefault();
        let comment_id = parseInt($(this).attr("data-comment-reply-action"));
        let product_id = parseInt($(this).attr("data-product-id"));
        $("div[data-comment-food-box=" + product_id + "]").toggleClass('d-none');
        $("button[data-toggle-comment-new=" + product_id + "]").remove();
        $("button[data-send-comment-for-product-id=" + product_id + "]").attr("data-comment-parent", comment_id).attr("data-type", "reply");
        $('.modal').animate({
            scrollTop: $("button[data-send-comment-for-product-id= " + product_id + "]").offset().top
        }, 2000);
    });

    // Add to Cart From Modal
    $(document).on('click', 'button[data-add-to-cart-in-modal]', function (event) {
        event.preventDefault();
        let product_id = parseInt($(this).attr("data-add-to-cart-in-modal"));
        wc_process_cart(product_id, 1, 'add');
        $("div[id^='food_" + product_id + "']").modal('hide');
    });

    // Send new Comment For Product
    $(document).on('click', 'button[data-send-comment-for-product-id]', function (event) {
        event.preventDefault();

        var product_id = parseInt($(this).attr("data-send-comment-for-product-id"));
        let type = $(this).attr("data-type");
        let user_id = $(this).attr("data-user-id");
        let content = $("textarea[name=comment-content-" + product_id + "]").val();
        let comment_parent = parseInt($(this).attr("data-comment-parent"));

        // Check Empty Content
        if (content.length < 1) {
            show_overhang("error", "خطا : لطفا متن نظر خود را وارد نمایید", 5000);
            return;
        }

        // Show Alert
        show_loading();

        // Send Ajax
        $.ajax({
            url: app_config.app_url + '/wp-admin/admin-ajax.php',
            type: 'POST',
            dataType: "json",
            cache: false,
            data: {
                'action': 'food_insert_new_comment',
                'token': app_config.token,
                'content': content,
                'product_id': product_id,
                'user_id': user_id,
                'type': type,
                'comment_parent': comment_parent
            },
            success: function (data) {
                if (data.status == "yes") {
                    show_overhang("success", data.message, 5000);
                    $("div[data-comment-food-box=" + product_id + "]").remove();
                } else {
                    show_overhang("error", data.message, 5000);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                show_overhang("error", " خطای ارتباط با سرور ایجاد شده لطفا دوباره تلاش کنید ", 5000);
            }
        });
    });

    // Change Tab Between Menu and Comment
    $(".menuTab1").click(function () {
        $("#tab2").css({display: "none"});
        $("#tab1").css({display: "block"});
        $(".cmntTab2").removeClass("selected_tab");
        $(".menuTab1").addClass("selected_tab");

    });
    $(".cmntTab2").click(function () {
        $("#tab1").css({display: "none"});
        $("#tab2").css({display: "block"});
        $(".menuTab1").removeClass("selected_tab");
        $(".cmntTab2").addClass("selected_tab");
    });
    $(".but1 button").click(function () {
        $(".cmntTab2").removeClass("selected_tab2");
        $(".menuTab1").addClass("selected_tab1");
    });
    $(".but2 button").click(function () {
        $(".menuTab1").removeClass("selected_tab1");
        $(".cmntTab2").addClass("selected_tab2");
        $("#tab2").find('img').each(function (i) {
            let data_src = $(this).attr("data-src");
            $(this).attr("src", data_src);
        });
    });

    // More click
    $(".closeBox").click(function () {
        $(".modalFod").fadeOut();
        $(".FoodTab").animate({marginTop: "-250px"});
    });
});