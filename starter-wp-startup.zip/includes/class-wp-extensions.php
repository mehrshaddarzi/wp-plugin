<?php

// Exit if accessed directly
defined( 'ABSPATH' ) || exit;

/**
 * Main bootstrap class for WP Extensions
 *
 * @package WP Extensions
 */
final class WP_Extensions {
	/**
	 * Holds various class instances
	 *
	 * @var array
	 */
	private $container = array();

	/**
	 * The single instance of the class.
	 *
	 * @var WP-Extensions
	 */
	protected static $_instance = null;

	/**
	 * Main WP-Extensions Instance.
	 * Ensures only one instance of WP-Extensions is loaded or can be loaded.
	 *
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * WP_Extensions constructor.
	 */
	public function __construct() {
		/**
		 * Check PHP Support
		 */
		if ( ! $this->require_php_version() ) {
			add_action( 'admin_notices', array( $this, 'php_version_notice' ) );
			return;
		}

		/**
		 * Plugin Loaded Action
		 */
		add_action( 'plugins_loaded', array( $this, 'plugin_setup' ) );

		/**
		 * Install And Upgrade plugin
		 */
		register_activation_hook( __FILE__, array( $this, 'install' ) );
		register_uninstall_hook( __FILE__, array( 'WP_Extensions', 'uninstall' ) );

		/**
		 * WP-Extensions loaded
		 */
		do_action( 'wp_extensions_loaded' );
	}

	/**
	 * Cloning is forbidden.
	 *
	 * @since 13.0
	 */
	public function __clone() {
		\WP_Extensions\Helper::doing_it_wrong( __CLASS__, esc_html__( 'Cloning is forbidden.', 'wp-extensions' ), '1.0.0' );
	}

	/**
	 * Magic getter to bypass referencing plugin.
	 *
	 * @param $key
	 * @return mixed
	 */
	public function __get( $key ) {
		return $this->container[ $key ];
	}

	/**
	 * Constructors plugin Setup
	 *
	 * @throws Exception
	 */
	public function plugin_setup() {
		/**
		 * Load Text Domain
		 */
		add_action( 'init', array( $this, 'load_textdomain' ) );

		/**
		 * Include Require File
		 */
		$this->includes();

		/**
		 * instantiate Plugin
		 */
		$this->instantiate();
	}

	/**
	 * Includes plugin files
	 */
	public function includes() {

		// Utility classes.
		require_once WP_EXTENSIONS_DIR . 'includes/class-wp-extensions-db.php';
		require_once WP_EXTENSIONS_DIR . 'includes/class-wp-extensions-timezone.php';
		require_once WP_EXTENSIONS_DIR . 'includes/class-wp-extensions-option.php';
		require_once WP_EXTENSIONS_DIR . 'includes/class-wp-extensions-user.php';
		require_once WP_EXTENSIONS_DIR . 'includes/class-wp-extensions-helper.php';
		require_once WP_EXTENSIONS_DIR . 'includes/class-wp-extensions-menus.php';
		require_once WP_EXTENSIONS_DIR . 'includes/class-wp-extensions-rest-api.php';

		// Admin classes
		if ( is_admin() ) {
			require_once WP_EXTENSIONS_DIR . 'includes/class-wp-extensions-install.php';
			require_once WP_EXTENSIONS_DIR . 'includes/admin/class-wp-extensions-admin-template.php';
			require_once WP_EXTENSIONS_DIR . 'includes/admin/class-wp-extensions-admin-ajax.php';
			require_once WP_EXTENSIONS_DIR . 'includes/admin/class-wp-extensions-admin-dashboard.php';
			require_once WP_EXTENSIONS_DIR . 'includes/admin/class-wp-extensions-admin-assets.php';
			require_once WP_EXTENSIONS_DIR . 'includes/admin/class-wp-extensions-admin-notices.php';
			require_once WP_EXTENSIONS_DIR . 'includes/admin/class-wp-extensions-admin-user.php';

			// Admin Pages List
			require_once WP_EXTENSIONS_DIR . 'includes/admin/pages/class-wp-extensions-admin-page-welcome.php';
		}

		// Rest-Api
		require_once WP_EXTENSIONS_DIR . 'includes/api/v1/class-wp-extensions-api-token.php';
	}

	/**
	 * Loads the load plugin text domain code.
	 */
	public function load_textdomain() {
		load_plugin_textdomain( 'wp-extensions', false, WP_EXTENSIONS_DIR . 'languages' );
	}

	/**
	 * Check PHP Version
	 */
	public function require_php_version() {
		if ( ! version_compare( phpversion(), '5.0.4', ">=" ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Show notice about PHP version
	 *
	 * @return void
	 */
	function php_version_notice() {

		$error = __( 'Your installed PHP Version is: ', 'wp-extensions' ) . PHP_VERSION . '. ';
		$error .= __( 'The <strong>WP-Extensions</strong> plugin requires PHP version <strong>', 'wp-extensions' ) . '5.0.4' . __( '</strong> or greater.', 'wp-extensions' );
		?>
        <div class="error">
            <p><?php printf( $error ); ?></p>
        </div>
		<?php
	}

	/**
	 * Create tables on plugin activation
	 *
	 * @param object $network_wide
	 */
	public static function install( $network_wide ) {
		require_once WP_EXTENSIONS_DIR . 'includes/class-wp-extensions-db.php';
		require_once WP_EXTENSIONS_DIR . 'includes/class-wp-extensions-install.php';
		$installer = new \WP_Extensions\Install();
		$installer->install( $network_wide );
	}

	/**
	 * Manage task on plugin deactivation
	 *
	 * @return void
	 */
	public static function uninstall() {
		require_once WP_EXTENSIONS_DIR . 'includes/class-wp-extensions-db.php';
		require_once WP_EXTENSIONS_DIR . 'includes/class-wp-extensions-uninstall.php';
		new \WP_Extensions\Uninstall();
	}

	/**
	 * Instantiate the classes
	 *
	 * @return void
	 * @throws Exception
	 */
	public function instantiate() {

		// Set Options
		$this->container['option'] = new \WP_Extensions\Option();
	}

}
