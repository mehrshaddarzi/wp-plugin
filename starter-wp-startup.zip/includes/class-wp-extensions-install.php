<?php

namespace WP_Extensions;

class Install {

	public function __construct() {

		// Change Plugin Action link in Plugin.php admin
		add_filter( 'plugin_action_links_' . plugin_basename( WP_EXTENSIONS_MAIN_FILE ), array( $this, 'settings_links' ), 10, 2 );
		add_filter( 'plugin_row_meta', array( $this, 'add_meta_links' ), 10, 2 );

		// Upgrades WordPress Plugin
		add_action( 'init', array( $this, 'plugin_upgrades' ) );
	}

	/**
	 * Install
	 *
	 * @param $network_wide
	 */
	public function install( $network_wide ) {

		// Create Default Option in Database
		self::create_options();

		// Set Version information
		update_option( 'wp_extensions_plugin_version', WP_EXTENSIONS_VERSION );
	}

	/**
	 * Adding new MYSQL Table in Activation Plugin
	 *
	 * @param $network_wide
	 */
	public static function create_table( $network_wide ) {
		global $wpdb;

		if ( is_multisite() && $network_wide ) {
			$blog_ids = $wpdb->get_col( "SELECT `blog_id` FROM $wpdb->blogs" );
			foreach ( $blog_ids as $blog_id ) {

				switch_to_blog( $blog_id );
				self::table_sql();
				restore_current_blog();

			}
		} else {
			self::table_sql();
		}
	}

	/**
	 * Create Database Table
	 */
	public static function table_sql() {

		// Load dbDelta WordPress
		self::load_dbDelta();

		// Charset Collate
		$collate = DB::charset_collate();

		// Users Online Table
		$create_user_online_table = ( "
					CREATE TABLE " . DB::table( 'useronline' ) . " (
						ID int(11) NOT NULL AUTO_INCREMENT,
	  					ip varchar(60) NOT NULL,
						created int(11),
						timestamp int(10) NOT NULL,
						date datetime NOT NULL,
						referred text CHARACTER SET utf8 NOT NULL,
						agent varchar(255) NOT NULL,
						platform varchar(255),
						version varchar(255),
						location varchar(10),
						`user_id` BIGINT(48) NOT NULL,
						`page_id` BIGINT(48) NOT NULL,
						`type` VARCHAR(100) NOT NULL
						PRIMARY KEY  (ID)
					) {$collate}" );
		dbDelta( $create_user_online_table );

		// Visit Table
		$create_visit_table = ( "
					CREATE TABLE " . DB::table( 'visit' ) . " (
						ID int(11) NOT NULL AUTO_INCREMENT,
						last_visit datetime NOT NULL,
						last_counter date NOT NULL,
						visit int(10) NOT NULL,
						PRIMARY KEY  (ID),
						UNIQUE KEY unique_date (last_counter)
					) {$collate}" );
		dbDelta( $create_visit_table );

		// Visitor Table
		$create_visitor_table = ( "
					CREATE TABLE " . DB::table( 'visitor' ) . " (
						ID int(11) NOT NULL AUTO_INCREMENT,
						last_counter date NOT NULL,
						referred text NOT NULL,
						agent varchar(255) NOT NULL,
						platform varchar(255),
						version varchar(255),
						UAString varchar(255),
						ip varchar(60) NOT NULL,
						location varchar(10),
						user_id BIGINT(40) NOT NULL,
						hits int(11),
						honeypot int(11),
						PRIMARY KEY  (ID),
						UNIQUE KEY date_ip_agent (last_counter,ip,agent(75),platform(75),version(75)),
						KEY agent (agent),
						KEY platform (platform),
						KEY version (version),
						KEY location (location)
					) {$collate}" );
		dbDelta( $create_visitor_table );

		// Exclusion Table
		$create_exclusion_table = ( "
					CREATE TABLE " . DB::table( 'exclusions' ) . " (
						ID int(11) NOT NULL AUTO_INCREMENT,
						date date NOT NULL,
						reason varchar(255) DEFAULT NULL,
						count bigint(20) NOT NULL,
						PRIMARY KEY  (ID),
						KEY date (date),
						KEY reason (reason)
					) {$collate}" );
		dbDelta( $create_exclusion_table );

		// Pages Table
		$create_pages_table = ( "
					CREATE TABLE " . DB::table( 'pages' ) . " (
					    page_id BIGINT(20) NOT NULL AUTO_INCREMENT,
						uri varchar(255) NOT NULL,
						type varchar(255) NOT NULL,
						date date NOT NULL,
						count int(11) NOT NULL,
						id int(11) NOT NULL,
						UNIQUE KEY date_2 (date,uri),
						KEY url (uri),
						KEY date (date),
						KEY id (id),
						KEY `uri` (`uri`,`count`,`id`),
						ADD PRIMARY KEY (`page_id`)
					) {$collate}" );
		dbDelta( $create_pages_table );

		// Historical Table
		$create_historical_table = ( "
					CREATE TABLE " . DB::table( 'historical' ) . " (
						ID bigint(20) NOT NULL AUTO_INCREMENT,
						category varchar(25) NOT NULL,
						page_id bigint(20) NOT NULL,
						uri varchar(255) NOT NULL,
						value bigint(20) NOT NULL,
						PRIMARY KEY  (ID),
						KEY category (category),
						UNIQUE KEY page_id (page_id),
						UNIQUE KEY uri (uri)
					) {$collate}" );
		dbDelta( $create_historical_table );

		// Search Table
		$create_search_table = ( "
					CREATE TABLE " . DB::table( 'search' ) . " (
						ID bigint(20) NOT NULL AUTO_INCREMENT,
						last_counter date NOT NULL,
						engine varchar(64) NOT NULL,
						host varchar(255),
						words varchar(255),
						visitor bigint(20),
						PRIMARY KEY  (ID),
						KEY last_counter (last_counter),
						KEY engine (engine),
						KEY host (host)
					) {$collate}" );
		dbDelta( $create_search_table );
	}

	/**
	 * Load WordPress dbDelta Function
	 */
	public static function load_dbDelta() {
		if ( ! function_exists( 'dbDelta' ) ) {
			require( ABSPATH . 'wp-admin/includes/upgrade.php' );
		}
	}

	/**
	 * Create Default Option
	 */
	public static function create_options() {

		//Require File For Create Default Option
		require_once WP_EXTENSIONS_DIR . 'includes/class-WP-Extensions-option.php';
		require_once WP_EXTENSIONS_DIR . 'includes/class-WP-Extensions-helper.php';

		// Create Default Option
		update_option( Option::$opt_name, Option::defaultOption() );
	}

	/**
	 * Creating Table for New Blog in wordpress
	 *
	 * @param $blog_id
	 */
	public function add_table_on_create_blog( $blog_id ) {
		if ( is_plugin_active_for_network( plugin_basename( WP_EXTENSIONS_MAIN_FILE ) ) ) {
			switch_to_blog( $blog_id );
			self::table_sql();
			restore_current_blog();
		}
	}

	/**
	 * Remove Table On Delete Blog Wordpress
	 *
	 * @param $tables
	 * @return array
	 */
	public function remove_table_on_delete_blog( $tables ) {
		$tables[] = array_merge( $tables, DB::table( 'all' ) );
		return $tables;
	}

	/**
	 * Add a settings link to the plugin list.
	 *
	 * @param string $links Links
	 * @param string $file Not Used!
	 * @return string Links
	 */
	public function settings_links( $links, $file ) {
		if ( User::Access( 'manage' ) ) {
			array_unshift( $links, '<a href="' . Menus::admin_url( 'settings' ) . '">' . __( 'Settings', 'WP-Extensions' ) . '</a>' );
		}
		return $links;
	}

	/**
	 * Add a WordPress plugin page and rating links to the meta information to the plugin list.
	 *
	 * @param string $links Links
	 * @param string $file File
	 * @return string
	 */
	public function add_meta_links( $links, $file ) {
		if ( $file == plugin_basename( WP_EXTENSIONS_MAIN_FILE ) ) {
			$plugin_url = 'http://wordpress.org/plugins/WP-Extensions/';

			$links[]  = '<a href="' . $plugin_url . '" target="_blank" title="' . __( 'Click here to visit the plugin on WordPress.org', 'WP-Extensions' ) . '">' . __( 'Visit WordPress.org page', 'WP-Extensions' ) . '</a>';
			$rate_url = 'https://wordpress.org/support/plugin/WP-Extensions/reviews/?rate=5#new-post';
			$links[]  = '<a href="' . $rate_url . '" target="_blank" title="' . __( 'Click here to rate and review this plugin on WordPress.org', 'WP-Extensions' ) . '">' . __( 'Rate this plugin', 'WP-Extensions' ) . '</a>';
		}

		return $links;
	}

	/**
	 * Plugin Upgrades
	 */
	public function plugin_upgrades() {
		global $wpdb;

		// Check installed plugin version
		$installed_version = get_option( 'WP_Extensions_plugin_version' );
		if ( $installed_version == WP_EXTENSIONS_VERSION ) {
			return;
		}



		// Store the new version information.
		update_option( 'WP_Extensions_plugin_version', WP_EXTENSIONS_VERSION );
	}
}

new Install;