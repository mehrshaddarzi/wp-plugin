<form method="get">
	<?php _e( 'Date', 'WP-Extensions' ); ?>:
    <input type="hidden" name="page" value="<?php echo $pageName; ?>">
    <input type="text" size="18" name="day" data-wps-date-picker="day" value="<?php echo $day; ?>" autocomplete="off" placeholder="YYYY-MM-DD">
    <input type="submit" value="<?php _e( 'Go', 'WP-Extensions' ); ?>" class="button-primary">
</form>
<div class="wp-clearfix"></div>
<div class="postbox-container" id="wps-big-postbox">
    <div class="metabox-holder">
        <div class="meta-box-sortables">
            <div class="postbox">
                <div class="inside">
					<?php if ( ! is_array( $list ) || ( is_array( $list ) and count( $list ) < 1 ) ) { ?>
                        <div class='wps-center wps-m-top-20'><?php _e( "No information is available for this day.", "WP-Extensions" ); ?></div>
					<?php } else { ?>
                        <table width="100%" class="widefat table-stats">
                            <tr>
                                <td><?php _e( 'Browser', 'WP-Extensions' ); ?></td>
								<?php if ( WP_Extensions\GeoIP::active() ) { ?>
                                    <td><?php _e( 'Country', 'WP-Extensions' ); ?></td>
								<?php } ?>
								<?php if ( WP_Extensions\GeoIP::active( 'city' ) ) { ?>
                                    <td><?php _e( 'City', 'WP-Extensions' ); ?></td>
								<?php } ?>
                                <td><?php _e( 'Date', 'WP-Extensions' ); ?></td>
                                <td><?php _e( 'IP', 'WP-Extensions' ); ?></td>
                                <td><?php _e( 'Platform', 'WP-Extensions' ); ?></td>
                                <td><?php _e( 'User', 'WP-Extensions' ); ?></td>
                                <td><?php _e( 'Referrer', 'WP-Extensions' ); ?></td>
                                <td><?php _e( 'Hits', 'WP-Extensions' ); ?></td>
                            </tr>

							<?php foreach ( $list as $item ) { ?>
                                <tr>
                                    <td style="text-align: left">
                                        <a href="<?php echo $item['browser']['link']; ?>" title="<?php echo $item['browser']['name']; ?>"><img src="<?php echo $item['browser']['logo']; ?>" alt="<?php echo $item['browser']['name']; ?>" class="log-tools" title="<?php echo $item['browser']['name']; ?>"/></a>
                                    </td>
									<?php if ( WP_Extensions\GeoIP::active() ) { ?>
                                        <td style="text-align: left">
                                            <img src="<?php echo $item['country']['flag']; ?>" alt="<?php echo $item['country']['name']; ?>" title="<?php echo $item['country']['name']; ?>" class="log-tools"/>
                                        </td>
									<?php } ?>
									<?php if ( WP_Extensions\GeoIP::active( 'city' ) ) { ?>
                                        <td><?php echo $item['city']; ?></td>
									<?php } ?>
                                    <td style='text-align: left'><span><?php echo $item['date']; ?></span></td>
                                    <td style='text-align: left'><?php echo( isset( $item['hash_ip'] ) ? $item['hash_ip'] : "<a href='" . $item['ip']['link'] . "' class='wps-text-danger'>" . $item['ip']['value'] . "</a>" ); ?></td>
                                    <td style='text-align: left'><?php echo $item['platform']; ?></td>
                                    <td style='text-align: left'>
										<?php if ( isset( $item['user'] ) and isset( $item['user']['ID'] ) and $item['user']['ID'] > 0 ) { ?>
                                            <a href="<?php echo \WP_Extensions\Menus::admin_url( 'visitors', array( 'user_id' => $item['user']['ID'] ) ); ?>" class="wps-text-success"><?php echo $item['user']['user_login']; ?></a>
										<?php } else { ?><?php echo \WP_Extensions\Admin_Template::UnknownColumn(); ?><?php } ?>
                                    </td>
                                    <td style='text-align: left'><?php echo $item['referred']; ?></td>
                                    <td style='text-align: left'><?php echo $item['hits']; ?></td>
                                </tr>
							<?php } ?>
                        </table>
					<?php } ?>
                </div>
            </div>
			<?php echo isset( $pagination ) ? $pagination : ''; ?>
        </div>
    </div>
</div>