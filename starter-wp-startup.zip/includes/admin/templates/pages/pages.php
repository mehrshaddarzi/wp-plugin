<div class="postbox-container" id="wps-big-postbox">
    <div class="metabox-holder">
        <div class="meta-box-sortables">
            <div class="postbox" id="<?php echo \WP_Extensions\Meta_Box::getMetaBoxKey( 'top-pages-chart' ); ?>">
                <button class="handlediv" type="button" aria-expanded="true">
                    <span class="screen-reader-text"><?php printf( __( 'Toggle panel: %s', 'WP-Extensions' ), __( 'Top 5 Pages Trends', 'WP-Extensions' ) ); ?></span>
                    <span class="toggle-indicator" aria-hidden="true"></span>
                </button>
                <h2 class="hndle"><span><?php _e( 'Top 5 Pages Trends', 'WP-Extensions' ); ?></span></h2>
                <div class="inside">
                    <!-- Do Js -->
                </div>
            </div>
        </div>
    </div>
</div>

<div class="postbox-container wps-postbox-full">
    <div class="metabox-holder">
        <div class="meta-box-sortables">
            <div class="postbox" id="<?php echo \WP_Extensions\Meta_Box::getMetaBoxKey( 'pages' ); ?>">
                <button class="handlediv" type="button" aria-expanded="true">
                    <span class="screen-reader-text"><?php printf( __( 'Toggle panel: %s', 'WP-Extensions' ), $title ); ?></span>
                    <span class="toggle-indicator" aria-hidden="true"></span>
                </button>
                <h2 class="hndle"><span><?php echo $title; ?></span></h2>
                <div class="inside">
                    <!-- Do Js -->
                </div>
            </div>
	        <?php echo isset( $pagination ) ? $pagination : ''; ?>
        </div>
    </div>
</div>