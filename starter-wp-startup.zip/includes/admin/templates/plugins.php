<div class="wrap wps-wrap">
	<?php use WP_Extensions\Admin_Helper;
	use WP_Extensions\Admin_Template;

	Admin_Template::show_page_title( __( 'Extensions for WP-Extensions', 'WP-Extensions' ) ); ?>

    <p><p><?php _e( 'These extensions add functionality to your WP-Extensions.', 'WP-Extensions' ); ?></p><br/></p>
    <?php include( WP_EXTENSIONS_DIR . "includes/admin/templates/add-ons.php" ); ?>
</div>