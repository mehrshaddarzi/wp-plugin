<script type="text/javascript">
    function DBMaintWarning() {
        var checkbox = jQuery('#wps_schedule_dbmaint');
        if (checkbox.attr('checked') == 'checked') {
            if (!confirm('<?php _e( 'This will permanently delete data from the database each day, are you sure you want to enable this option?', 'WP-Extensions' ); ?>'))
                checkbox.attr('checked', false);
        }
    }
</script>
<table class="form-table">
    <tbody>
    <tr valign="top">
        <th scope="row" colspan="2"><h3><?php _e( 'Purge Old Data Daily', 'WP-Extensions' ); ?></h3></th>
    </tr>

    <tr valign="top">
        <th scope="row">
            <label for="wps_schedule_dbmaint"><?php _e( 'Enabled:', 'WP-Extensions' ); ?></label>
        </th>

        <td>
            <input id="wps_schedule_dbmaint" type="checkbox" name="wps_schedule_dbmaint" <?php echo WP_Extensions\Option::get( 'schedule_dbmaint' ) == true ? "checked='checked'" : ''; ?> onclick='DBMaintWarning();'>
            <label for="wps_schedule_dbmaint"><?php _e( 'Enable', 'WP-Extensions' ); ?></label>
            <p class="description"><?php _e( 'A WP Cron job will be run daily to purge any data older than a set number of days.', 'WP-Extensions' ); ?></p>
        </td>
    </tr>

    <tr valign="top">
        <th scope="row">
            <label for="wps_schedule_dbmaint_days"><?php _e( 'Purge data older than:', 'WP-Extensions' ); ?></label>
        </th>

        <td>
            <input type="text" class="small-text code" id="wps_schedule_dbmaint_days" name="wps_schedule_dbmaint_days" value="<?php echo htmlentities( WP_Extensions\Option::get( 'schedule_dbmaint_days', "365" ), ENT_QUOTES ); ?>"/>
			<?php _e( 'Days', 'WP-Extensions' ); ?>
            <p class="description"><?php echo __( 'The number of days to keep statistics for.', 'WP-Extensions' ) . ' ' . __( 'Minimum value is 30 days.', 'WP-Extensions' ) . ' ' . __( 'Invalid values will disable the daily maintenance.', 'WP-Extensions' ); ?></p>
        </td>
    </tr>

    <tr valign="top">
        <th scope="row" colspan="2"><h3><?php _e( 'Purge High Hit Count Visitors Daily', 'WP-Extensions' ); ?></h3>
        </th>
    </tr>

    <tr valign="top">
        <th scope="row">
            <label for="wps_schedule_dbmaint_visitor"><?php _e( 'Enabled:', 'WP-Extensions' ); ?></label>
        </th>

        <td>
            <input id="wps_schedule_dbmaint_visitor" type="checkbox" name="wps_schedule_dbmaint_visitor" <?php echo WP_Extensions\Option::get( 'schedule_dbmaint_visitor' ) == true ? "checked='checked'" : ''; ?> onclick='DBMaintWarning();'>
            <label for="wps_schedule_dbmaint_visitor"><?php _e( 'Enable', 'WP-Extensions' ); ?></label>
            <p class="description"><?php _e( 'A WP Cron job will be run daily to purge any users statistics data where the user has more than the defined number of hits in a day (aka they are probably a bot).', 'WP-Extensions' ); ?></p>
        </td>
    </tr>

    <tr valign="top">
        <th scope="row">
            <label for="wps_schedule_dbmaint_visitor_hits"><?php _e( 'Purge visitors with more than:', 'WP-Extensions' ); ?></label>
        </th>

        <td>
            <input type="text" class="small-text code" id="wps_schedule_dbmaint_visitor_hits" name="wps_schedule_dbmaint_visitor_hits" value="<?php echo htmlentities( WP_Extensions\Option::get( 'schedule_dbmaint_visitor_hits', '50' ), ENT_QUOTES ); ?>"/>
			<?php _e( 'Hits', 'WP-Extensions' ); ?>
            <p class="description"><?php echo __( 'The number of hits required to delete the visitor.', 'WP-Extensions' ) . ' ' . __( 'Minimum value is 10 hits.', 'WP-Extensions' ) . ' ' . __( 'Invalid values will disable the daily maintenance.', 'WP-Extensions' ); ?></p>
        </td>
    </tr>

    </tbody>
</table>

<?php submit_button( __( 'Update', 'WP-Extensions' ), 'primary', 'submit' );