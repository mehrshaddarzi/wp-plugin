<table class="form-table">
    <tbody>
    <tr valign="top">
        <td scope="row" align="center">
            <img src="<?php echo plugins_url( 'WP-Extensions/assets/images/logo-250.png' ); ?>" alt="WP-Extensions">
        </td>
    </tr>

    <tr valign="top">
        <td scope="row" align="center">
            <h2><?php echo sprintf( __( 'WP Extensions V%s', 'WP-Extensions' ), WP_EXTENSIONS_VERSION ); ?></h2>
        </td>
    </tr>

    <tr valign="top">
        <td scope="row" align="center">
			<?php echo sprintf( __( 'This product includes GeoLite2 data created by %s.', 'WP-Extensions' ), '<a href="http://www.maxmind.com" target=_blank>MaxMind</a>' ); ?>
        </td>
    </tr>

    <tr valign="top">
        <td scope="row" align="center">
            <hr/>
        </td>
    </tr>

    <tr valign="top">
        <td scope="row" colspan="2"><h2><?php _e( 'Donate', 'WP-Extensions' ); ?></h2></td>
    </tr>

    <tr valign="top">
        <td scope="row" colspan="2"><?php echo sprintf( __( 'Feel like showing us how much you enjoy WP Extensions? Drop by our %sdonation%s page and show us some love!', 'WP-Extensions' ), '<a href="http://WP-Extensions.com/donate" target="_blank">', '</a>' ); ?></td>
    </tr>

    <tr valign="top">
        <td scope="row" colspan="2"><h2><?php _e( 'Visit Us Online', 'WP-Extensions' ); ?></h2></td>
    </tr>

    <tr valign="top">
        <td scope="row" colspan="2"><?php echo sprintf( __( 'Come visit our great new %swebsite%s and keep up to date on the latest news about WP Extensions.', 'WP-Extensions' ), '<a href="http://WP-Extensions.com" target="_blank">', '</a>' ); ?></td>
    </tr>

    <tr valign="top">
        <td scope="row" colspan="2"><h2><?php _e( 'Rate and Review at WordPress.org', 'WP-Extensions' ); ?></h2></td>
    </tr>

    <tr valign="top">
        <td scope="row" colspan="2"><?php printf( __( 'Thanks for installing WP Extensions, we encourage you to submit a %srating and review%s over at WordPress.org. Your feedback is greatly appreciated!', 'WP-Extensions' ), '<a href="https://wordpress.org/support/plugin/WP-Extensions/reviews/?rate=5#new-post" target="_blank">', '</a>' ); ?>
        </td>
    </tr>

    <tr valign="top">
        <td scope="row" colspan="2"><h2><?php _e( 'Translations', 'WP-Extensions' ); ?></h2></td>
    </tr>

    <tr valign="top">
        <td scope="row" colspan="2"><?php echo sprintf( __( 'WP Extensions supports internationalization. Please visit %sWP Extensions translations page%s to help translation.', 'WP-Extensions' ), '<a href="https://WP-Extensions.com/translations/" target="_blank">', '</a>' ); ?></td>
    </tr>

    <tr valign="top">
        <td scope="row" colspan="2"><h2><?php _e( 'Support', 'WP-Extensions' ); ?></h2></td>
    </tr>

    <tr valign="top">
        <td scope="row" colspan="2">
            <p><?php _e( "We're sorry you're having problem with WP Extensions and we're happy to help out. Here are a few things to do before contacting us:", 'WP-Extensions' ); ?></p>

            <ul style="list-style-type: disc; list-style-position: inside; padding-left: 25px;">
                <li><?php echo sprintf( __( 'Have you read the %sFAQs%s?', 'WP-Extensions' ), '<a title="' . __( 'FAQs', 'WP-Extensions' ) . '" href="http://WP-Extensions.com/category/faq/" target="_blank">', '</a>' ); ?></li>
                <li><?php echo sprintf( __( 'Have you read the %sdocumentation%s?', 'WP-Extensions' ), '<a title="' . __( 'Documentation', 'WP-Extensions' ) . '" href="http://WP-Extensions.com/category/documentation/">', '</a>' ); ?></li>
                <li><?php echo sprintf( __( 'Have you search the %ssupport forum%s for a similar issue?', 'WP-Extensions' ), '<a href="http://wordpress.org/support/plugin/WP-Extensions" target="_blank">', '</a>' ); ?></li>
                <li><?php _e( 'Have you search the Internet for any error messages you are receiving?', 'WP-Extensions' ); ?></li>
                <li><?php _e( 'Make sure you have access to your PHP error logs.', 'WP-Extensions' ); ?></li>
            </ul>
            <p><?php _e( 'And a few things to double-check:', 'WP-Extensions' ); ?></p>

            <ul style="list-style-type: disc; list-style-position: inside; padding-left: 25px;">
                <li><?php _e( 'How\'s your memory_limit in php.ini?', 'WP-Extensions' ); ?></li>
                <li><?php _e( 'Have you tried disabling any other plugins you may have installed?', 'WP-Extensions' ); ?></li>
                <li><?php _e( 'Have you tried using the default WordPress theme?', 'WP-Extensions' ); ?></li>
                <li><?php _e( 'Have you double checked the plugin settings?', 'WP-Extensions' ); ?></li>
                <li><?php _e( 'Do you have all the required PHP extensions installed?', 'WP-Extensions' ); ?></li>
                <li><?php echo __( 'Are you getting a blank or incomplete page displayed in your browser?', 'WP-Extensions' ) . ' ' . __( 'Did you view the source for the page and check for any fatal errors?', 'WP-Extensions' ); ?></li>
                <li><?php _e( 'Have you checked your PHP and web server error logs?', 'WP-Extensions' ); ?></li>
            </ul>
            <p><?php _e( 'Still not having any luck?', 'WP-Extensions' ); ?><?php echo sprintf( __( 'Then please open a new thread on the %sWordPress.org support forum%s and we\'ll respond as soon as possible.', 'WP-Extensions' ), '<a href="http://wordpress.org/support/plugin/WP-Extensions" target="_blank">', '</a>' ); ?></p>
        </td>
    </tr>

    </tbody>
</table>