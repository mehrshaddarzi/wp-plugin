<script type="text/javascript">
    function ToggleShowHitsOptions() {
        jQuery('[id^="wps_show_hits_option"]').fadeToggle();
    }
</script>

<table class="form-table">
    <tbody>
    <tr valign="top">
        <th scope="row" colspan="2"><h3><?php _e( 'Online Users', 'WP-Extensions' ); ?></h3></th>
    </tr>

    <tr valign="top">
        <th scope="row">
            <label for="useronline"><?php _e( 'Online User:', 'WP-Extensions' ); ?></label>
        </th>

        <td>
            <input id="useronline" type="checkbox" value="1" name="wps_useronline" <?php echo WP_Extensions\Option::get( 'useronline' ) == true ? "checked='checked'" : ''; ?>>
            <label for="useronline"><?php _e( 'Enable', 'WP-Extensions' ); ?></label>
            <p class="description"><?php _e( 'Enable or disable this feature', 'WP-Extensions' ); ?></p>
        </td>
    </tr>

    <tr valign="top">
        <th scope="row">
            <label for="check_online"><?php _e( 'Check for online users every:', 'WP-Extensions' ); ?></label>
        </th>

        <td>
            <input type="text" class="small-text code" id="check_online" name="wps_check_online" value="<?php echo htmlentities( WP_Extensions\Option::get( 'check_online' ), ENT_QUOTES ); ?>"/>
			<?php _e( 'Seconds', 'WP-Extensions' ); ?>
            <p class="description"><?php echo sprintf( __( 'Time for the check accurate online user in the site. Now: %s Seconds', 'WP-Extensions' ), WP_Extensions\Option::get( 'check_online' ) ); ?></p>
        </td>
    </tr>

    <tr valign="top">
        <th scope="row">
            <label for="allonline"><?php _e( 'Record all user:', 'WP-Extensions' ); ?></label>
        </th>

        <td>
            <input id="allonline" type="checkbox" value="1" name="wps_all_online" <?php echo WP_Extensions\Option::get( 'all_online' ) == true ? "checked='checked'" : ''; ?>>
            <label for="allonline"><?php _e( 'Enable', 'WP-Extensions' ); ?></label>
            <p class="description"><?php _e( 'Ignores the exclusion settings and records all users that are online (including self referrals and robots). Should only be used for troubleshooting.', 'WP-Extensions' ); ?></p>
        </td>
    </tr>

    <tr valign="top">
        <th scope="row" colspan="2"><h3><?php _e( 'Visits', 'WP-Extensions' ); ?></h3></th>
    </tr>

    <tr valign="top">
        <th scope="row">
            <label for="visits"><?php _e( 'Visits:', 'WP-Extensions' ); ?></label>
        </th>

        <td>
            <input id="visits" type="checkbox" value="1" name="wps_visits" <?php echo WP_Extensions\Option::get( 'visits' ) == true ? "checked='checked'" : ''; ?>>
            <label for="visits"><?php _e( 'Enable', 'WP-Extensions' ); ?></label>
            <p class="description"><?php _e( 'Enable or disable this feature', 'WP-Extensions' ); ?></p>
        </td>
    </tr>

    <tr valign="top">
        <th scope="row" colspan="2"><h3><?php _e( 'Visitors', 'WP-Extensions' ); ?></h3></th>
    </tr>

    <tr valign="top" id="visitors_tr">
        <th scope="row">
            <label for="visitors"><?php _e( 'Visitors:', 'WP-Extensions' ); ?></label>
        </th>
        <td>
            <input id="visitors" type="checkbox" value="1" name="wps_visitors" <?php echo WP_Extensions\Option::get( 'visitors' ) == true ? "checked='checked'" : ''; ?>>
            <label for="visitors"><?php _e( 'Enable', 'WP-Extensions' ); ?></label>
            <p class="description"><?php _e( 'Enable or disable this feature', 'WP-Extensions' ); ?></p>
        </td>
    </tr>

    <tr valign="top" data-view="visitors_log_tr" <?php echo( WP_Extensions\Option::get( 'visitors' ) == false ? 'style="display:none;"' : '' ) ?>>
        <th scope="row">
            <label for="visitors_log"><?php _e( 'Visitors logs:', 'WP-Extensions' ); ?></label>
        </th>
        <td>
            <input id="visitors_log" type="checkbox" value="1" name="wps_visitors_log" <?php echo WP_Extensions\Option::get( 'visitors_log' ) == true ? "checked='checked'" : ''; ?>>
            <label for="visitors_log"><?php _e( 'Enable', 'WP-Extensions' ); ?></label>
            <p class="description"><?php _e( 'If enabled, you will receive a report of each user\'s visit to the pages', 'WP-Extensions' ); ?></p>
        </td>
    </tr>

    <tr valign="top" data-view="visitors_log_tr" <?php echo( WP_Extensions\Option::get( 'visitors' ) == false ? 'style="display:none;"' : '' ) ?>>
        <th scope="row">
            <label for="enable_user_column"><?php _e( 'User visits column', 'WP-Extensions' ); ?></label>
        </th>
        <td>
            <input id="enable_user_column" type="checkbox" value="1" name="wps_enable_user_column" <?php echo WP_Extensions\Option::get( 'enable_user_column' ) == true ? "checked='checked'" : ''; ?>>
            <label for="enable_user_column"><?php _e( 'Enable', 'WP-Extensions' ); ?></label>
            <p class="description"><?php _e( 'Enable or disable show list of user visits link in WordPress admin user list page.', 'WP-Extensions' ); ?></p>
        </td>
    </tr>

    <tr valign="top" data-view="visitors_log_tr" <?php echo( WP_Extensions\Option::get( 'visitors' ) == false ? 'style="display:none;"' : '' ) ?>>
        <th scope="row">
            <label for="coefficient"><?php _e( 'Coefficient per visitor:', 'WP-Extensions' ); ?></label>
        </th>
        <td>
            <input type="text" class="small-text code" id="coefficient" name="wps_coefficient" value="<?php echo htmlentities( WP_Extensions\Option::get( 'coefficient' ), ENT_QUOTES ); ?>"/>
            <p class="description"><?php echo sprintf( __( 'For each visit to account for several hits. Currently %s.', 'WP-Extensions' ), WP_Extensions\Option::get( 'coefficient' ) ); ?></p>
        </td>
    </tr>

    <tr valign="top">
        <th scope="row" colspan="2"><h3><?php _e( 'Pages and Posts', 'WP-Extensions' ); ?></h3></th>
    </tr>

    <tr valign="top">
        <th scope="row">
            <label for="pages"><?php _e( 'Pages:', 'WP-Extensions' ); ?></label>
        </th>
        <td>
            <input id="pages" type="checkbox" value="1" name="wps_pages" <?php echo WP_Extensions\Option::get( 'pages' ) == true ? "checked='checked'" : ''; ?>>
            <label for="pages"><?php _e( 'Enable', 'WP-Extensions' ); ?></label>
            <p class="description"><?php _e( 'Enable or disable this feature', 'WP-Extensions' ); ?></p>
        </td>
    </tr>

    <tr valign="top">
        <th scope="row">
            <label for="all_pages"><?php _e( 'Track all pages:', 'WP-Extensions' ); ?></label>
        </th>
        <td>
            <input id="all_pages" type="checkbox" value="1" name="wps_track_all_pages" <?php echo WP_Extensions\Option::get( 'track_all_pages' ) == true ? "checked='checked'" : ''; ?>>
            <label for="all_pages"><?php _e( 'Enable', 'WP-Extensions' ); ?></label>
            <p class="description"><?php _e( 'Enable or disable this feature', 'WP-Extensions' ); ?></p>
            <p class="description"><?php echo sprintf( __( 'Track All Wordpress Page Contains Category, Post Tags, Author, Custom Taxonomy and ...', 'WP-Extensions' ), admin_url( 'options-permalink.php' ) ); ?></p>
        </td>
    </tr>

	<?php
	if ( ! $disable_strip_uri_parameters ) {
		?>
        <tr valign="top">
            <th scope="row">
                <label for="strip_uri_parameters"><?php _e( 'Strip parameters from URI:', 'WP-Extensions' ); ?></label>
            </th>

            <td>
                <input id="strip_uri_parameters" type="checkbox" value="1" name="wps_strip_uri_parameters" <?php echo WP_Extensions\Option::get( 'strip_uri_parameters' ) == true ? "checked='checked'" : ''; ?>>
                <label for="strip_uri_parameters"><?php _e( 'Enable', 'WP-Extensions' ); ?></label>

                <p class="description"><?php _e( 'This will remove anything after the ? in a URL.', 'WP-Extensions' ); ?></p>
            </td>
        </tr>
		<?php
	}
	?>

    <tr valign="top">
        <th scope="row">
            <label for="disable_column"><?php _e( 'Hits chart', 'WP-Extensions' ); ?></label>
        </th>

        <td>
            <input id="disable-editor" type="checkbox" value="1" name="wps_disable_editor" <?php echo WP_Extensions\Option::get( 'disable_editor' ) == true ? "checked='checked'" : ''; ?>>
            <label for="disable-editor"><?php _e( 'Disable', 'WP-Extensions' ); ?></label>
            <p class="description"><?php _e( 'Show Hit Chart in the WordPress page/post editor.', 'WP-Extensions' ); ?></p>
        </td>
    </tr>

    <tr valign="top">
        <th scope="row">
            <label for="disable_column"><?php _e( 'Hits column', 'WP-Extensions' ); ?></label>
        </th>
        <td>
            <input id="disable_column" type="checkbox" value="1" name="wps_disable_column" <?php echo WP_Extensions\Option::get( 'disable_column' ) == true ? "checked='checked'" : ''; ?>>
            <label for="disable_column"><?php _e( 'Disable', 'WP-Extensions' ); ?></label>
            <p class="description"><?php _e( 'Enable or disable show page/post hits number column.', 'WP-Extensions' ); ?></p>
        </td>
    </tr>

    <tr valign="top">
        <th scope="row">
            <label for="hit_post_metabox"><?php _e( 'Hits in submit box:', 'WP-Extensions' ); ?></label>
        </th>

        <td>
            <input id="hit_post_metabox" type="checkbox" value="1" name="wps_hit_post_metabox" <?php echo WP_Extensions\Option::get( 'hit_post_metabox' ) == true ? "checked='checked'" : ''; ?>>
            <label for="hit_post_metabox"><?php _e( 'Enable', 'WP-Extensions' ); ?></label>
            <p class="description"><?php _e( 'Show hits number in the page/post submit box.', 'WP-Extensions' ); ?></p>
        </td>
    </tr>

    <tr valign="top">
        <th scope="row">
            <label for="show_hits"><?php _e( 'Hits in single page:', 'WP-Extensions' ); ?></label>
        </th>

        <td>
            <input id="show_hits" type="checkbox" value="1" name="wps_show_hits" <?php echo WP_Extensions\Option::get( 'show_hits' ) == true
				? "checked='checked'" : ''; ?> onClick='ToggleShowHitsOptions();'>
            <label for="show_hits"><?php _e( 'Enable', 'WP-Extensions' ); ?></label>

            <p class="description"><?php _e( 'Enable or disable show hits in content', 'WP-Extensions' ); ?></p>
        </td>
    </tr>

	<?php if ( WP_Extensions\Option::get( 'show_hits' ) ) {
		$hidden = "";
	} else {
		$hidden = " style='display: none;'";
	} ?>
    <tr valign="top"<?php echo $hidden; ?> id='wps_show_hits_option'>
        <td scope="row" style="vertical-align: top;">
            <label for="display_hits_position"><?php _e( 'Display position:', 'WP-Extensions' ); ?></label>
        </td>

        <td>
            <select name="wps_display_hits_position" id="display_hits_position">
                <option value="0" <?php selected( WP_Extensions\Option::get( 'display_hits_position' ), '0' ); ?>><?php _e( 'Please select', 'WP-Extensions' ); ?></option>
                <option value="before_content" <?php selected( WP_Extensions\Option::get( 'display_hits_position' ), 'before_content' ); ?>><?php _e( 'Before Content', 'WP-Extensions' ); ?></option>
                <option value="after_content" <?php selected( WP_Extensions\Option::get( 'display_hits_position' ), 'after_content' ); ?>><?php _e( 'After Content', 'WP-Extensions' ); ?></option>
            </select>
            <p class="description"><?php _e( 'Choose the position to show Hits.', 'WP-Extensions' ); ?></p>
        </td>
    </tr>

    <tr valign="top">
        <th scope="row" colspan="2"><h3><?php _e( 'Cache Plugin', 'WP-Extensions' ); ?></h3></th>
    </tr>

    <tr valign="top">
        <th scope="row">
            <label for="all_pages"><?php _e( 'Use Cache Plugin:', 'WP-Extensions' ); ?></label>
        </th>

        <td>
            <input id="use_cache_plugin" type="checkbox" value="1" name="wps_use_cache_plugin" <?php echo WP_Extensions\Option::get( 'use_cache_plugin' ) == true ? "checked='checked'" : ''; ?>>
            <label for="use_cache_plugin"><?php _e( 'Yes', 'WP-Extensions' ); ?></label>
            <p class="description"><?php _e( 'If you use WordPress Cache Plugins, enable this option.', 'WP-Extensions' ); ?></p>
            <p class="description"><?php echo sprintf( __( 'To register WP-Extensions REST API endpoint  ( %s ) , go to the <a href="%s">Permalink page</a> and update the permalink with press Save Changes.', 'WP-Extensions' ), WP_Extensions\RestAPI::$namespace, admin_url( 'options-permalink.php' ) ); ?></p>
            <p class="description"><?php echo __( 'Don\'t forget to clear your enabled plugin cache.', 'WP-Extensions' ); ?></p>
        </td>
    </tr>


    <tr valign="top">
        <th scope="row" colspan="2"><h3><?php _e( 'Miscellaneous', 'WP-Extensions' ); ?></h3></th>
    </tr>

    <tr valign="top">
        <th scope="row">
            <label for="menu-bar"><?php _e( 'Show stats in menu bar:', 'WP-Extensions' ); ?></label>
        </th>

        <td>
            <select name="wps_menu_bar" id="menu-bar">
                <option value="0" <?php selected( WP_Extensions\Option::get( 'menu_bar' ), '0' ); ?>><?php _e( 'No', 'WP-Extensions' ); ?></option>
                <option value="1" <?php selected( WP_Extensions\Option::get( 'menu_bar' ), '1' ); ?>><?php _e( 'Yes', 'WP-Extensions' ); ?></option>
            </select>
            <p class="description"><?php _e( 'Show stats in admin menu bar', 'WP-Extensions' ); ?></p>
        </td>
    </tr>

    <tr valign="top">
        <th scope="row">
            <label for="hide_notices"><?php _e( 'Hide admin notices about non active features:', 'WP-Extensions' ); ?></label>
        </th>

        <td>
            <input id="hide_notices" type="checkbox" value="1" name="wps_hide_notices" <?php echo WP_Extensions\Option::get( 'hide_notices' ) == true ? "checked='checked'" : ''; ?>>
            <label for="hide_notices"><?php _e( 'Enable', 'WP-Extensions' ); ?></label>

            <p class="description"><?php _e( 'By default WP Extensions displays an alert if any of the core features are disabled on every admin page, this option will disable these notices.', 'WP-Extensions' ); ?></p>
        </td>
    </tr>

    <tr valign="top">
        <th scope="row" colspan="2"><h3><?php _e( 'Search Engines', 'WP-Extensions' ); ?></h3></th>
    </tr>

    <tr valign="top">
        <th scope="row">
            <label for="addsearchwords"><?php _e( 'Add page title to empty search words:', 'WP-Extensions' ); ?></label>
        </th>

        <td>
            <input id="addsearchwords" type="checkbox" value="1" name="wps_addsearchwords" <?php echo WP_Extensions\Option::get( 'addsearchwords' ) == true ? "checked='checked'" : ''; ?>>
            <label for="addsearchwords"><?php _e( 'Enable', 'WP-Extensions' ); ?></label>
            <p class="description"><?php _e( 'If a search engine is identified as the referrer but it does not include the search query this option will substitute the page title in quotes preceded by "~:" as the search query to help identify what the user may have been searching for.', 'WP-Extensions' ); ?></p>
        </td>
    </tr>

    <tr valign="top">
        <th scope="row" colspan="2">
            <p class="description"><?php _e( 'Disabling all search engines is not allowed, doing so will result in all search engines being active.', 'WP-Extensions' ); ?></p>
        </th>
    </tr>
	<?php
	$se_option_list = '';

	foreach ( $selist as $se ) {
		$option_name    = 'wps_disable_se_' . $se['tag'];
		$store_name     = 'disable_se_' . $se['tag'];
		$se_option_list .= $option_name . ',';
		?>

        <tr valign="top">
            <th scope="row">
                <label for="<?php echo $option_name; ?>"><?php _e( $se['name'], 'WP-Extensions' ); ?>:</label>
            </th>
            <td>
                <input id="<?php echo $option_name; ?>" type="checkbox" value="1" name="<?php echo $option_name; ?>" <?php echo WP_Extensions\Option::get( $store_name ) == true ? "checked='checked'" : ''; ?>><label for="<?php echo $option_name; ?>"><?php _e( 'Disable', 'WP-Extensions' ); ?></label>
                <p class="description"><?php echo sprintf( __( 'Disable %s from data collection and reporting.', 'WP-Extensions' ), $se['name'] ); ?></p>
            </td>
        </tr>
	<?php } ?>

    <tr valign="top">
        <th scope="row" colspan="2"><h3><?php _e( 'Charts', 'WP-Extensions' ); ?></h3></th>
    </tr>

    <tr valign="top">
        <th scope="row">
            <label for="chart-totals"><?php _e( 'Include totals:', 'WP-Extensions' ); ?></label>
        </th>
        <td>
            <input id="chart-totals" type="checkbox" value="1" name="wps_chart_totals" <?php echo WP_Extensions\Option::get( 'chart_totals' ) == true ? "checked='checked'" : ''; ?>>
            <label for="chart-totals"><?php _e( 'Enable', 'WP-Extensions' ); ?></label>
            <p class="description"><?php _e( 'Add a total line to charts with multiple values, like the search engine referrals', 'WP-Extensions' ); ?></p>
        </td>
    </tr>

    </tbody>
</table>

<?php submit_button( __( 'Update', 'WP-Extensions' ), 'primary', 'submit' );