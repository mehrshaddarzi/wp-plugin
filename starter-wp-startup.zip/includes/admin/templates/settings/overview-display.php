<?php
// Only display the global options if the user is an administrator.
if ( $wps_admin ) {
	?>
    <table class="form-table">
        <tbody>
        <tr valign="top">
            <th scope="row" colspan="2"><h3><?php _e( 'Dashboard', 'WP-Extensions' ); ?></h3></th>
        </tr>

        <tr valign="top">
            <td scope="row" colspan="2"><?php _e( 'The following items are global to all users.', 'WP-Extensions' ); ?></td>
        </tr>

        <tr valign="top">
            <th scope="row">
                <label for="disable-map"><?php _e( 'Disable dashboard widgets:', 'WP-Extensions' ); ?></label>
            </th>

            <td>
                <input id="disable-dashboard" type="checkbox" value="1" name="wps_disable_dashboard" <?php echo WP_Extensions\Option::get( 'disable_dashboard' ) == true ? "checked='checked'" : ''; ?>>
                <label for="disable-dashboard"><?php _e( 'Disable', 'WP-Extensions' ); ?></label>
                <p class="description"><?php _e( 'Disable the dashboard widgets.', 'WP-Extensions' ); ?></p>
            </td>
        </tr>

        <tr valign="top">
            <th scope="row" colspan="2"><h3><?php _e( 'Map', 'WP-Extensions' ); ?></h3></th>
        </tr>

        <tr valign="top">
            <td scope="row" colspan="2"><?php _e( 'The following items are global to all users.', 'WP-Extensions' ); ?></td>
        </tr>

        <tr valign="top">
            <th scope="row">
                <label for="disable-map"><?php _e( 'Disable map:', 'WP-Extensions' ); ?></label>
            </th>

            <td>
                <input id="disable-map" type="checkbox" value="1" name="wps_disable_map" <?php echo WP_Extensions\Option::get( 'disable_map' ) == true ? "checked='checked'" : ''; ?>>
                <label for="disable-map"><?php _e( 'Disable', 'WP-Extensions' ); ?></label>
                <p class="description"><?php _e( 'Disable the map display', 'WP-Extensions' ); ?></p>
            </td>
        </tr>

        </tbody>
    </table>
	<?php
}

submit_button( __( 'Update', 'WP-Extensions' ), 'primary', 'submit' );
