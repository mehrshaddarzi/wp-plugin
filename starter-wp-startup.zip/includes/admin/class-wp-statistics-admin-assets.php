<?php

namespace WP_Extensions;

class Admin_Assets {
	/**
	 * Prefix Of Load Css/Js in WordPress Admin
	 *
	 * @var string
	 */
	public static $prefix = 'WP-Extensions-admin';

	/**
	 * Suffix Of Minify File in Assets
	 *
	 * @var string
	 */
	public static $suffix_min = '.min';

	/**
	 * Assets Folder name in Plugin
	 *
	 * @var string
	 */
	public static $asset_dir = 'assets';

	/**
	 * Basic Of Plugin Url in Wordpress
	 *
	 * @var string
	 * @example http://site.com/wp-content/plugins/my-plugin/
	 */
	public static $plugin_url = WP_EXTENSIONS_URL;

	/**
	 * Current Asset Version for this plugin
	 *
	 * @var string
	 */
	public static $asset_version = WP_EXTENSIONS_VERSION;

	/**
	 * Admin_Assets constructor.
	 */
	public function __construct() {
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_styles' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );
	}

	/**
	 * Get Version of File
	 *
	 * @param $ver
	 * @return bool
	 */
	public static function version( $ver = false ) {
		if ( $ver ) {
			return $ver;
		} else {
			if ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) {
				return time();
			} else {
				return self::$asset_version;
			}
		}
	}

	/**
	 * Get Asset Url
	 *
	 * @param $file_name
	 * @return string
	 */
	public static function url( $file_name ) {

		// Get file Extension Type
		$ext = pathinfo( $file_name, PATHINFO_EXTENSION );
		if ( $ext != "js" and $ext != "css" ) {
			$ext = 'images';
		}

		// Prepare File Path
		$path = self::$asset_dir . '/' . $ext . '/';

		// Prepare Full Url
		$url = self::$plugin_url . $path;

		// Return Url
		return $url . $file_name;
	}

	/**
	 * Enqueue styles.
	 */
	public function admin_styles() {

		// Get Current Screen ID
		$screen_id = Helper::get_screen_id();

		// Load Admin Css
		wp_enqueue_style( self::$prefix, self::url( 'admin.min.css' ), array(), self::version() );

		// Load Rtl Version Css
		if ( is_rtl() ) {
			wp_enqueue_style( self::$prefix . '-rtl', self::url( 'rtl.min.css' ), array(), self::version() );
		}

		//Load Jquery VMap Css
		if ( ! Option::get( 'disable_map' ) and ( Menus::in_page( 'overview' ) || ( in_array( $screen_id, array( 'dashboard' ) ) and ! Option::get( 'disable_dashboard' ) ) ) ) {
			wp_enqueue_style( self::$prefix . '-jqvmap', self::url( 'jqvmap/jqvmap.min.css' ), array(), '1.5.1' );
		}

		// Load Jquery-ui theme
		if ( Menus::in_plugin_page() and Menus::in_page( 'optimization' ) === false and Menus::in_page( 'settings' ) === false ) {
			wp_enqueue_style( self::$prefix . '-jquery-datepicker', self::url( 'datepicker.min.css' ), array(), '1.11.4' );
		}

		// Load Select2
		if ( Menus::in_page( 'visitors' ) || ( Menus::in_page( 'pages' ) and isset( $_GET['ID'] ) ) ) {
			wp_enqueue_style( self::$prefix . '-select2', self::url( 'select2/select2.min.css' ), array(), '4.0.7' );
		}
	}

	/**
	 * Enqueue scripts.
	 *
	 * @param $hook [ Page Now ]
	 */
	public function admin_scripts( $hook ) {

		// Get Current Screen ID
		$screen_id = Helper::get_screen_id();

		// Load Chart Js Library [ Load in <head> Tag ]
		if ( Menus::in_plugin_page() || ( in_array( $screen_id, array( 'dashboard' ) ) and ! Option::get( 'disable_dashboard' ) ) || ( in_array( $hook, array( 'post.php', 'edit.php', 'post-new.php' ) ) and ! Option::get( 'disable_editor' ) ) ) {
			wp_enqueue_script( self::$prefix . '-chart.js', self::url( 'chartjs/chart.bundle.min.js' ), false, '2.8.0', false );
		}

		// Load Jquery VMap Js Library
		if ( ! Option::get( 'disable_map' ) and ( Menus::in_page( 'overview' ) || ( in_array( $screen_id, array( 'dashboard' ) ) and ! Option::get( 'disable_dashboard' ) ) ) ) {
			wp_enqueue_script( self::$prefix . '-jqvmap', self::url( 'jqvmap/jquery.vmap.min.js' ), true, '1.5.1' );
			wp_enqueue_script( self::$prefix . '-jqvmap-world', self::url( 'jqvmap/jquery.vmap.world.min.js' ), true, '1.5.1' );
		}

		// Load Jquery UI
		if ( Menus::in_plugin_page() and Menus::in_page( 'optimization' ) === false and Menus::in_page( 'settings' ) === false ) {
			wp_enqueue_script( 'jquery-ui-datepicker' );
			wp_localize_script( 'jquery-ui-datepicker', 'wps_i18n_jquery_datepicker', self::localize_jquery_datepicker() );
		}

		// Load Select2
		if ( Menus::in_page( 'visitors' ) || ( Menus::in_page( 'pages' ) and isset( $_GET['ID'] ) ) ) {
			wp_enqueue_script( self::$prefix . '-select2', self::url( 'select2/select2.full.min.js' ), array( 'jquery' ), '4.0.7' );
		}

		// Load WordPress PostBox Script
		if ( Menus::in_plugin_page() and Menus::in_page( 'optimization' ) === false and Menus::in_page( 'settings' ) === false ) {
			wp_enqueue_script( 'common' );
			wp_enqueue_script( 'wp-lists' );
			wp_enqueue_script( 'postbox' );
		}

		// Load Admin Js
		if ( Menus::in_plugin_page() || ( in_array( $screen_id, array( 'dashboard' ) ) and ! Option::get( 'disable_dashboard' ) ) || ( in_array( $hook, array( 'post.php', 'edit.php', 'post-new.php' ) ) and ! Option::get( 'disable_editor' ) ) ) {
			wp_enqueue_script( self::$prefix, self::url( 'admin.min.js' ), array( 'jquery' ), self::version() );
			wp_localize_script( self::$prefix, 'wps_global', self::wps_global( $hook ) );
		}

		// Load TinyMCE for Widget Page
		if ( in_array( $screen_id, array( 'widgets' ) ) ) {
			wp_enqueue_script( self::$prefix . '-button-widget', self::url( 'tinymce.min.js' ), array( 'jquery' ), self::version() );
		}

		// Add Thick box
		if ( Menus::in_page( 'visitors' ) ) {
			wp_enqueue_script( 'thickbox' );
			wp_enqueue_style( 'thickbox' );
		}
	}

	/**
	 * Prepare global WP-Extensions data for use Admin Js
	 *
	 * @param $hook
	 * @return mixed
	 */
	public static function wps_global( $hook ) {
		global $post;

		//Global Option
		$list['options'] = array(
			'rtl'           => ( is_rtl() ? 1 : 0 ),
			'user_online'   => ( Option::get( 'useronline' ) ? 1 : 0 ),
			'visitors'      => ( Option::get( 'visitors' ) ? 1 : 0 ),
			'visits'        => ( Option::get( 'visits' ) ? 1 : 0 ),
			'geo_ip'        => ( GeoIP::active() ? 1 : 0 ),
			'geo_city'      => ( GeoIP::active( 'city' ) ? 1 : 0 ),
			'overview_page' => ( Menus::in_page( 'overview' ) ? 1 : 0 ),
			'gutenberg'     => ( Helper::is_gutenberg() ? 1 : 0 ),
			'more_btn'      => ( apply_filters( 'WP_Extensions_meta_box_more_button', true ) ? 1 : 0 )
		);

		// WordPress Current Page
		$list['page'] = array(
			'file' => $hook,
			'ID'   => ( isset( $post ) ? $post->ID : 0 )
		);

		// WordPress Admin Page request Params
		if ( isset( $_GET ) ) {
			foreach ( $_GET as $key => $value ) {
				if ( $key == "page" ) {
					$slug  = Menus::getPageKeyFromSlug( $value );
					$value = $slug[0];
				}
				$list['request_params'][ $key ] = $value;
			}
		}

		// Global Lang
		$list['i18n'] = array(
			'more_detail'   => __( 'More Details', 'WP-Extensions' ),
			'reload'        => __( 'Reload', 'WP-Extensions' ),
			'online_users'  => __( 'Online Users', 'WP-Extensions' ),
			'visitors'      => __( 'Visitors', 'WP-Extensions' ),
			'visits'        => __( 'Visits', 'WP-Extensions' ),
			'today'         => __( 'Today', 'WP-Extensions' ),
			'yesterday'     => __( 'Yesterday', 'WP-Extensions' ),
			'week'          => __( 'Last 7 Days (Week)', 'WP-Extensions' ),
			'month'         => __( 'Last 30 Days (Month)', 'WP-Extensions' ),
			'year'          => __( 'Last 365 Days (Year)', 'WP-Extensions' ),
			'total'         => __( 'Total', 'WP-Extensions' ),
			'daily_total'   => __( 'Daily Total', 'WP-Extensions' ),
			'date'          => __( 'Date', 'WP-Extensions' ),
			'time'          => __( 'Time', 'WP-Extensions' ),
			'browsers'      => __( 'Browsers', 'WP-Extensions' ),
			'rank'          => __( 'Rank', 'WP-Extensions' ),
			'flag'          => __( 'Flag', 'WP-Extensions' ),
			'country'       => __( 'Country', 'WP-Extensions' ),
			'visitor_count' => __( 'Visitor Count', 'WP-Extensions' ),
			'id'            => __( 'ID', 'WP-Extensions' ),
			'title'         => __( 'Title', 'WP-Extensions' ),
			'link'          => __( 'Link', 'WP-Extensions' ),
			'address'       => __( 'Address', 'WP-Extensions' ),
			'word'          => __( 'Word', 'WP-Extensions' ),
			'browser'       => __( 'Browser', 'WP-Extensions' ),
			'city'          => __( 'City', 'WP-Extensions' ),
			'ip'            => __( 'IP', 'WP-Extensions' ),
			'referrer'      => __( 'Referrer', 'WP-Extensions' ),
			'hits'          => __( 'Hits', 'WP-Extensions' ),
			'agent'         => __( 'Agent', 'WP-Extensions' ),
			'platform'      => __( 'Platform', 'WP-Extensions' ),
			'version'       => __( 'Version', 'WP-Extensions' ),
			'page'          => __( 'Page', 'WP-Extensions' ),
			'str_week'      => __( 'Week', 'WP-Extensions' ),
			'str_month'     => __( 'Month', 'WP-Extensions' ),
			'str_year'      => __( 'Year', 'WP-Extensions' ),
			'custom'        => __( 'Custom', 'WP-Extensions' ),
			'to'            => __( 'to', 'WP-Extensions' ),
			'from'          => __( 'from', 'WP-Extensions' ),
			'go'            => __( 'Go', 'WP-Extensions' ),
			'no_data'       => __( 'No data to display', 'WP-Extensions' ),
			'count'         => __( 'Count', 'WP-Extensions' ),
			'percentage'    => __( 'Percentage', 'WP-Extensions' ),
			'version_list'  => __( 'Version List', 'WP-Extensions' ),
			'filter'        => __( 'Filter', 'WP-Extensions' ),
			'all'           => __( 'All', 'WP-Extensions' ),
			'er_datepicker' => __( 'Please select the time efficiency.', 'WP-Extensions' ),
			'er_valid_ip'   => __( 'Please enter a valid ip.', 'WP-Extensions' ),
			'please_wait'   => __( 'Please Wait ...', 'WP-Extensions' ),
			'user'          => __( 'User', 'WP-Extensions' ),
		);

		// Rest-API Meta Box Url
		$list['admin_url']      = admin_url();
		$list['rest_api_nonce'] = wp_create_nonce( 'wp_rest' );
		$list['meta_box_api']   = get_rest_url( null, RestAPI::$namespace . '/metabox' );

		// Meta Box List
		$meta_boxes_list    = Meta_Box::getList();
		$list['meta_boxes'] = array();
		foreach ( $meta_boxes_list as $meta_box => $value ) {

			// Convert Page Url
			if ( isset( $value['page_url'] ) ) {
				$value['page_url'] = Menus::get_page_slug( $value['page_url'] );
			}

			// Add Post ID Params To Post Widget Link
			if ( $meta_box == "post" and isset( $post ) and in_array( $post->post_status, array( "publish", "private" ) ) ) {
				$value['page_url'] = add_query_arg( 'page-id', $post->ID, $value['page_url'] );
			}

			// Remove unnecessary params
			foreach ( array( 'show_on_dashboard', 'hidden', 'place', 'require', 'js', 'disable_overview' ) as $param ) {
				unset( $value[ $param ] );
			}

			// Add Meta Box Lang
			$class = Meta_Box::getMetaBoxClass( $meta_box );
			if ( method_exists( $class, 'lang' ) ) {
				$value['lang'] = $class::lang();
			}

			//Push to List
			$list['meta_boxes'][ $meta_box ] = $value;
		}

		// Ads For Overview Pages
		if ( Menus::in_page( 'overview' ) ) {
			$overview_ads = get_option( 'WP_Extensions_overview_page_ads', false );
			if ( $overview_ads != false and is_array( $overview_ads ) and $overview_ads['ads']['ID'] != $overview_ads['view'] and $overview_ads['ads']['status'] == "yes" ) {
				$list['overview']['ads'] = $overview_ads['ads'];
			}
		}

		// Return Data JSON
		return $list;
	}

	/**
	 * Localize jquery datepicker
	 *
	 * @see https://gist.github.com/mehrshaddarzi/7f661baeb5d801961deb8b821157e820
	 */
	public static function localize_jquery_datepicker() {
		global $wp_locale;

		return array(
			'closeText'       => __( 'Done', 'WP-Extensions' ),
			'currentText'     => __( 'Today', 'WP-Extensions' ),
			'monthNames'      => Helper::strip_array_indices( $wp_locale->month ),
			'monthNamesShort' => Helper::strip_array_indices( $wp_locale->month_abbrev ),
			'monthStatus'     => __( 'Show a different month', 'WP-Extensions' ),
			'dayNames'        => Helper::strip_array_indices( $wp_locale->weekday ),
			'dayNamesShort'   => Helper::strip_array_indices( $wp_locale->weekday_abbrev ),
			'dayNamesMin'     => Helper::strip_array_indices( $wp_locale->weekday_initial ),
			'dateFormat'      => 'yy-mm-dd', // Format time for Jquery UI
			'firstDay'        => get_option( 'start_of_week' ),
			'isRTL'           => (int) $wp_locale->is_rtl(),
		);
	}
}

new Admin_Assets;