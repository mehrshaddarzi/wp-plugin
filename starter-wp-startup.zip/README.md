# WP Extensions
A free and advanced stats plugin for WordPress