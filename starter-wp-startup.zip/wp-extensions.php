<?php
/**
 * Plugin Name: WP Extensions
 * Plugin URI: https://wp-extensions.net/
 * Description: Manage WordPress website in browser extensions
 * Version: 1.0.0
 * Author: Mehrshad Darzi
 * Author URI: https://wp-extensions.net/
 * Text Domain: wp-extensions
 * Domain Path: /languages/
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

// Check get_plugin_data function exist
if ( ! function_exists( 'get_plugin_data' ) ) {
	require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}

// Set Plugin path and url defines.
define( 'WP_EXTENSIONS_URL', plugin_dir_url( dirname( __FILE__ ) ) );
define( 'WP_EXTENSIONS_DIR', plugin_dir_path( dirname( __FILE__ ) ) );
define( 'WP_EXTENSIONS_MAIN_FILE', WP_EXTENSIONS_DIR . 'wp-extensions.php' );

// Get plugin Data.
$plugin_data = get_plugin_data( WP_EXTENSIONS_MAIN_FILE );

// Set another useful Plugin defines.
define( 'WP_EXTENSIONS_VERSION', $plugin_data['Version'] );
define( 'WP_EXTENSIONS_SITE', $plugin_data['AuthorURI'] );


// Load Plugin
if ( ! class_exists( 'WP_Extensions' ) ) {
	require_once WP_EXTENSIONS_DIR . 'includes/class-wp-extensions.php';
}

// Returns the main instance of WP-Extensions.
function WP_Extensions() {
	return WP_Extensions::instance();
}

// Global for backwards compatibility.
$GLOBALS['WP_Extensions'] = WP_Extensions();